# CHAMA CHETU v2 — Database schema (SQLite; PostgreSQL notes below)

Tables created automatically on first start (server/server.js):

| Table | Purpose | Key columns |
|---|---|---|
| auth_users | Real accounts (bcrypt password hashes; never plaintext) | username PK, role CHECK(admin/chairperson/secretary/treasurer/member), password_hash, member_id, status(active/disabled), must_change_password, failed_attempts, locked_until, created_by |
| sessions | HttpOnly cookie sessions with expiry | sid PK, username FK, csrf, expires_at |
| state | Central business state (members, meetings, attendance, payments, ledger, MGR rotation, share-outs, settings) as one versioned document | id=1, data JSON, version (optimistic concurrency) |
| idempotency | Idempotency keys for every mutation + automatic pre-restore snapshots | key PK, action, response |
| audit_log | Append-only audit trail (logins, actions, denials, restores) | at, action, details, actor |
| login_audit | Login attempts (success/failure/lockout) | at, username, ip, ok, reason |

## Why a versioned state document plus relational auth tables?
- The double-entry ledger, duplicate-payment guards, fine automation, MGR rotation and
  share-out logic in src/core.js are already proven by 30+ unit tests. Storing that
  validated business state as one transactionally-replaced, version-checked document
  keeps those guarantees intact while adding multi-user concurrency safety
  (stale writes are rejected with HTTP 409, never silently merged).
- auth_users/sessions/audit are fully relational with parameterized queries everywhere
  (no string-built SQL, so no SQL injection surface).

## PostgreSQL upgrade path (when the group outgrows one server)
1. Provision a free Postgres (Supabase/Neon free tier).
2. Replace better-sqlite3 with `pg` + the same parameterized statements, or put
   `state.data` in a `jsonb` column with `version bigint` for the optimistic check.
3. No application-logic changes are needed: all business rules live in src/core.js.

## Backups
- `/api/backup` (admin only) downloads a full snapshot; every restore writes an
  automatic pre-restore snapshot into `idempotency` as a rollback point.
- Server-level: schedule `sqlite3 server/chama_chetu.db ".backup 'backups/cc-$(date +%F).db'"`
  nightly (cron) and copy off-site.
