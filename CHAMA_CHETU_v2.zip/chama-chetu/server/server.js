/* ============================================================
   CHAMA CHETU v2 — production backend
   Express + SQLite (better-sqlite3) + bcryptjs
   - No demo accounts: first admin created via one-time SETUP_TOKEN
   - HttpOnly/Secure/SameSite=Strict session cookies + CSRF tokens
   - Login rate-limiting + account lockout
   - Server-side RBAC on EVERY mutating action
   - Business state stored centrally in SQLite with optimistic
     versioning (stale clients get a conflict, never silent overwrite)
   - Business rules reuse src/core.js (double-entry ledger, reversals,
     duplicate guards) inside a synchronous transaction
   - Append-only audit log table
   Run:  node server/server.js     (see .env.example)
   ============================================================ */
require('dotenv').config();
const express = require('express');
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const path = require('path');
const fs = require('fs');
const Core = require('../src/core.js');

const PORT = process.env.PORT || 3000;
const DB_PATH = process.env.DB_PATH || path.join(__dirname, 'chama_chetu.db');
const SESSION_SECRET = process.env.SESSION_SECRET;
const SETUP_TOKEN = process.env.SETUP_TOKEN;
const COOKIE_SECURE = String(process.env.COOKIE_SECURE || 'auto') === 'true';

if (!SESSION_SECRET || SESSION_SECRET.length < 32) {
  console.error('FATAL: SESSION_SECRET env var missing or too short (min 32 chars). Generate: openssl rand -hex 32');
  process.exit(1);
}
if (!SETUP_TOKEN || SETUP_TOKEN.length < 24) {
  console.error('FATAL: SETUP_TOKEN env var missing or too short (min 24 chars). Generate: openssl rand -hex 24');
  process.exit(1);
}

/* ---------- database ---------- */
const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS auth_users (
  username TEXT PRIMARY KEY,
  full_name TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('admin','chairperson','secretary','treasurer','member')),
  password_hash TEXT NOT NULL,
  member_id TEXT,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','disabled')),
  must_change_password INTEGER NOT NULL DEFAULT 0,
  failed_attempts INTEGER NOT NULL DEFAULT 0,
  locked_until INTEGER,
  created_at TEXT NOT NULL,
  created_by TEXT
);
CREATE TABLE IF NOT EXISTS sessions (
  sid TEXT PRIMARY KEY,
  username TEXT NOT NULL REFERENCES auth_users(username),
  csrf TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS state (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  data TEXT NOT NULL,
  version INTEGER NOT NULL DEFAULT 1,
  updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS idempotency (
  key TEXT PRIMARY KEY,
  action TEXT NOT NULL,
  response TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS audit_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  at TEXT NOT NULL,
  action TEXT NOT NULL,
  details TEXT,
  actor TEXT
);
CREATE TABLE IF NOT EXISTS login_audit (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  at TEXT NOT NULL,
  username TEXT,
  ip TEXT,
  ok INTEGER NOT NULL,
  reason TEXT
);
`);

const qStateGet = db.prepare('SELECT data, version FROM state WHERE id = 1');
const qStateInit = db.prepare('INSERT INTO state (id, data, version, updated_at) VALUES (1, ?, 1, ?)');
const qStateSave = db.prepare('UPDATE state SET data = ?, version = version + 1, updated_at = ? WHERE id = 1 AND version = ?');
const qAudit = db.prepare('INSERT INTO audit_log (at, action, details, actor) VALUES (?, ?, ?, ?)');
const qIdemGet = db.prepare('SELECT response FROM idempotency WHERE key = ?');
const qIdemPut = db.prepare('INSERT OR IGNORE INTO idempotency (key, action, response, created_at) VALUES (?, ?, ?, ?)');
const qUserGet = db.prepare('SELECT * FROM auth_users WHERE username = ?');
const qUserAll = db.prepare('SELECT username, full_name, role, member_id, status, must_change_password, created_at, created_by FROM auth_users');
const qUserInsert = db.prepare('INSERT INTO auth_users (username, full_name, role, password_hash, member_id, status, must_change_password, created_at, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
const qUserSetRole = db.prepare('UPDATE auth_users SET role = ? WHERE username = ?');
const qUserSetStatus = db.prepare('UPDATE auth_users SET status = ? WHERE username = ?');
const qUserSetPwd = db.prepare('UPDATE auth_users SET password_hash = ?, must_change_password = ? WHERE username = ?');
const qUserFail = db.prepare('UPDATE auth_users SET failed_attempts = failed_attempts + 1 WHERE username = ?');
const qUserLock = db.prepare('UPDATE auth_users SET failed_attempts = 0, locked_until = ? WHERE username = ?');
const qUserFailReset = db.prepare('UPDATE auth_users SET failed_attempts = 0, locked_until = NULL WHERE username = ?');
const qSessionIns = db.prepare('INSERT INTO sessions (sid, username, csrf, created_at, expires_at) VALUES (?, ?, ?, ?, ?)');
const qSessionGet = db.prepare('SELECT * FROM sessions WHERE sid = ?');
const qSessionDel = db.prepare('DELETE FROM sessions WHERE sid = ?');
const qSessionPurge = db.prepare('DELETE FROM sessions WHERE expires_at < ?');
const qLoginAudit = db.prepare('INSERT INTO login_audit (at, username, ip, ok, reason) VALUES (?, ?, ?, ?, ?)');
const qAdminCount = db.prepare("SELECT COUNT(*) AS n FROM auth_users WHERE role = 'admin' AND status = 'active'");

function loadState() {
  const row = qStateGet.get();
  if (!row) { const fresh = blankState(); qStateInit.run(JSON.stringify(fresh), new Date().toISOString()); return { data: fresh, version: 1 }; }
  return { data: JSON.parse(row.data), version: row.version };
}
function blankState() {
  const s = Core.seedDB ? null : null; /* never seed demo data in production */
  return {
    version: 2, app: 'CHAMA CHETU', created_at: new Date().toISOString(),
    settings: {
      group_name: 'My Chama', logo: '', reg_no: '', contact: '',
      currency: 'KES', currency_symbol: 'KSh',
      meeting_frequency: 'Monthly', contribution_amount: 500, mgr_contribution: 300,
      fine_absence: 200, fine_late: 50, fine_apology: 0, late_payment_fine: 100,
      member_prefix: 'MEM', meeting_prefix: 'MTG', spin_exclude_benefited: true,
      financial_year_start: '01-01'
    },
    /* business users come from the auth_users table; state mirrors role links */
    users: [],
    members: [], meetings: [], attendance: [], payments: [],
    investments: [], expenses: [], ledger: [], audit: [], spin_history: [],
    mgr: { config: null, payouts: [] }, shareouts: [], shareout_config: null,
    notifications: []
  };
}
function saveState(version, mutate) {
  /* synchronous transaction: read-check-mutate-write, optimistic version */
  const tx = db.transaction(() => {
    const row = qStateGet.get();
    if (!row || row.version !== version) { const err = new Error('VERSION_CONFLICT'); err.code = 409; throw err; }
    const st = JSON.parse(row.data);
    const result = mutate(st);
    qStateSave.run(JSON.stringify(st), new Date().toISOString(), version);
    return { state: st, result, version: version + 1 };
  });
  return tx();
}

/* ---------- security helpers ---------- */
const sessions = new Map(); /* sid -> {username, role, member_id, expires} memory cache */
function hashPassword(p) { return bcrypt.hashSync(p, 10); }
function newSession(username) {
  const sid = crypto.randomBytes(32).toString('hex');
  const csrf = crypto.randomBytes(24).toString('hex');
  const now = Date.now();
  const ttl = parseInt(process.env.SESSION_TTL_HOURS || '12', 10) * 3600 * 1000;
  qSessionIns.run(sid, username, csrf, now, now + ttl);
  return { sid, csrf, expires_at: now + ttl };
}
function getSession(req) {
  const raw = (req.headers.cookie || '').split(/;\s*/).find(c => c.startsWith('cc_sid='));
  if (!raw) return null;
  const sid = decodeURIComponent(raw.split('=')[1]);
  const row = qSessionGet.get(sid);
  if (!row || row.expires_at < Date.now()) { if (row) qSessionDel.run(sid); return null; }
  const u = qUserGet.get(row.username);
  if (!u || u.status !== 'active') { qSessionDel.run(sid); return null; }
  return { sid, username: u.username, role: u.role, member_id: u.member_id, csrf: row.csrf, must_change_password: !!u.must_change_password };
}
function publicUser(u) { return { username: u.username, full_name: u.full_name, role: u.role, member_id: u.member_id, status: u.status }; }

/* member data filtering: ordinary members never receive other members' financial records */
function filterStateFor(st, sess) {
  if (sess.role !== 'member') return st;
  const own = sess.member_id;
  const ownLedger = st.ledger.filter(e =>
    e.member_id === own || (e.lines || []).some(l => l.member_id === own) ||
    (!e.member_id && !(e.lines || []).some(l => String(l.account || '').includes('@'))));
  return {
    version: st.version, app: st.app, created_at: st.created_at,
    settings: { ...st.settings },
    users: [],
    members: st.members.filter(m => m.id === own),
    meetings: st.meetings.map(m => ({ id: m.id, ref: m.ref, date: m.date, time: m.time, venue: m.venue, type: m.type, status: m.status })),
    attendance: st.attendance.filter(a => a.member_id === own),
    payments: st.payments.filter(p => p.member_id === own),
    investments: [], expenses: [],
    ledger: ownLedger,
    audit: [], spin_history: st.spin_history,
    mgr: st.mgr, shareouts: st.shareouts, shareout_config: st.shareout_config,
    notifications: st.notifications || []
  };
}

/* ---------- rate limiting ---------- */
const hits = new Map();
function rateLimit(req, res, next) {
  const key = (req.headers['x-forwarded-for'] || req.socket.remoteAddress || '?') + ':' + req.path;
  const now = Date.now(), win = 60000, max = 90;
  const arr = (hits.get(key) || []).filter(t => now - t < win);
  arr.push(now); hits.set(key, arr);
  if (arr.length > max) return res.status(429).json({ error: 'Too many requests — slow down.' });
  next();
}

/* ---------- app ---------- */
const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '2mb' }));
app.use(rateLimit);
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Content-Security-Policy', "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'");
  if (COOKIE_SECURE || req.secure || req.headers['x-forwarded-proto'] === 'https') res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  next();
});

function setCookie(res, sid, maxAgeMs) {
  const secure = COOKIE_SECURE || 'auto';
  const secFlag = secure === 'true' ? '; Secure' : '';
  res.setHeader('Set-Cookie', `cc_sid=${sid}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${Math.floor(maxAgeMs / 1000)}${secFlag}`);
}
function requireAuth(req, res, next) {
  const s = getSession(req);
  if (!s) return res.status(401).json({ error: 'Not authenticated' });
  req.sess = s; next();
}
function requireCSRF(req, res, next) {
  if (req.headers['x-csrf-token'] !== req.sess.csrf) return res.status(403).json({ error: 'CSRF token invalid' });
  next();
}
function requireRole(action) {
  return (req, res, next) => {
    if (!Core.can(req.sess.role, action)) {
      qAudit.run(new Date().toISOString(), 'ACCESS_DENIED', action, req.sess.username);
      return res.status(403).json({ error: `ACCESS DENIED: role "${req.sess.role}" cannot "${action}"` });
    }
    next();
  };
}

/* ---------- routes ---------- */
app.get('/api/health', (req, res) => res.json({ ok: true, app: 'CHAMA CHETU', version: 2 }));

app.get('/api/setup-status', (req, res) => res.json({ setup_needed: qAdminCount.get().n === 0 }));

/* One-time protected setup: creates the FIRST administrator. Requires SETUP_TOKEN. */
app.post('/api/setup', (req, res) => {
  if (qAdminCount.get().n > 0) return res.status(409).json({ error: 'Setup already completed — administrator exists.' });
  const { setup_token, username, password, full_name, group_name } = req.body || {};
  if (!setup_token || setup_token !== SETUP_TOKEN) { qAudit.run(new Date().toISOString(), 'SETUP_DENIED', 'bad token', 'anonymous'); return res.status(403).json({ error: 'Invalid setup token' }); }
  if (!/^[a-zA-Z0-9_.-]{3,32}$/.test(username || '')) return res.status(400).json({ error: 'Username must be 3-32 chars (letters, digits, . _ -)' });
  if (!password || String(password).length < 8) return res.status(400).json({ error: 'Password must be at least 8 characters' });
  const st0 = loadState();
  if (group_name) st0.data.settings.group_name = String(group_name).slice(0, 80);
  db.transaction(() => {
    qUserInsert.run(username, full_name || 'Administrator', 'admin', hashPassword(password), null, 'active', 0, new Date().toISOString(), 'setup');
    qStateSave.run(JSON.stringify(st0.data), new Date().toISOString(), st0.version);
    qAudit.run(new Date().toISOString(), 'SETUP_ADMIN_CREATED', username, 'setup');
  })();
  qLoginAudit.run(new Date().toISOString(), username, req.ip, 1, 'setup');
  const s = newSession(username);
  setCookie(res, s.sid, s.expires_at - Date.now());
  const st = loadState();
  res.json({ csrf: s.csrf, user: publicUser(qUserGet.get(username)), state: filterStateFor(st.data, { role: 'admin' }), version: st.version });
});

app.post('/api/login', (req, res) => {
  const { username, password } = req.body || {};
  const u = username ? qUserGet.get(String(username)) : null;
  const now = Date.now();
  if (!u || u.status === 'disabled') { qLoginAudit.run(new Date().toISOString(), username || '?', req.ip, 0, u ? 'disabled' : 'no-user'); return res.status(401).json({ error: 'Invalid username or password' }); }
  if (u.locked_until && u.locked_until > now) { qLoginAudit.run(new Date().toISOString(), username, req.ip, 0, 'locked'); return res.status(423).json({ error: 'Account temporarily locked after failed attempts. Try again later.' }); }
  if (!u.password_hash || !bcrypt.compareSync(String(password || ''), u.password_hash)) {
    db.transaction(() => {
      qUserFail.run(username);
      const after = qUserGet.get(username);
      if (after.failed_attempts >= 5) qUserLock.run(now + 10 * 60 * 1000, username);
      qLoginAudit.run(new Date().toISOString(), username, req.ip, 0, 'bad-password');
    })();
    return res.status(401).json({ error: 'Invalid username or password' });
  }
  qUserFailReset.run(username);
  qLoginAudit.run(new Date().toISOString(), username, req.ip, 1, 'ok');
  const s = newSession(username);
  setCookie(res, s.sid, s.expires_at - Date.now());
  qSessionPurge.run(now);
  const st = loadState();
  res.json({ csrf: s.csrf, user: { ...publicUser(u), must_change_password: !!u.must_change_password }, state: filterStateFor(st.data, { role: u.role, member_id: u.member_id }), version: st.version });
});

app.post('/api/logout', requireAuth, (req, res) => { qSessionDel.run(req.sess.sid); res.setHeader('Set-Cookie', 'cc_sid=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0'); res.json({ ok: true }); });

app.get('/api/session', (req, res) => {
  const s = getSession(req);
  if (!s) return res.status(401).json({ error: 'Not authenticated' });
  const st = loadState();
  res.json({ csrf: s.csrf, user: { username: s.username, role: s.role, member_id: s.member_id, must_change_password: s.must_change_password }, state: filterStateFor(st.data, s), version: st.version });
});

/* change own password (requires current password) */
app.post('/api/password', requireAuth, requireCSRF, (req, res) => {
  const { current, next } = req.body || {};
  const u = qUserGet.get(req.sess.username);
  if (!bcrypt.compareSync(String(current || ''), u.password_hash)) return res.status(401).json({ error: 'Current password is wrong' });
  if (!next || String(next).length < 8) return res.status(400).json({ error: 'New password must be at least 8 characters' });
  qUserSetPwd.run(hashPassword(next), 0, req.sess.username);
  qAudit.run(new Date().toISOString(), 'PASSWORD_CHANGED', req.sess.username, req.sess.username);
  res.json({ ok: true });
});

/* admin: create user, set role, disable/enable, reset password */
app.post('/api/users', requireAuth, requireCSRF, requireRole('manage_users'), (req, res) => {
  const { username, password, full_name, role, member_id } = req.body || {};
  if (!/^[a-zA-Z0-9_.-]{3,32}$/.test(username || '')) return res.status(400).json({ error: 'Invalid username' });
  if (!password || String(password).length < 8) return res.status(400).json({ error: 'Password must be at least 8 characters' });
  if (!Core.ROLES.includes(role)) return res.status(400).json({ error: 'Unknown role' });
  if (qUserGet.get(username)) return res.status(409).json({ error: 'Username already exists' });
  qUserInsert.run(username, full_name || username, role, hashPassword(password), member_id || null, 'active', 1, new Date().toISOString(), req.sess.username);
  qAudit.run(new Date().toISOString(), 'USER_CREATED', `${username} (${role})`, req.sess.username);
  res.json({ ok: true, users: qUserAll.all().map(publicUser) });
});
app.post('/api/users/role', requireAuth, requireCSRF, requireRole('assign_roles'), (req, res) => {
  const { username, role } = req.body || {};
  const u = qUserGet.get(username || '');
  if (!u) return res.status(404).json({ error: 'User not found' });
  if (!Core.ROLES.includes(role)) return res.status(400).json({ error: 'Unknown role' });
  if (u.role === 'admin' && role !== 'admin' && qAdminCount.get().n <= 1) return res.status(400).json({ error: 'Cannot demote the last administrator' });
  qUserSetRole.run(role, username);
  qAudit.run(new Date().toISOString(), 'ROLE_CHANGE', `${username}: ${u.role} -> ${role}`, req.sess.username);
  res.json({ ok: true, users: qUserAll.all().map(publicUser) });
});
app.post('/api/users/status', requireAuth, requireCSRF, requireRole('manage_users'), (req, res) => {
  const { username, status } = req.body || {};
  const u = qUserGet.get(username || '');
  if (!u) return res.status(404).json({ error: 'User not found' });
  if (u.role === 'admin' && status === 'disabled' && qAdminCount.get().n <= 1) return res.status(400).json({ error: 'Cannot disable the last administrator' });
  if (status !== 'active' && status !== 'disabled') return res.status(400).json({ error: 'Bad status' });
  db.transaction(() => { qUserSetStatus.run(status, username); qSessionDel.run && db.prepare('DELETE FROM sessions WHERE username = ?').run(username); })();
  qAudit.run(new Date().toISOString(), 'USER_STATUS', `${username} -> ${status}`, req.sess.username);
  res.json({ ok: true, users: qUserAll.all().map(publicUser) });
});
app.post('/api/users/reset-password', requireAuth, requireCSRF, requireRole('manage_users'), (req, res) => {
  const { username, new_password } = req.body || {};
  const u = qUserGet.get(username || '');
  if (!u) return res.status(404).json({ error: 'User not found' });
  if (!new_password || String(new_password).length < 8) return res.status(400).json({ error: 'Password must be at least 8 characters' });
  qUserSetPwd.run(hashPassword(new_password), 1, username);
  db.prepare('DELETE FROM sessions WHERE username = ?').run(username);
  qAudit.run(new Date().toISOString(), 'PASSWORD_RESET_BY_ADMIN', username, req.sess.username);
  res.json({ ok: true });
});
app.get('/api/users', requireAuth, (req, res) => {
  if (req.sess.role === 'member') return res.json({ users: [] });
  res.json({ users: qUserAll.all().map(publicUser) });
});

/* ---------- business state + actions ---------- */
app.get('/api/state', requireAuth, (req, res) => {
  const st = loadState();
  res.json({ state: filterStateFor(st.data, req.sess), version: st.version });
});

/* THE single mutating endpoint. Dispatch table enforces server-side RBAC
   via Core permissions; every action is transactional, idempotent-keyed,
   version-checked, and audited. */
const ACTIONS = {
  addMember:            { perm: 'manage_members',   run: (st, p, role, by) => Core.addMember(st, p, by, role) },
  editMember:           { perm: 'edit_members',     run: (st, p, role, by) => Core.editMember(st, p.id, p, role) },
  removeMember:         { perm: 'remove_members',   run: (st, p, role, by) => Core.removeMember(st, p.id, p.reason, role) },
  importMembers:        { perm: 'manage_members',   run: (st, p, role, by) => Core.importMembers(st, p.rows, by, role) },
  createMeeting:        { perm: 'schedule_meetings',run: (st, p, role, by) => Core.createMeeting(st, p, role) },
  markAttendance:       { perm: 'record_attendance',run: (st, p, role) => Core.markAttendance(st, p.meeting_id, p.member_id, p.status, role) },
  waiveFine:            { perm: 'waive_fines',      run: (st, p, role, by) => Core.waiveFine(st, p.meeting_id, p.member_id, p.reason, by, role) },
  closeMeeting:         { perm: 'close_meeting',    run: (st, p, role) => Core.closeMeeting(st, p.meeting_id, p.minutes, p.resolutions, role) },
  recordPayment:        { perm: 'record_payments',  run: (st, p, role, by) => Core.recordPayment(st, p, role) },
  mgrConfig:            { perm: 'manage_settings',  run: (st, p, role) => Core.mgrConfig(st, p, role) },
  recordMgrPayout:      { perm: 'record_payments',  run: (st, p, role) => Core.recordMgrPayout(st, p.member_id, p.amount, p.date, role) },
  spinSelect:           { perm: 'spin_beneficiary', run: (st, p, role, by) => Core.spinSelect(st, p.meeting_id, by, role) },
  addInvestment:        { perm: 'record_investments',run: (st, p, role) => Core.addInvestment(st, p, role) },
  addExpense:           { perm: 'record_expenses',  run: (st, p, role) => Core.addExpense(st, p, role) },
  configureShareOut:    { perm: 'configure_shareout',run: (st, p, role) => Core.configureShareOut(st, p, role) },
  executeShareOut:      { perm: 'execute_shareout', run: (st, p, role, by) => Core.executeShareOut(st, p.date, by, role) },
  reverse:              { perm: 'correct_records',  run: (st, p, role, by) => Core.reverse(st, p.entry_id, p.reason, by) },
  saveSettings:         { perm: 'manage_settings',  run: (st, p, role) => { Object.assign(st.settings, p.patch || {}); if (st.mgr.config && p.patch && p.patch.mgr_contribution) st.mgr.config.amount = p.patch.mgr_contribution; return st.settings; } }
};

app.post('/api/action', requireAuth, requireCSRF, (req, res) => {
  const { action, payload, idempotency_key, base_version } = req.body || {};
  const spec = ACTIONS[action];
  if (!spec) return res.status(400).json({ error: 'Unknown action' });
  if (!Core.can(req.sess.role, spec.perm)) {
    qAudit.run(new Date().toISOString(), 'ACCESS_DENIED', action, req.sess.username);
    return res.status(403).json({ error: `ACCESS DENIED: role "${req.sess.role}" cannot perform ${action}` });
  }
  if (!idempotency_key || typeof idempotency_key !== 'string' || idempotency_key.length > 64)
    return res.status(400).json({ error: 'idempotency_key required' });
  const cached = qIdemGet.get(idempotency_key);
  if (cached) return res.json(JSON.parse(cached.response));
  if (!Number.isInteger(base_version)) return res.status(400).json({ error: 'base_version required' });
  try {
    const out = saveState(base_version, st => spec.run(st, payload || {}, req.sess.role, req.sess.username));
    qAudit.run(new Date().toISOString(), 'ACTION:' + action, JSON.stringify(payload || {}).slice(0, 500), req.sess.username);
    const resp = { ok: true, result: out.result, state: filterStateFor(out.state, req.sess), version: out.version };
    qIdemPut.run(idempotency_key, action, JSON.stringify(resp), new Date().toISOString());
    res.json(resp);
  } catch (e) {
    if (e.message === 'VERSION_CONFLICT') return res.status(409).json({ error: 'Conflict: another user updated records. Reloading latest…', code: 'VERSION_CONFLICT' });
    res.status(400).json({ error: e.message });
  }
});

/* backup / restore (admin only) */
app.get('/api/backup', requireAuth, (req, res) => {
  if (req.sess.role !== 'admin') return res.status(403).json({ error: 'ACCESS DENIED' });
  const st = loadState();
  const users = qUserAll.all();
  const payload = { app: 'CHAMA CHETU', exported_at: new Date().toISOString(), version: st.version, state: st.data, users: users.map(u => ({ ...u, password_hash: undefined })) };
  qAudit.run(new Date().toISOString(), 'BACKUP_DOWNLOADED', 'version ' + st.version, req.sess.username);
  res.setHeader('Content-Disposition', `attachment; filename="chama-chetu-backup-${new Date().toISOString().slice(0, 10)}.json"`);
  res.json(payload);
});
app.post('/api/restore', requireAuth, requireCSRF, (req, res) => {
  if (req.sess.role !== 'admin') return res.status(403).json({ error: 'ACCESS DENIED' });
  const b = req.body || {};
  if (!b.state || !b.state.settings || !b.state.ledger) return res.status(400).json({ error: 'Not a valid CHAMA CHETU backup file' });
  /* safety: automatic pre-restore snapshot kept in DB (rollback point) */
  const pre = loadState();
  db.prepare('INSERT INTO idempotency (key, action, response, created_at) VALUES (?, ?, ?, ?)')
    .run('PRE-RESTORE-' + Date.now(), 'snapshot', JSON.stringify({ state: pre.data, version: pre.version }), new Date().toISOString());
  db.transaction(() => {
    qStateSave.run(JSON.stringify(b.state), new Date().toISOString(), pre.version);
    qAudit.run(new Date().toISOString(), 'RESTORE', 'version ' + pre.version + ' -> backup of ' + (b.exported_at || 'unknown'), req.sess.username);
  })();
  const st = loadState();
  res.json({ ok: true, state: filterStateFor(st.data, req.sess), version: st.version, rollback_note: 'Pre-restore snapshot stored; contact the server operator to roll back.' });
});
app.get('/api/audit', requireAuth, (req, res) => {
  if (req.sess.role === 'member') return res.status(403).json({ error: 'ACCESS DENIED' });
  res.json({ rows: db.prepare('SELECT at, action, details, actor FROM audit_log ORDER BY id DESC LIMIT 200').all() });
});

/* static frontend */
app.use(express.static(path.join(__dirname, '..', 'public'), { index: 'index.html', maxAge: '1h' }));
app.get('/', (req, res) => res.sendFile(path.join(__dirname, '..', 'public', 'index.html')));

app.use((err, req, res, next) => { console.error(err); res.status(500).json({ error: 'Internal server error' }); });

app.listen(PORT, () => {
  console.log(`CHAMA CHETU v2 backend on :${PORT}`);
  console.log(`Setup needed: ${qAdminCount.get().n === 0 ? 'YES — create first admin via POST /api/setup with SETUP_TOKEN' : 'no'}`);
});
module.exports = { app, loadState, saveState, qUserGet, qUserAll, qAudit, qIdemGet, qIdemPut, hashPassword, ACTIONS, filterStateFor, qStateSave, qStateInit, qUserInsert, qAdminCount, db };
