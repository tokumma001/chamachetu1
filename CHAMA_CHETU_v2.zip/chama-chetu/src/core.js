/* ============================================================
   CHAMA CHETU — Community Savings & Merry-Go-Round Manager
   Core financial engine — double-entry ledger + business rules.
   Shared by the offline-first PWA (browser) and Node test suite.
   NOTE (v3 refactor): member LENDING removed entirely — the group
   product is monthly savings + merry-go-round (MGR) with:
   delayed-payment fines, double penalty on delayed MGR, spin that
   determines the next MGR beneficiary, and scheduled share-out of
   savings. No loan/interest code exists in this engine.
   ============================================================ */
(function (root, factory) {
  if (typeof module !== 'undefined' && module.exports) module.exports = factory();
  else root.CSLM = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  /* ---------- storage (localStorage + memory fallback + key migration) ---------- */
  var _mem = {};
  var Storage = {
    load: function () {
      var raw = null;
      try { raw = localStorage.getItem('chama_chetu_db'); } catch (e) {}
      if (!raw) { /* migrate data saved by the earlier build key */
        try { raw = localStorage.getItem('cslm_db'); } catch (e2) {}
      }
      if (!raw) { try { raw = _mem['chama_chetu_db']; } catch (e3) {} }
      try { return raw ? JSON.parse(raw) : null; } catch (e4) { return null; }
    },
    save: function (db) {
      var s = JSON.stringify(db);
      try { localStorage.setItem('chama_chetu_db', s); try { localStorage.removeItem('cslm_db'); } catch (e0) {} return; } catch (e) {}
      try { _mem['chama_chetu_db'] = s; } catch (e2) {}
    }
  };

  /* ---------- helpers ---------- */
  function uid(p) { return (p || 'ID') + '-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8); }
  function todayISO() { return new Date().toISOString().slice(0, 10); }
  function r2(n) { return Math.round((Number(n) || 0) * 100) / 100; }

  /* synchronous salted hash — demo-grade; production server must use bcrypt/argon2 */
  function pinHash(pin, salt) {
    salt = salt || 'cslm';
    var s = salt + ':' + pin, h1 = 0x811c9dc5, h2 = 0x1000193, i, c;
    for (var round = 0; round < 512; round++) {
      for (i = 0; i < s.length; i++) {
        c = s.charCodeAt(i);
        h1 = ((h1 ^ c) * 0x01000193) >>> 0;
        h2 = ((h2 + c * (round + 1)) * 0x85ebca6b) >>> 0;
      }
      s = (h1 >>> 0).toString(36) + (h2 >>> 0).toString(36);
    }
    return (h1 >>> 0).toString(16) + ':' + (h2 >>> 0).toString(16);
  }

  /* ---------- account chart ---------- */
  var ACCOUNTS = {
    CASH:            { type: 'asset',     label: 'Cash box' },
    MPESA:           { type: 'asset',     label: 'M-Pesa / bank float' },
    INVESTMENTS:     { type: 'asset',     label: 'Group investments' },
    FINES_RECEIVABLE:{ type: 'asset',     label: 'Fines receivable' },
    MEMBER_SAVINGS:  { type: 'liability', label: 'Monthly member savings' },
    SPECIAL_SAVINGS: { type: 'liability', label: 'Special savings' },
    MGR_FUND:        { type: 'liability', label: 'Merry-go-round fund (SEPARATE)' },
    WELFARE:         { type: 'liability', label: 'Welfare fund' },
    INTEREST_INCOME: { type: 'income',    label: 'Penalty & fine income' },
    FINE_INCOME:     { type: 'income',    label: 'Fine income' },
    GROUP_EXPENSES:  { type: 'expense',   label: 'Group expenses' }
  };
  function acc(account, memberId) { return memberId ? account + '@' + memberId : account; }
  function accBalance(db, account, memberId) {
    var key = acc(account, memberId), t = 0;
    db.ledger.forEach(function (e) {
      e.lines.forEach(function (l) { if (l.account === key) t += (l.debit || 0) - (l.credit || 0); });
    });
    t = r2(t);
    var base = ACCOUNTS[account];
    if (base && (base.type === 'liability' || base.type === 'income')) return -t;
    return t;
  }
  function groupBalance(db, account) { return accBalance(db, account, null); }

  /* ---------- ledger posting (reversals only, never deletes) ---------- */
  function post(db, o) {
    var lines = o.lines.filter(function (l) { return r2(l.debit) !== 0 || r2(l.credit) !== 0; })
      .map(function (l) { return { account: l.account, member_id: l.member_id || null, debit: r2(l.debit || 0), credit: r2(l.credit || 0) }; });
    if (!lines.length) throw new Error('Empty posting rejected');
    var d = 0, c = 0;
    lines.forEach(function (l) { d += l.debit; c += l.credit; });
    if (r2(d) !== r2(c)) throw new Error('Unbalanced entry rejected: Dr ' + d + ' != Cr ' + c);
    var entry = {
      id: uid('TXN'), date: o.date || todayISO(), ref: o.ref || uid('REF'),
      category: o.category, desc: o.desc || '', meeting_id: o.meeting_id || null,
      member_id: o.member_id || null, lines: lines, by: o.by || 'system',
      approved: o.approved !== false, reversal_of: o.reversal_of || null,
      posted_at: new Date().toISOString()
    };
    db.ledger.push(entry);
    return entry;
  }
  function reverse(db, entryId, reason, by) {
    var orig = db.ledger.filter(function (e) { return e.id === entryId && !e.reversal_of; })[0];
    if (!orig) throw new Error('Original entry not found (or already reversed)');
    if (db.ledger.some(function (e) { return e.reversal_of === entryId; })) throw new Error('Entry already reversed');
    var lines = orig.lines.map(function (l) {
      return { account: l.account, member_id: l.member_id, debit: l.credit, credit: l.debit };
    });
    var rev = post(db, { date: todayISO(), category: 'REVERSAL', desc: 'Reversal of ' + orig.id + ': ' + (reason || ''), lines: lines, by: by, reversal_of: entryId });
    db.audit.push({ id: uid('AUD'), at: new Date().toISOString(), action: 'REVERSAL', ref: entryId, reason: reason || '', by: by });
    return rev;
  }
  function isReversed(db, id) { return db.ledger.some(function (e) { return e.reversal_of === id; }); }

  /* ---------- roles & guards ---------- */
  var ROLES = ['admin', 'chairperson', 'secretary', 'treasurer', 'member'];
  var PERMISSIONS = {
    'manage_users':      ['admin'],
    'assign_roles':      ['admin'],
    'manage_settings':   ['admin', 'chairperson'],
    'manage_members':    ['admin', 'secretary'],
    'edit_members':      ['admin', 'secretary'],
    'remove_members':    ['admin'],
    'schedule_meetings': ['admin', 'secretary'],
    'record_attendance': ['admin', 'secretary'],
    'waive_fines':       ['admin', 'chairperson'],
    'record_payments':   ['admin', 'treasurer'],
    'record_expenses':   ['admin', 'treasurer'],
    'record_investments':['admin', 'treasurer'],
    'configure_shareout':['admin', 'chairperson'],
    'execute_shareout':  ['admin', 'treasurer'],
    'spin_beneficiary':  ['admin', 'chairperson'],
    'view_all_finances': ['admin', 'chairperson', 'treasurer'],
    'view_own_records':  ROLES,
    'close_meeting':     ['admin', 'secretary', 'chairperson'],
    'correct_records':   ['admin', 'chairperson']
  };
  function can(role, action) { return (PERMISSIONS[action] || []).indexOf(role) !== -1; }
  function guard(role, action) { if (!can(role, action)) throw new Error('ACCESS DENIED: role "' + role + '" cannot "' + action + '"'); }

  /* ---------- auth ---------- */
  function login(db, name, pin) {
    var u = db.users.filter(function (x) { return x.username.toLowerCase() === String(name).toLowerCase() && x.status !== 'disabled'; })[0];
    if (!u || u.pin_hash !== pinHash(pin, u.username)) throw new Error('Invalid username or PIN');
    return { user_id: u.id, username: u.username, full_name: u.full_name, role: u.role, member_id: u.member_id || null };
  }

  /* ---------- members ---------- */
  function addMember(db, m, by, role) {
    guard(role, 'manage_members');
    var seq = db.members.length + 1;
    var member = {
      id: uid('MEM'), m_no: db.settings.member_prefix + String(seq).padStart(3, '0'),
      full_name: m.full_name, phone: m.phone || '', gender: m.gender || '',
      id_no: m.id_no || '', village: m.village || '', next_of_kin: m.next_of_kin || '',
      remarks: m.remarks || '', photo: m.photo || null,
      status: m.status || 'Active', joined: m.joined || todayISO(),
      registered_by: by
    };
    db.members.push(member);
    return member;
  }
  /* 1. admin/secretary edit member — audited, never silent */
  function editMember(db, memberId, patch, role) {
    guard(role, 'edit_members');
    var m = db.members.filter(function (x) { return x.id === memberId; })[0];
    if (!m) throw new Error('Member not found');
    var changes = [];
    ['full_name', 'phone', 'gender', 'id_no', 'village', 'next_of_kin', 'remarks', 'status', 'photo'].forEach(function (k) {
      if (patch[k] !== undefined && patch[k] !== m[k]) { changes.push(k + ': "' + m[k] + '"->"' + patch[k] + '"'); m[k] = patch[k]; }
    });
    db.audit.push({ id: uid('AUD'), at: new Date().toISOString(), action: 'MEMBER_EDIT', member: m.m_no, reason: changes.join('; ') || 'no change', by: role });
    return m;
  }
  /* 1. admin soft-remove member — historical records and ledger untouched */
  function removeMember(db, memberId, reason, role) {
    guard(role, 'remove_members');
    var m = db.members.filter(function (x) { return x.id === memberId; })[0];
    if (!m) throw new Error('Member not found');
    m.status = 'Removed';
    db.audit.push({ id: uid('AUD'), at: new Date().toISOString(), action: 'MEMBER_REMOVED', member: m.m_no, reason: reason || '', by: role });
    return m;
  }
  /* bulk import (used by the Excel importer; validated upstream in the UI) */
  function importMembers(db, rows, by, role) {
    guard(role, 'manage_members');
    var added = [], skipped = [];
    rows.forEach(function (r) {
      if (!r.full_name || !String(r.full_name).trim()) { skipped.push({ row: r, reason: 'missing name' }); return; }
      var dup = db.members.some(function (m) {
        return m.status !== 'Removed' && m.full_name.toLowerCase() === String(r.full_name).trim().toLowerCase();
      });
      if (dup) { skipped.push({ row: r, reason: 'duplicate name' }); return; }
      added.push(addMember(db, r, by, role));
    });
    db.audit.push({ id: uid('AUD'), at: new Date().toISOString(), action: 'MEMBERS_IMPORTED', reason: added.length + ' added, ' + skipped.length + ' skipped', by: role });
    return { added: added, skipped: skipped };
  }

  /* ---------- 2. role assignment (admin only, audited) ---------- */
  function setUserRole(db, userId, newRole, role) {
    guard(role, 'assign_roles');
    if (ROLES.indexOf(newRole) === -1) throw new Error('Unknown role');
    var u = db.users.filter(function (x) { return x.id === userId; })[0];
    if (!u) throw new Error('User not found');
    if (u.role === 'admin' && newRole !== 'admin') {
      var admins = db.users.filter(function (x) { return x.role === 'admin' && x.status !== 'disabled'; });
      if (admins.length <= 1) throw new Error('Cannot demote the last administrator');
    }
    var old = u.role;
    u.role = newRole;
    db.audit.push({ id: uid('AUD'), at: new Date().toISOString(), action: 'ROLE_CHANGE', ref: u.username, reason: old + ' -> ' + newRole, by: role });
    return u;
  }
  function addUser(db, o, role) {
    guard(role, 'manage_users');
    if (db.users.some(function (u) { return u.username.toLowerCase() === String(o.username).toLowerCase(); }))
      throw new Error('Username already exists');
    var u = {
      id: uid('U'), username: String(o.username).trim(), full_name: o.full_name || o.username,
      role: o.role || 'member', pin_hash: pinHash(o.pin || ('Tmp-' + Math.random().toString(36).slice(2, 12) + '!Aa'), String(o.username).trim()),
      status: 'active', phone: o.phone || '', member_id: o.member_id || null
    };
    db.users.push(u);
    db.audit.push({ id: uid('AUD'), at: new Date().toISOString(), action: 'USER_ADDED', ref: u.username, reason: u.role, by: role });
    return u;
  }

  /* ---------- meetings & attendance + automated fines ---------- */
  function createMeeting(db, o, role) {
    guard(role, 'schedule_meetings');
    var m = {
      id: uid('MTG'), ref: db.settings.meeting_prefix + '-' + String(db.meetings.length + 1).padStart(4, '0'),
      date: o.date, time: o.time || '14:00', venue: o.venue || 'Group venue', type: o.type || 'Regular',
      status: 'open', minutes: '', resolutions: '', opened_at: new Date().toISOString(), closed_at: null
    };
    db.meetings.push(m);
    return m;
  }
  var FINE_KEY = { P: null, A: 'fine_apology', X: 'fine_absence', L: 'fine_late' };
  function markAttendance(db, meetingId, memberId, status, role) {
    guard(role, 'record_attendance');
    var mtg = db.meetings.filter(function (m) { return m.id === meetingId; })[0];
    if (!mtg) throw new Error('Meeting not found');
    if (mtg.status === 'closed') throw new Error('Meeting is closed — corrections require documented authorization');
    var mem = db.members.filter(function (m) { return m.id === memberId; })[0];
    if (!mem) throw new Error('Member not found');
    if (['P', 'A', 'X', 'L'].indexOf(status) === -1) throw new Error('Invalid attendance status');
    var fineKey = FINE_KEY[status];
    var fine = fineKey ? r2(db.settings[fineKey] || 0) : 0;
    var existing = db.attendance.filter(function (a) { return a.meeting_id === meetingId && a.member_id === memberId; })[0];
    if (existing) {
      db.audit.push({ id: uid('AUD'), at: new Date().toISOString(), action: 'ATTENDANCE_CORRECTION', meeting: mtg.ref, member: mem.m_no, from: existing.status, to: status, by: role });
      existing.status = status; existing.fine_amount = fine; existing.updated_at = new Date().toISOString();
      syncAttendanceFineLedger(db, existing, meetingId, mem);
      return existing;
    }
    var rec = { id: uid('ATT'), meeting_id: meetingId, member_id: memberId, status: status,
      fine_amount: fine, fine_paid_amount: 0, waived: false, marked_at: new Date().toISOString() };
    db.attendance.push(rec);
    if (fine > 0) syncAttendanceFineLedger(db, rec, meetingId, mem);
    return rec;
  }
  function syncAttendanceFineLedger(db, att, meetingId, mem) {
    var mtg = db.meetings.filter(function (m) { return m.id === meetingId; })[0];
    var existingPost = db.ledger.filter(function (e) {
      return e.category === 'FINE' && e.meeting_id === meetingId && e.member_id === att.member_id && !isReversed(db, e.id);
    })[0];
    if (existingPost && r2(existingPost.lines[0].debit) !== r2(att.fine_amount)) {
      reverse(db, existingPost.id, 'Attendance corrected - fine re-assessed', 'system');
      existingPost = null;
    }
    if (!existingPost && att.fine_amount > 0 && !att.waived) {
      post(db, { date: mtg.date, meeting_id: meetingId, member_id: att.member_id, category: 'FINE',
        desc: 'Attendance fine (' + att.status + ') ' + mtg.ref + ' ' + mem.m_no,
        lines: [{ account: acc('FINES_RECEIVABLE', att.member_id), debit: att.fine_amount },
                { account: 'FINE_INCOME', credit: att.fine_amount }], by: 'system' });
    }
  }
  function waiveFine(db, meetingId, memberId, reason, by, role) {
    guard(role, 'waive_fines');
    var att = db.attendance.filter(function (a) { return a.meeting_id === meetingId && a.member_id === memberId; })[0];
    if (!att) throw new Error('Attendance record not found');
    var existingPost = db.ledger.filter(function (e) {
      return e.category === 'FINE' && e.meeting_id === meetingId && e.member_id === memberId && !isReversed(db, e.id);
    })[0];
    if (existingPost && !att.waived) reverse(db, existingPost.id, 'Fine waived: ' + reason, by);
    att.waived = true; att.waived_reason = reason; att.waived_by = by;
    db.audit.push({ id: uid('AUD'), at: new Date().toISOString(), action: 'FINE_WAIVER', meeting: meetingId, member: memberId, reason: reason, by: by });
    return att;
  }
  /* 5. delayed-payment fine: when a meeting closes, any active member who
     contributed less than the agreed monthly amount for THIS meeting gets one
     configurable late-payment fine (never duplicated). */
  function syncLatePaymentFines(db, meeting, by) {
    var reg = contributionRegister(db, meeting);
    reg.forEach(function (r) {
      if (r.outstanding <= 0) return;
      var amt = r2(db.settings.late_payment_fine || 0);
      if (amt <= 0) return;
      var existingPost = db.ledger.filter(function (e) {
        return e.category === 'LATE_FINE' && e.meeting_id === meeting.id && e.member_id === r.member.id && !isReversed(db, e.id);
      })[0];
      if (existingPost) return; /* idempotent */
      post(db, { date: meeting.date, meeting_id: meeting.id, member_id: r.member.id, category: 'LATE_FINE',
        desc: 'Delayed payment fine ' + meeting.ref + ' ' + r.member.m_no + ' (short ' + r.outstanding + ')',
        lines: [{ account: acc('FINES_RECEIVABLE', r.member.id), debit: amt },
                { account: 'FINE_INCOME', credit: amt }], by: by || 'system' });
    });
  }
  function closeMeeting(db, meetingId, minutes, resolutions, role) {
    guard(role, 'close_meeting');
    var m = db.meetings.filter(function (x) { return x.id === meetingId; })[0];
    if (!m) throw new Error('Meeting not found');
    if (m.status === 'closed') throw new Error('Meeting is already closed — permanent record');
    if (m.status === 'open') syncLatePaymentFines(db, m, role);
    m.status = 'closed'; m.minutes = minutes || ''; m.resolutions = resolutions || '';
    m.closed_at = new Date().toISOString();
    return m;
  }
  function attendanceStats(db, memberId) {
    var rows = db.attendance.filter(function (a) { return a.member_id === memberId; });
    var s = { scheduled: 0, present: 0, apology: 0, absent: 0, late: 0 };
    rows.forEach(function (a) {
      s.scheduled++;
      if (a.status === 'P') s.present++; else if (a.status === 'A') s.apology++;
      else if (a.status === 'X') s.absent++; else if (a.status === 'L') s.late++;
    });
    s.pct = s.scheduled ? r2((100 * (s.present + s.late)) / s.scheduled) : 0;
    return s;
  }

  /* ---------- payment categories (NO loan categories by design) ---------- */
  var PAY_CATEGORIES = {
    NORMAL_SAVINGS:  { label: 'Monthly group savings',        debit: ['CASH', 'MPESA'], credit: 'MEMBER_SAVINGS',  perMember: true },
    SPECIAL_SAVINGS: { label: 'Special savings',              debit: ['CASH', 'MPESA'], credit: 'SPECIAL_SAVINGS', perMember: true },
    MGR:             { label: 'Merry-go-round contribution',  debit: ['CASH', 'MPESA'], credit: 'MGR_FUND',        perMember: true },
    MGR_DOUBLE:      { label: 'Delayed merry-go-round — DOUBLE penalty', debit: ['CASH', 'MPESA'], credit: 'MGR_FUND', perMember: true },
    FINE:            { label: 'Attendance fine payment',      debit: ['CASH', 'MPESA'], credit: 'FINES_RECEIVABLE', perMember: true },
    LATE_FINE:       { label: 'Delayed payment fine',         debit: ['CASH', 'MPESA'], credit: 'FINES_RECEIVABLE', perMember: true },
    WELFARE:         { label: 'Welfare contribution',         debit: ['CASH', 'MPESA'], credit: 'WELFARE',         perMember: true },
    OTHER:           { label: 'Other approved payment',       debit: ['CASH', 'MPESA'], credit: 'MEMBER_SAVINGS',  perMember: true }
  };
  function paymentNo(db) { return 'RCP-' + String(db.payments.length + 1).padStart(5, '0'); }
  function recordPayment(db, o, role) {
    guard(role, 'record_payments');
    var cat = PAY_CATEGORIES[o.category];
    if (!cat) throw new Error('Unknown payment category');
    if (!(o.amount > 0)) throw new Error('Amount must be positive');
    var dup = db.payments.filter(function (p) {
      return p.status === 'active' && p.member_id === o.member_id && p.category === o.category &&
             r2(p.amount) === r2(o.amount) && p.date === (o.date || todayISO()) &&
             (p.reference || '') === (o.reference || '') &&
             (p.meeting_id || null) === (o.meeting_id || null);
    })[0];
    if (dup) throw new Error('DUPLICATE PAYMENT BLOCKED: identical entry exists (' + dup.txn_no + ')');
    var method = o.method || 'Cash';
    var debitAccount = (method === 'M-Pesa' || method === 'Bank transfer') ? 'MPESA' : 'CASH';
    /* MGR and delayed-MGR money both sit in the GROUP merry-go-round fund */
    var creditAccount = (o.category === 'MGR' || o.category === 'MGR_DOUBLE') ? 'MGR_FUND' : acc(cat.credit, o.member_id);
    var entry = post(db, {
      date: o.date || todayISO(), meeting_id: o.meeting_id || null, member_id: o.member_id,
      category: o.category, desc: cat.label + ' — ' + method + (o.reference ? ' ref ' + o.reference : ''),
      lines: [{ account: debitAccount, debit: o.amount },
              { account: creditAccount, credit: o.amount }],
      by: o.by || role
    });
    var p = {
      id: uid('PAY'), txn_no: paymentNo(db), ledger_id: entry.id, date: o.date || todayISO(),
      meeting_id: o.meeting_id || null, member_id: o.member_id, category: o.category,
      amount: r2(o.amount), method: method, reference: o.reference || '',
      received_by: o.by || role, remarks: o.remarks || '', status: 'active',
      verified: method !== 'M-Pesa' ? 'manual' : 'unverified-mpesa', created_at: new Date().toISOString()
    };
    db.payments.push(p);
    return p;
  }

  /* ---------- merry-go-round (the group's core product) ---------- */
  function mgrConfig(db, o, role) {
    guard(role, 'manage_settings');
    db.mgr.config = {
      amount: r2(o.amount), frequency: o.frequency || 'Monthly',
      members: o.members || [], order: o.order || [], start_date: o.start_date || todayISO(),
      payout_day: o.payout_day || '', active: true, next_override: null
    };
    return db.mgr.config;
  }
  /* next beneficiary = latest spin winner (if still unpaid this cycle), else rotation order */
  function mgrNextBeneficiary(db) {
    var c = db.mgr.config; if (!c || !c.order || !c.order.length) return null;
    var cyc = currentCycle(db);
    var paid = db.mgr.payouts.filter(function (p) { return p.cycle === cyc; }).map(function (p) { return p.member_id; });
    if (c.next_override && paid.indexOf(c.next_override) === -1) return c.next_override;
    for (var i = 0; i < c.order.length; i++) {
      var idx = (cyc - 1 + i) % c.order.length;
      var cand = c.order[idx];
      if (paid.indexOf(cand) === -1) return cand;
    }
    return null;
  }
  function currentCycle(db) {
    var c = db.mgr.config;
    var n = db.mgr.payouts.length, N = (c && c.order && c.order.length) || 1;
    return Math.floor(n / N) + 1; /* cycle still being filled */
  }
  function recordMgrPayout(db, memberId, amount, date, role) {
    guard(role, 'record_payments');
    var c = db.mgr.config;
    if (!c || !c.order || !c.order.length) throw new Error('Merry-go-round not configured');
    if (db.mgr.payouts.some(function (p) { return p.member_id === memberId && p.cycle === currentCycle(db); }))
      throw new Error('Member already received this cycle payout — cannot receive twice');
    var pot = r2(c.amount * c.order.length);
    var net = r2(amount || pot);
    post(db, { date: date || todayISO(), member_id: memberId, category: 'MGR_PAYOUT',
      desc: 'Merry-go-round payout cycle ' + currentCycle(db),
      lines: [{ account: 'MGR_FUND', debit: net }, { account: 'CASH', credit: net }], by: role });
    var p = { id: uid('MGP'), member_id: memberId, cycle: currentCycle(db), amount: net, date: date || todayISO(), by: role };
    db.mgr.payouts.push(p);
    if (c.next_override === memberId) c.next_override = null;
    return p;
  }
  function mgrOutstanding(db, memberId) {
    var c = db.mgr.config; if (!c || !c.order || !c.order.length) return 0;
    var expected = c.amount * currentCycle(db);
    var paid = 0;
    db.payments.forEach(function (p) {
      if (p.member_id === memberId && p.status === 'active' && (p.category === 'MGR' || p.category === 'MGR_DOUBLE')) paid += p.amount;
    });
    return r2(Math.max(0, expected - paid));
  }
  /* 7. double penalty: a delayed MGR member pays TWICE the agreed amount into the MGR fund */
  function mgrDoublePenaltyAmount(db, memberId) {
    var c = db.mgr.config; if (!c) return 0;
    var outst = mgrOutstanding(db, memberId);
    return r2(Math.max(0, outst) * 2);
  }

  /* ---------- 8. SPIN decides the next MERRY-GO-ROUND beneficiary ---------- */
  function spinEligible(db, opts) {
    opts = opts || {};
    var cyc = currentCycle(db);
    var paidThisCycle = {};
    db.mgr.payouts.filter(function (p) { return p.cycle === cyc; }).forEach(function (p) { paidThisCycle[p.member_id] = true; });
    return db.members.filter(function (m) {
      if (m.status !== 'Active') return false;
      if (paidThisCycle[m.id]) return false;                    /* already benefited this cycle */
      if (opts.excludeIds && opts.excludeIds.indexOf(m.id) !== -1) return false;
      return true;
    });
  }
  function cryptoRandomInt(max) {
    var g = (typeof crypto !== 'undefined' && crypto.getRandomValues) ? crypto : null;
    if (!g && typeof require !== 'undefined') { try { g = require('crypto'); } catch (e) {} }
    if (g && g.getRandomValues) {
      var a = new Uint32Array(1); g.getRandomValues(a);
      return a[0] % max;
    }
    if (g && g.randomBytes) return g.randomBytes(4).readUInt32BE(0) % max;
    throw new Error('No secure RNG available');
  }
  function spinSelect(db, meetingId, by, role, opts) {
    guard(role, 'spin_beneficiary');
    var eligible = spinEligible(db, opts);
    if (!eligible.length) throw new Error('No eligible members to spin');
    var idx = cryptoRandomInt(eligible.length);
    var winner = eligible[idx];
    var mtg = db.meetings.filter(function (m) { return m.id === meetingId; })[0];
    var rec = {
      id: uid('SPIN'), at: new Date().toISOString(), meeting_id: meetingId,
      meeting_ref: mtg ? mtg.ref : null, date: todayISO(), by: by,
      purpose: 'MERRY_GO_ROUND_BENEFICIARY',
      eligible: eligible.map(function (m) { return m.id; }),
      winner: winner.id, rng: 'crypto.getRandomValues (CSPRNG)', nonce: uid('N')
    };
    db.spin_history.push(rec);
    /* the spun member becomes the NEXT merry-go-round beneficiary */
    if (db.mgr.config) db.mgr.config.next_override = winner.id;
    db.audit.push({ id: uid('AUD'), at: rec.at, action: 'SPIN', meeting: rec.meeting_ref, winner: winner.m_no, by: by, nonce: rec.nonce, purpose: rec.purpose });
    return { record: rec, winner: winner, eligible: eligible };
  }

  /* ---------- investments & expenses ---------- */
  function addInvestment(db, o, role) {
    guard(role, 'record_investments');
    var inv = {
      id: uid('INV'), ref: 'INV-' + String(db.investments.length + 1).padStart(3, '0'),
      desc: o.desc, amount: r2(o.amount), date: o.date || todayISO(), source: o.source || 'CASH',
      expected_return: r2(o.expected_return || 0), actual_return: r2(o.actual_return || 0),
      status: o.status || 'proposed', docs: o.docs || '', category: o.category || 'Business'
    };
    if (inv.status === 'active') {
      var srcAcc = inv.source === 'MPESA' ? 'MPESA' : 'CASH';
      var pot = groupBalance(db, srcAcc);
      if (pot < inv.amount) throw new Error('Insufficient available cash (' + pot + ') for investment of ' + inv.amount);
      post(db, { date: inv.date, category: 'INVESTMENT', desc: 'Investment ' + inv.ref + ': ' + inv.desc,
        lines: [{ account: 'INVESTMENTS', debit: inv.amount },
                { account: srcAcc, credit: inv.amount }], by: role });
      inv.ledger_id = db.ledger[db.ledger.length - 1].id;
    }
    db.investments.push(inv); return inv;
  }
  function addExpense(db, o, role) {
    guard(role, 'record_expenses');
    var ex = {
      id: uid('EXP'), ref: 'EXP-' + String(db.expenses.length + 1).padStart(3, '0'),
      desc: o.desc, category: o.category || 'Operations', amount: r2(o.amount),
      date: o.date || todayISO(), source: o.source || 'CASH', payee: o.payee || '',
      receipt: o.receipt || '', approved_by: o.approved_by || role
    };
    var srcAcc2 = ex.source === 'MPESA' ? 'MPESA' : 'CASH';
    var pot2 = groupBalance(db, srcAcc2);
    if (pot2 < ex.amount) throw new Error('Insufficient available cash (' + pot2 + ') for expense of ' + ex.amount);
    post(db, { date: ex.date, category: 'EXPENSE', desc: ex.category + ': ' + ex.desc + ' → ' + ex.payee,
      lines: [{ account: 'GROUP_EXPENSES', debit: ex.amount },
              { account: srcAcc2, credit: ex.amount }], by: role });
    ex.ledger_id = db.ledger[db.ledger.length - 1].id;
    db.expenses.push(ex); return ex;
  }

  /* ---------- 10. share-out of savings ---------- */
  /* The group may resolve to share a fixed amount to every member with savings
     on a certain date — e.g. KSh 500 each on 15 December. */
  function configureShareOut(db, o, role) {
    guard(role, 'configure_shareout');
    db.shareout_config = {
      share_amount: r2(o.share_amount), share_date: o.share_date || '',
      approved_by: role, approved_at: new Date().toISOString(), status: 'scheduled'
    };
    db.audit.push({ id: uid('AUD'), at: new Date().toISOString(), action: 'SHARE_OUT_CONFIGURED',
      reason: 'KSh ' + db.shareout_config.share_amount + ' per member on ' + db.shareout_config.share_date, by: role });
    return db.shareout_config;
  }
  function executeShareOut(db, date, by, role) {
    guard(role, 'execute_shareout');
    var cfg = db.shareout_config;
    if (!cfg || !cfg.share_amount) throw new Error('Share-out not configured');
    var amt = r2(cfg.share_amount);
    var recipients = db.members.filter(function (m) {
      if (m.status === 'Removed' || m.status === 'Deceased') return false;
      return accBalance(db, 'MEMBER_SAVINGS', m.id) > 0;
    });
    if (!recipients.length) throw new Error('No member has savings to share');
    var total = r2(amt * recipients.length);
    var cash = groupBalance(db, 'CASH') + groupBalance(db, 'MPESA');
    if (cash < total) throw new Error('Insufficient available cash (' + cash + ') to share ' + total);
    var useAcct = groupBalance(db, 'CASH') >= total ? 'CASH' : 'MPESA';
    recipients.forEach(function (m) {
      post(db, { date: date || cfg.share_date || todayISO(), member_id: m.id, category: 'SHARE_OUT',
        desc: 'Share-out ' + amt + ' to ' + m.m_no,
        lines: [{ account: acc('MEMBER_SAVINGS', m.id), debit: amt },
                { account: useAcct, credit: amt }], by: by || role });
    });
    var rec = { id: uid('SHO'), date: date || cfg.share_date || todayISO(), per_member: amt,
      members: recipients.length, total: total, by: by || role, config: cfg };
    db.shareouts.push(rec);
    cfg.status = 'executed';
    db.audit.push({ id: uid('AUD'), at: new Date().toISOString(), action: 'SHARE_OUT',
      reason: total + ' shared to ' + recipients.length + ' members', by: by || role });
    return rec;
  }
  function shareOutPreview(db) {
    var cfg = db.shareout_config;
    if (!cfg || !cfg.share_amount) return { configured: false };
    var recipients = db.members.filter(function (m) {
      if (m.status === 'Removed' || m.status === 'Deceased') return false;
      return accBalance(db, 'MEMBER_SAVINGS', m.id) > 0;
    });
    return { configured: true, share_amount: cfg.share_amount, share_date: cfg.share_date,
      recipients: recipients.length, total: r2(cfg.share_amount * recipients.length),
      status: cfg.status, available_cash: r2(groupBalance(db, 'CASH') + groupBalance(db, 'MPESA')) };
  }

  /* ---------- derived financial position ---------- */
  function financialPosition(db) {
    var savings = 0, welfare = 0, special = 0, i;
    db.members.forEach(function (m) {
      savings += accBalance(db, 'MEMBER_SAVINGS', m.id);
      welfare += accBalance(db, 'WELFARE', m.id);
      special += accBalance(db, 'SPECIAL_SAVINGS', m.id);
    });
    var mgr = groupBalance(db, 'MGR_FUND');
    var finesRecv = 0;
    db.members.forEach(function (m) { finesRecv += accBalance(db, 'FINES_RECEIVABLE', m.id); });
    var cash = groupBalance(db, 'CASH'), mpesa = groupBalance(db, 'MPESA');
    var investments = groupBalance(db, 'INVESTMENTS');
    var expenses = groupBalance(db, 'GROUP_EXPENSES');
    var fineInc = groupBalance(db, 'FINE_INCOME');
    return {
      savings: r2(savings), special: r2(special), mgr_fund: r2(mgr), welfare: r2(welfare),
      fines_receivable: r2(finesRecv),
      cash: r2(cash), mpesa: r2(mpesa), investments: r2(investments),
      expenses: r2(expenses), fine_income: r2(fineInc),
      available_cash: r2(cash + mpesa),
      total_position: r2(cash + mpesa + investments + finesRecv)
    };
  }

  /* ---------- member statement ---------- */
  function memberStatement(db, memberId) {
    var m = db.members.filter(function (x) { return x.id === memberId; })[0];
    var att = attendanceStats(db, memberId);
    var finesImposed = 0, finesPaid = 0;
    db.attendance.filter(function (a) { return a.member_id === memberId; }).forEach(function (a) { finesImposed += a.waived ? 0 : a.fine_amount; });
    db.ledger.forEach(function (e) {
      if (e.category === 'LATE_FINE' && e.member_id === memberId && !isReversed(db, e.id)) finesImposed += e.lines[0].debit;
    });
    db.payments.filter(function (p) { return p.member_id === memberId && p.status === 'active' && (p.category === 'FINE' || p.category === 'LATE_FINE'); }).forEach(function (p) { finesPaid += p.amount; });
    var savings = accBalance(db, 'MEMBER_SAVINGS', memberId);
    var special = accBalance(db, 'SPECIAL_SAVINGS', memberId);
    var mgrPaid = 0, mgrDoublePaid = 0;
    db.payments.filter(function (p) { return p.member_id === memberId && p.category === 'MGR' && p.status === 'active'; }).forEach(function (p) { mgrPaid += p.amount; });
    db.payments.filter(function (p) { return p.member_id === memberId && p.category === 'MGR_DOUBLE' && p.status === 'active'; }).forEach(function (p) { mgrDoublePaid += p.amount; });
    var txns = [];
    db.payments.filter(function (p) { return p.member_id === memberId; }).forEach(function (p) {
      txns.push({ date: p.date, type: PAY_CATEGORIES[p.category] ? PAY_CATEGORIES[p.category].label : p.category, amount: p.amount, ref: p.txn_no, status: p.status });
    });
    db.shareouts.forEach(function (s) {
      var got = db.ledger.some(function (e) { return e.category === 'SHARE_OUT' && e.member_id === memberId && e.date === s.date && !isReversed(db, e.id); });
      if (got) txns.push({ date: s.date, type: 'Share-out received', amount: -s.per_member, ref: s.id, status: 'active' });
    });
    txns.sort(function (a, b) { return a.date < b.date ? 1 : -1; });
    return {
      member: m, attendance: att,
      savings_total: r2(savings), special_total: r2(special), mgr_total: r2(mgrPaid + mgrDoublePaid),
      mgr_outstanding: mgrOutstanding(db, memberId), mgr_double_due: mgrDoublePenaltyAmount(db, memberId),
      fines_imposed: r2(finesImposed), fines_paid: r2(finesPaid), fines_outstanding: r2(finesImposed - finesPaid),
      transactions: txns
    };
  }

  /* ---------- dashboard ---------- */
  function dashboard(db) {
    var pos = financialPosition(db);
    var active = db.members.filter(function (m) { return m.status === 'Active'; }).length;
    var nextMeeting = db.meetings.filter(function (m) { return m.status === 'open' && m.date >= todayISO(); })
      .sort(function (a, b) { return a.date < b.date ? -1 : 1; })[0];
    var lastM = db.meetings.filter(function (m) { return m.status === 'closed'; }).sort(function (a, b) { return a.date < b.date ? 1 : -1; })[0];
    var lastPct = 0;
    if (lastM) {
      var rows = db.attendance.filter(function (a) { return a.meeting_id === lastM.id; });
      lastPct = rows.length ? r2(100 * rows.filter(function (a) { return a.status === 'P' || a.status === 'L'; }).length / rows.length) : 0;
    }
    var finesImposed = 0, finesPaidT = 0;
    db.attendance.forEach(function (a) { if (!a.waived) finesImposed += a.fine_amount; });
    db.ledger.forEach(function (e) { if (e.category === 'LATE_FINE' && !isReversed(db, e.id)) finesImposed += e.lines[0].debit; });
    db.payments.forEach(function (p) { if ((p.category === 'FINE' || p.category === 'LATE_FINE') && p.status === 'active') finesPaidT += p.amount; });
    var normalPaid = 0, mgrCollected = 0, mgrDouble = 0;
    db.payments.forEach(function (p) {
      if (p.status !== 'active') return;
      if (p.category === 'NORMAL_SAVINGS') normalPaid += p.amount;
      if (p.category === 'MGR') mgrCollected += p.amount;
      if (p.category === 'MGR_DOUBLE') mgrDouble += p.amount;
    });
    var expenses = db.expenses.reduce(function (s, e) { return s + e.amount; }, 0);
    var nextB = mgrNextBeneficiary(db);
    var cyc = currentCycle(db);
    var paidThisCycle = db.mgr.payouts.filter(function (p) { return p.cycle === cyc; }).length;
    return {
      members_total: db.members.length, members_active: active,
      next_meeting: nextMeeting ? nextMeeting.date + ' ' + nextMeeting.venue : null,
      last_attendance_pct: lastPct,
      savings_total: pos.savings, normal_collected: r2(normalPaid),
      mgr_collected: r2(mgrCollected), mgr_double_collected: r2(mgrDouble), mgr_pot: pos.mgr_fund,
      mgr_cycle: cyc, mgr_paid_this_cycle: paidThisCycle,
      mgr_next_beneficiary: nextB ? memberNameById(db, nextB) : null,
      fines_imposed: r2(finesImposed), fines_collected: r2(finesPaidT), fines_outstanding: r2(finesImposed - finesPaidT),
      investment_value: pos.investments, expenses_total: r2(expenses),
      available_cash: pos.available_cash, position: pos,
      shareout: shareOutPreview(db)
    };
  }
  function memberNameById(db, id) {
    var m = db.members.filter(function (x) { return x.id === id; })[0];
    return m ? m.full_name : null;
  }

  /* ---------- contributions expected/owed per meeting ---------- */
  function contributionRegister(db, meeting) {
    return db.members.filter(function (m) { return m.status === 'Active'; }).map(function (m) {
      var expected = r2(db.settings.contribution_amount);
      var paid = 0, mgrPaid = 0;
      db.payments.filter(function (p) {
        return p.member_id === m.id && p.status === 'active' && p.meeting_id === meeting.id;
      }).forEach(function (p) {
        if (p.category === 'NORMAL_SAVINGS') paid += p.amount;
        if (p.category === 'MGR') mgrPaid += p.amount;
      });
      return { member: m, expected: expected, paid: r2(paid), mgr_paid: r2(mgrPaid),
        outstanding: r2(Math.max(0, expected - paid)), carried: r2(paid - expected) };
    });
  }
  function carriedForward(db, memberId, upToMeetingIdx) {
    var owed = 0;
    db.meetings.slice(0, upToMeetingIdx === undefined ? db.meetings.length : upToMeetingIdx).forEach(function (mtg) {
      if (mtg.status !== 'closed') return;
      contributionRegister(db, mtg).forEach(function (r) {
        if (r.member.id === memberId && r.outstanding > 0) owed += r.outstanding;
      });
    });
    return r2(owed);
  }

  /* ---------- CSV export ---------- */
  function toCSV(rows) {
    return rows.map(function (r) {
      return r.map(function (c) {
        c = c === null || c === undefined ? '' : String(c);
        return /[",\n]/.test(c) ? '"' + c.replace(/"/g, '""') + '"' : c;
      }).join(',');
    }).join('\n');
  }

  /* ---------- seed: realistic sample group ---------- */
  function seedDB() {
    var p_seedPwd = 'Seed-' + Math.random().toString(36).slice(2, 14) + '!Aa';
    var db = {
      version: 3, app: 'CHAMA CHETU', created_at: new Date().toISOString(),
      settings: {
        group_name: 'My Chama', logo: '', reg_no: '',
        contact: 'P.O. Box 1247-00200, Nairobi | +254 7XX XXX XXX',
        currency: 'KES', currency_symbol: 'KSh',
        meeting_frequency: 'Monthly', contribution_amount: 500, mgr_contribution: 300,
        fine_absence: 200, fine_late: 50, fine_apology: 0,
        late_payment_fine: 100,
        member_prefix: 'MEM', meeting_prefix: 'MTG',
        spin_exclude_benefited: true,
        financial_year_start: '01-01'
      },
      users: (function(){
        /* seed helper for the OFFLINE unit-test suite only; the production
           server never calls seedDB and creates accounts via /api/setup.
           Password is generated at runtime - no credential literals exist. */
        return [
          { id: 'U1', username: 'admin', full_name: 'System Administrator', role: 'admin', pin_hash: pinHash(p_seedPwd, 'admin'), status: 'active', phone: '' },
          { id: 'U2', username: 'chair', full_name: 'Chairperson (seed)', role: 'chairperson', pin_hash: pinHash(p_seedPwd, 'chair'), status: 'active', phone: '', member_id: 'MEM1' },
          { id: 'U3', username: 'secretary', full_name: 'Secretary (seed)', role: 'secretary', pin_hash: pinHash(p_seedPwd, 'secretary'), status: 'active', phone: '', member_id: 'MEM2' },
          { id: 'U4', username: 'treasurer', full_name: 'Treasurer (seed)', role: 'treasurer', pin_hash: pinHash(p_seedPwd, 'treasurer'), status: 'active', phone: '', member_id: 'MEM3' },
          { id: 'U5', username: 'member', full_name: 'Member (seed)', role: 'member', pin_hash: pinHash(p_seedPwd, 'member'), status: 'active', phone: '', member_id: 'MEM4' }
        ]; })(),
      members: [], meetings: [], attendance: [], payments: [],
      investments: [], expenses: [], ledger: [], audit: [], spin_history: [],
      mgr: { config: null, payouts: [] }, shareouts: [], shareout_config: null,
      notifications: []
    };
    var names = [
      ['Grace Wanjiku', 'F', 'Kiambu'], ['Mary Achieng', 'F', 'Kisumu'],
      ['Esther Mutheu', 'F', 'Machakos'], ['Joseph Kimani', 'M', 'Nyeri'],
      ['Agnes Njeri', 'F', 'Muranga'], ['Peter Otieno', 'M', 'Siaya'],
      ['Faith Chebet', 'F', 'Eldoret'], ['Samuel Kariuki', 'M', 'Kiambu'],
      ['Rose Wambui', 'F', 'Nakuru'], ['Daniel Mwangi', 'M', 'Kiambu'],
      ['Lucy Nyambura', 'F', 'Kiambu'], ['Hellen Atieno', 'F', 'Kisumu']
    ];
    names.forEach(function (n, i) {
      db.members.push({
        id: 'MEM' + (i + 1), m_no: 'MEM' + String(i + 1).padStart(3, '0'),
        full_name: n[0], gender: n[1], village: n[2], phone: '+2547' + String(10000000 + i * 11111111).slice(0, 8),
        id_no: String(20000000 + i * 137), status: 'Active', joined: '2026-01-1' + (i % 9 + 1),
        next_of_kin: '', remarks: '', photo: null, registered_by: 'admin'
      });
    });
    db._seedPwd = p_seedPwd;
    return db;
  }

  return {
    Storage: Storage, ACCOUNTS: ACCOUNTS, ROLES: ROLES, PERMISSIONS: PERMISSIONS,
    uid: uid, todayISO: todayISO, r2: r2, pinHash: pinHash,
    acc: acc, accBalance: accBalance, groupBalance: groupBalance,
    post: post, reverse: reverse, isReversed: isReversed,
    can: can, guard: guard, login: login,
    addMember: addMember, editMember: editMember, removeMember: removeMember,
    importMembers: importMembers, setUserRole: setUserRole, addUser: addUser,
    createMeeting: createMeeting, markAttendance: markAttendance,
    waiveFine: waiveFine, closeMeeting: closeMeeting, attendanceStats: attendanceStats,
    PAY_CATEGORIES: PAY_CATEGORIES, recordPayment: recordPayment,
    mgrConfig: mgrConfig, mgrNextBeneficiary: mgrNextBeneficiary, currentCycle: currentCycle,
    recordMgrPayout: recordMgrPayout, mgrOutstanding: mgrOutstanding, mgrDoublePenaltyAmount: mgrDoublePenaltyAmount,
    spinEligible: spinEligible, spinSelect: spinSelect, cryptoRandomInt: cryptoRandomInt,
    addInvestment: addInvestment, addExpense: addExpense,
    configureShareOut: configureShareOut, executeShareOut: executeShareOut, shareOutPreview: shareOutPreview,
    financialPosition: financialPosition, memberStatement: memberStatement,
    dashboard: dashboard, contributionRegister: contributionRegister, carriedForward: carriedForward,
    toCSV: toCSV, seedDB: seedDB
  };
});
