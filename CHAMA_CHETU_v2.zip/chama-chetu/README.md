# CHAMA CHETU v2 — Secure Multi-User Community Savings & Merry-Go-Round System

Production upgrade of CHAMA CHETU: all demo accounts removed, real authentication on a
secure backend, central database, server-enforced roles, audited financial transactions,
and an offline-capable frontend. **The system is not live until you deploy it and complete
the protected first-administrator setup — no credentials ship in this package.**

## What changed from the demo build (summary)

| Area | Demo build (v3 standalone) | v2 (this package) |
|---|---|---|
| Accounts | 5 hardcoded demo PINs in the HTML | Zero credentials shipped. First admin created via one-time `SETUP_TOKEN`; admin creates all real users; forced password change on first login |
| Auth | JavaScript check in the browser | bcrypt password hashes verified server-side; HttpOnly+SameSite session cookies with expiry; lockout after 5 failed logins; rate limiting |
| Data | localStorage on each phone | Central SQLite database (server); multi-device access; optimistic versioning prevents silent overwrites |
| Permissions | UI buttons hidden per role | Every mutation re-checked **on the server**; members receive only their own financial rows |
| Audit | In-browser array | Append-only server `audit_log` + `login_audit` tables |
| Backups | localStorage JSON | Admin-only server backup endpoint (no password hashes exported); restore keeps an automatic rollback snapshot |

All v3 business features are preserved: dashboard, members (+edit/remove, Excel import),
meetings, P/A/X/L attendance with automatic fines, delayed-payment fines, combined
monthly + merry-go-round contribution register, MGR rotation with spinning-wheel
beneficiary selection (server-side CSPRNG), double penalty, share-out, investments,
expenses, 12 reports, audit trail, backup/restore, mobile-first green/gold UI.

## Quick start (local test, 5 minutes)

```bash
# 1. install (Node 18+; free, open-source dependencies only)
npm install

# 2. configure secrets (never commit .env)
cp .env.example .env
# then edit .env:
#   SESSION_SECRET  ->  openssl rand -hex 32
#   SETUP_TOKEN     ->  openssl rand -hex 24

# 3. run
npm start                     # http://localhost:3000

# 4. open the app in a browser — the SETUP screen appears.
#    Paste the SETUP_TOKEN from .env, choose the administrator
#    username and a strong password (min 8 chars), set group name.
#    This is the ONLY account creation that uses the token; after
#    setup, further accounts are created by the admin in Settings.

# 5. run the automated tests (72 checks total)
npm test
```

## User accounts (created by your Administrator, never shipped)

| Role | Created by | Powers (all enforced server-side) |
|---|---|---|
| Administrator | One-time protected setup | Everything: users, roles, settings, members, backup/restore, audit |
| Chairperson | Admin (Settings → + Add user) | Approvals/waivers, meetings oversight, spin, settings, corrections |
| Secretary | Admin | Member registration, meetings, attendance, minutes |
| Treasurer | Admin | Payments, expenses, investments, MGR payouts, reports |
| Ordinary Member | Admin (linked to a member record) | Own records only — server strips everyone else's financial data |

New users receive a temporary password and **must set their own at first sign-in**.
Admins can reset passwords (which ends the user's sessions), disable users, and change
roles — all audited. The last administrator cannot be demoted or disabled.

## Repository layout

```
package.json            dependencies + start/test scripts
.env.example            server configuration template (no real secrets)
server/server.js        Express backend: auth, sessions, CSRF, RBAC, transactions, audit
server/schema.md        database schema + PostgreSQL upgrade path + backup notes
public/index.html       the complete offline-capable app (bundled SheetJS, no CDNs)
public/app_api.js       frontend application layer (API-connected, offline queue)
public/sw.js            service worker: app-shell caching for offline use
src/core.js             financial engine (double-entry ledger, fines, MGR, share-out)
tests/test.js           32 engine unit tests (financial rules, ledger integrity)
tests/server.test.js    21 server integration tests (auth, RBAC, security, money)
scripts/migrate-legacy.js   validates + cleans a legacy demo-build backup before import
docs/SECURITY.md        vulnerabilities found & fixed; operator responsibilities
docs/MIGRATION.md       migration of genuine records + rollback procedure
docs/DEPLOYMENT.md      hosting, HTTPS, env vars, first-admin setup, production checklist
docs/TEST-REPORT.md     actual test-suite output from the delivered build
```

## Offline behaviour (honest limits)

- The app shell, registers and reports work offline after first load (service worker).
- Actions recorded while offline are held in a **local queue** and replayed to the server
  when connectivity returns. The server re-validates every queued action (RBAC, duplicates,
  balances) — offline **cannot bypass authorization**. Conflicting/overwritten writes are
  rejected with HTTP 409 and the screen refreshes from the server's version.
- Multi-device live sharing requires connectivity; it is the server, not the phones, that
  holds the single truth.

## Security & operational documents

Read `docs/SECURITY.md` (what was vulnerable and what changed), `docs/DEPLOYMENT.md`
(free hosting paths, HTTPS, setup, checklist, backup/DR), `docs/MIGRATION.md` (bringing in
genuine old records safely), and `docs/TEST-REPORT.md` (what was actually tested).

## Known external configuration still required before going live

1. A host that runs Node (see DEPLOYMENT.md — free tiers exist) — **Netlify static hosting
   alone cannot run this backend**.
2. `SESSION_SECRET` and `SETUP_TOKEN` environment variables on that host.
3. HTTPS (provided automatically by the recommended hosts).
4. The protected first-administrator setup (section above).
5. Optional later: Safaricom Daraja credentials for automatic M-Pesa verification
   (server env only; the app already records M-Pesa codes manually).
