
/* ==================== CHAMA CHETU v2 — API-connected app layer ====================
   All authentication and every financial mutation now go through the backend API.
   No demo credentials, no demo seed data, no client-side authority over money. */
var DB = null, SESS = null, CUR = { screen: 'dashboard', member: null, meeting: null, memberTab: 'personal' }, IDSEQ = 0;
var QUEUE = [];
try { QUEUE = JSON.parse(localStorage.getItem('cc_queue') || '[]'); } catch (e) { QUEUE = []; }
function $(id){ return document.getElementById(id); }
function fmt(n){ return 'KSh ' + Number(n||0).toLocaleString('en-KE', {maximumFractionDigits:2}); }
function esc(s){ return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
function memberName(id){ var m = DB.members.filter(function(x){return x.id===id;})[0]; return m ? m.full_name : '—'; }
function can(action){ return SESS && Core.can(SESS.user.role, action); }
function catLabel(c){ var p = Core.PAY_CATEGORIES[c]; return p ? p.label : c; }
function toast(msg, kind){
  var t = document.createElement('div'); t.className = 'toast ' + (kind||''); t.textContent = msg;
  document.body.appendChild(t); setTimeout(function(){ t.remove(); }, 3400);
}
function persistQueue(){ try { localStorage.setItem('cc_queue', JSON.stringify(QUEUE)); } catch(e){} }
function renderSyncBar(){
  var el = $('syncbar'); if (!el) return;
  el.textContent = QUEUE.length ? ('⏳ ' + QUEUE.length + ' change(s) queued offline — will sync securely when online')
    : '🔗 Live: all records on the secure central server';
}
window.addEventListener('online', replayQueue);

/* ---------- API helpers ---------- */
async function api(method, path, body, extra){
  var opt = { method: method, headers: Object.assign({'Content-Type':'application/json'}, extra||{}) };
  if (body !== undefined) opt.body = JSON.stringify(body);
  if (SESS && SESS.csrf) opt.headers['X-CSRF-Token'] = SESS.csrf;
  var r = await fetch(path, opt);
  var j = null; try { j = await r.json(); } catch(e){}
  if (r.status === 401 && !/\/(login|setup)/.test(path)) { showLogin('Session expired — please sign in again.'); throw new Error('session-expired'); }
  return { status: r.status, json: j || {} };
}
/* the single mutation path: server-side RBAC + transaction + idempotency + version check */
async function ACT(action, payload, silent){
  var key = action + ':' + Date.now() + ':' + (++IDSEQ) + ':' + Math.random().toString(36).slice(2,8);
  if (!navigator.onLine){ QUEUE.push({action:action, payload:payload, idempotency_key:key, base_version:DB.version}); persistQueue(); renderSyncBar(); toast('Offline — change queued securely on this device', 'ok'); return { ok:false, offline:true }; }
  try {
    var r = await api('POST', '/api/action', { action: action, payload: payload, idempotency_key: key, base_version: DB.version });
    if (r.status === 409 && r.json.code === 'VERSION_CONFLICT'){
      await refreshState(); toast('Records were updated by another official — screen refreshed, nothing overwritten', 'ok');
      nav(CUR.screen); return { ok:false };
    }
    if (!r.ok){ toast(r.json.error || 'Action failed', 'err'); return { ok:false }; }
    DB = r.json.state; DB.version = r.json.version;
    if (!silent) toast('Saved on the secure server ✔', 'ok');
    nav(CUR.screen); return { ok:true, result:r.json.result };
  } catch(e){
    if (e.message === 'session-expired') return { ok:false };
    QUEUE.push({action:action, payload:payload, idempotency_key:key, base_version:DB.version}); persistQueue(); renderSyncBar();
    toast('Network problem — change queued, will sync when online', 'ok'); return { ok:false };
  }
}
async function replayQueue(){
  if (!QUEUE.length || !SESS) return;
  var remaining = [];
  for (var i = 0; i < QUEUE.length; i++){
    var op = QUEUE[i];
    try {
      var r = await api('POST', '/api/action', op);
      if (r.ok && r.json && r.json.ok){ DB = r.json.state; DB.version = r.json.version; }
      else if (r.status === 409){ await refreshState(); }
      else if (r.status === 400) { toast('Queued change rejected by server: ' + (r.json.error||''), 'err'); }
      else remaining.push(op);
    } catch(e){ remaining.push(op); }
  }
  QUEUE = remaining; persistQueue(); renderSyncBar(); if (SESS) nav(CUR.screen);
}
async function refreshState(){
  var r = await api('GET', '/api/state');
  if (r.ok){ DB = r.json.state; DB.version = r.json.version; }
}

/* ==================== SETUP / LOGIN ==================== */
function showSetup(){
  $('app').innerHTML = '<div class="login-wrap"><div class="login-logo"><div class="big">KSh</div>' +
    '<h2 style="text-align:center">CHAMA CHETU</h2><div style="font-size:12px;color:var(--muted)">First-time secure setup</div></div>' +
    '<div class="card"><p style="font-size:13px;margin-bottom:8px">No accounts exist yet. Create the <b>first Administrator</b> using the setup token issued by your server operator (found in the server <code>.env</code> — never in this file).</p>' +
    '<label>Setup token</label><input id="su_tok" type="password">' +
    '<label>Administrator full name</label><input id="su_fn">' +
    '<label>Choose username</label><input id="su_un" autocomplete="off">' +
    '<label>Choose password (min 8 chars)</label><input id="su_pw" type="password">' +
    '<label>Confirm password</label><input id="su_pw2" type="password">' +
    '<label>Group name</label><input id="su_gn" placeholder="e.g. my-chama-group">' +
    '<div style="margin-top:12px"><button class="btn big" onclick="doSetup()">Create administrator & start</button></div></div></div>';
}
async function doSetup(){
  if ($('su_pw').value !== $('su_pw2').value) return toast('Passwords do not match', 'err');
  try {
    var r = await api('POST', '/api/setup', { setup_token: $('su_tok').value, username: $('su_un').value.trim(), password: $('su_pw').value, full_name: $('su_fn').value.trim() || 'Administrator', group_name: $('su_gn').value.trim() });
    if (!r.ok) return toast(r.json.error, 'err');
    SESS = { csrf: r.json.csrf, user: r.json.user }; DB = r.json.state; DB.version = r.json.version;
    toast('Administrator created. Welcome to CHAMA CHETU!', 'ok'); nav('dashboard');
  } catch(e){ toast('Setup failed: ' + e.message, 'err'); }
}
function showLogin(msg){
  SESS = null;
  $('app').innerHTML = '<div class="login-wrap"><div class="login-logo"><div class="big">KSh</div>' +
    '<h2 style="text-align:center">CHAMA CHETU</h2><div style="font-size:12px;color:var(--muted)">Community Savings &amp; Merry-Go-Round · secure live system</div></div>' +
    (msg ? '<div class="card" style="border-left:4px solid var(--red);margin-bottom:10px">' + esc(msg) + '</div>' : '') +
    '<div class="card"><label>Username</label><input id="lu" autocomplete="username">' +
    '<label>Password</label><input id="lp" type="password" onkeydown="if(event.key===\'Enter\')doLogin()">' +
    '<div style="margin-top:12px"><button class="btn big" onclick="doLogin()">Sign in securely</button></div>' +
    '<p style="font-size:11px;color:var(--muted);margin-top:10px">Accounts are created by your Administrator. After 5 failed attempts the account locks for 10 minutes.</p></div></div>';
}
async function doLogin(){
  try {
    var r = await api('POST', '/api/login', { username: $('lu').value.trim(), password: $('lp').value });
    if (!r.ok) return toast(r.json.error, 'err');
    SESS = { csrf: r.json.csrf, user: r.json.user }; DB = r.json.state; DB.version = r.json.version;
    if (SESS.user.must_change_password) return forcePasswordChange();
    toast('Signed in as ' + SESS.user.full_name, 'ok'); nav('dashboard');
  } catch(e){ if (e.message !== 'session-expired') toast('Sign-in failed', 'err'); }
}
function forcePasswordChange(){
  $('app').innerHTML = '<div class="login-wrap"><div class="card"><h2>Set your own password</h2>' +
    '<p style="font-size:13px">Your account was created by an administrator with a temporary password. Choose your own now.</p>' +
    '<label>Temporary password</label><input id="fp_cur" type="password">' +
    '<label>New password (min 8 chars)</label><input id="fp_new" type="password">' +
    '<label>Confirm new password</label><input id="fp_new2" type="password">' +
    '<button class="btn big" style="margin-top:10px" onclick="doForcePwd()">Save my password</button></div></div>';
}
async function doForcePwd(){
  if ($('fp_new').value !== $('fp_new2').value) return toast('New passwords do not match', 'err');
  var r = await api('POST', '/api/password', { current: $('fp_cur').value, next: $('fp_new').value });
  if (!r.ok) return toast(r.json.error, 'err');
  toast('Password set ✔', 'ok'); var s = await api('GET', '/api/session');
  SESS = { csrf: s.json.csrf, user: s.json.user }; DB = s.json.state; DB.version = s.json.version; nav('dashboard');
}
async function doLogout(){ try { await api('POST', '/api/logout', {}); } catch(e){} showLogin(); }

/* ==================== SHELL / NAV ==================== */
var NAV = [
  ['dashboard','🏠','Dashboard'], ['members','👥','Members'], ['meetings','📅','Meetings'],
  ['payments','💰','Payments'], ['shareout','🤝','Share-Out'], ['spin','🎯','Spin']
];
var MENU = [
  ['attendance','✅','Attendance'], ['savings','🪙','Savings'], ['mgr','🔄','Merry-Go-Round'],
  ['fines','⚠️','Fines'], ['investments','📈','Investments'], ['expenses','🧾','Expenses'],
  ['reports','📊','Reports'], ['audit','🛡️','Audit & Backup'], ['settings','⚙️','Settings']
];
var RENDER = {};
function nav(screen){
  if (!SESS || !DB) return showLogin();
  CUR.screen = screen; $('modal-root').innerHTML = ''; try { window.scrollTo(0,0); } catch(e){}
  var tabs = NAV.map(function(n){
    var allowed = n[0] !== 'spin' || can('spin_beneficiary');
    return allowed ? '<button class="' + (screen===n[0]||screen==='meeting'&&n[0]==='meetings'||screen==='member'&&n[0]==='members' ? 'on':'') + '" onclick="nav(\'' + n[0] + '\')"><span class="ic">' + n[1] + '</span>' + n[2] + '</button>' : '';
  }).join('');
  $('app').innerHTML =
    '<header><div class="logo">' + esc((DB.settings.group_name||'CC').slice(0,3).toUpperCase()) + '</div>' +
    '<div><h1>' + esc(DB.settings.group_name) + '</h1><div class="sub">' + esc(DB.settings.reg_no||'') + ' · ' + Core.todayISO() + '</div></div>' +
    '<div class="role"><b>' + esc(SESS.user.full_name) + '</b>' + SESS.user.role + ' · <a onclick="doLogout()" style="color:#ffd;cursor:pointer;text-decoration:underline">Sign out</a></div></header>' +
    '<main id="view"></main><div class="syncbar" id="syncbar"></div>' +
    '<nav class="tabs">' + tabs + '</nav>';
  (RENDER[screen] || RENDER.dashboard)();
  renderSyncBar();
}
function menuScreen(){
  $('view').innerHTML = '<h2>All modules</h2><div class="menu-grid">' +
    MENU.map(function(m){
      return '<div class="mi" onclick="nav(\'' + m[0] + '\')"><div class="ic">' + m[1] + '</div><div class="t">' + m[2] + '</div></div>';
    }).join('') + '</div>';
}

/* ==================== CHARTS ==================== */
function chart(canvasId, series, labels, colors){
  var cv = $(canvasId); if (!cv || !cv.getContext) return; var ctx = cv.getContext('2d'); if (!ctx) return;
  var W = cv.width = cv.clientWidth * 2, H = cv.height = 240; cv.style.height = '120px';
  ctx.clearRect(0,0,W,H);
  var max = 0; series.forEach(function(s){ s.forEach(function(v){ if (v>max) max=v; }); });
  max = max || 1; var n = labels.length; var pad = 30, bw = (W - pad*2) / Math.max(n,1);
  ctx.font = '18px sans-serif'; ctx.textAlign = 'center';
  for (var g = 0; g <= 4; g++){ var gy = H - 30 - g*(H-70)/4; ctx.strokeStyle='#e3e8e6'; ctx.beginPath(); ctx.moveTo(pad,gy); ctx.lineTo(W-pad,gy); ctx.stroke(); }
  labels.forEach(function(lb, i){
    series.forEach(function(s, si){
      var v = s[i] || 0; var bh = (H-70) * v/max;
      ctx.fillStyle = colors[si] || '#0e7a4d';
      ctx.fillRect(pad + i*bw + bw*(0.18 + si*0.32), H - 30 - bh, bw*0.28, bh);
    });
    if (n <= 8 || i % 2 === 0){ ctx.fillStyle='#6b7a74'; ctx.fillText(String(lb).slice(5), pad + i*bw + bw/2, H-8); }
  });
}

/* ==================== DASHBOARD ==================== */
function renderDashboard(){
  var d = Core.dashboard(DB), p = d.position;
  if (SESS.user.role === 'member'){
    var st = Core.memberStatement(DB, SESS.user.member_id);
    var own = [
      ['🪙 My monthly savings', fmt(st.savings_total), ''],
      ['🔄 My merry-go-round paid', fmt(st.mgr_total), 'gold'],
      ['⚠️ My MGR outstanding', fmt(st.mgr_outstanding), st.mgr_outstanding>0?'red':''],
      ['2️⃣ My double penalty due', fmt(st.mgr_double_due), st.mgr_double_due>0?'red':''],
      ['⚠️ My fines owing', fmt(st.fines_outstanding), st.fines_outstanding>0?'red':''],
      ['✅ My attendance', st.attendance.pct + '%', ''],
      ['📅 Next meeting', d.next_meeting || 'None scheduled', 'blue'],
      ['🤝 Share-out', d.shareout && d.shareout.configured ? fmt(d.shareout.share_amount) + ' each on ' + d.shareout.share_date : 'Not scheduled', '']
    ];
    $('view').innerHTML = '<div class="grid">' + own.map(function(c){
      return '<div class="card stat ' + c[2] + '"><div class="k">' + c[0] + '</div><div class="v">' + esc(c[1]) + '</div></div>'; }).join('') + '</div>' +
      '<div class="card" style="margin-top:10px"><h3>📢 Group announcements</h3><p>Next meeting: ' + esc(d.next_meeting || 'to be announced') + '.</p></div>';
    return;
  }
  var cards = [
    ['👥 Members', d.members_active + ' / ' + d.members_total + ' active', ''],
    ['📅 Next meeting', d.next_meeting || 'None scheduled', 'blue'],
    ['✅ Last attendance', d.last_attendance_pct + '%', ''],
    ['🪙 Monthly savings fund', fmt(d.savings_total), ''],
    ['🔄 Merry-go-round pot', fmt(d.mgr_pot), 'gold'],
    ['🎯 Next MGR beneficiary', d.mgr_next_beneficiary || 'Spin to select', 'gold'],
    ['🔄 MGR cycle #' + d.mgr_cycle, d.mgr_paid_this_cycle + ' payouts made', ''],
    ['⚠️ Fines outstanding', fmt(d.fines_outstanding), d.fines_outstanding > 0 ? 'red' : ''],
    ['💰 Available cash', fmt(d.available_cash), 'gold'],
    ['📈 Investment value', fmt(d.investment_value), 'blue'],
    ['🧾 Total expenses', fmt(d.expenses_total), ''],
    ['🏛 Total position', fmt(p.total_position), 'gold'],
    ['🤝 Share-out', d.shareout && d.shareout.configured ? fmt(d.shareout.share_amount) + ' × ' + d.shareout.recipients + ' = ' + fmt(d.shareout.total) : 'Not configured', '']
  ];
  var mtgs = DB.meetings.filter(function(m){return m.status==='closed';}).slice(-6);
  var attS = mtgs.map(function(m){
    var rows = DB.attendance.filter(function(a){return a.meeting_id===m.id;});
    return rows.length ? Math.round(100*rows.filter(function(a){return a.status==='P'||a.status==='L';}).length/rows.length) : 0;
  });
  var savS = mtgs.map(function(m){ var t=0; DB.payments.forEach(function(pp){ if (pp.category==='NORMAL_SAVINGS' && pp.meeting_id===m.id && pp.status==='active') t+=pp.amount; }); return t; });
  var mgrS = mtgs.map(function(m){ var t=0; DB.payments.forEach(function(pp){ if ((pp.category==='MGR'||pp.category==='MGR_DOUBLE') && pp.meeting_id===m.id && pp.status==='active') t+=pp.amount; }); return t; });
  var fImp = mtgs.map(function(m){
    var t=0; DB.attendance.forEach(function(a){ if(a.meeting_id===m.id && !a.waived) t+=a.fine_amount; });
    DB.ledger.forEach(function(e){ if(e.category==='LATE_FINE' && e.meeting_id===m.id && !Core.isReversed(DB,e.id)) t+=e.lines[0].debit; }); return t; });
  var fPaid = mtgs.map(function(m){ var t=0; DB.payments.forEach(function(pp){ if((pp.category==='FINE'||pp.category==='LATE_FINE') && pp.meeting_id===m.id && pp.status==='active') t+=pp.amount; }); return t; });
  $('view').innerHTML = '<div class="grid">' + cards.map(function(c){
      return '<div class="card stat ' + c[2] + '"><div class="k">' + c[0] + '</div><div class="v">' + esc(c[1]) + '</div></div>'; }).join('') + '</div>' +
    '<h2>Trends</h2>' +
    '<div class="card"><h3>Attendance % per meeting</h3><canvas id="c1"></canvas></div>' +
    '<div class="card"><h3>Monthly savings collected (KSh)</h3><canvas id="c2"></canvas></div>' +
    '<div class="card"><h3>Merry-go-round collected (KSh)</h3><canvas id="c5"></canvas></div>' +
    '<div class="card"><h3>Fines & penalties imposed vs paid (KSh)</h3><canvas id="c3"></canvas></div>' +
    '<h2>Quick actions</h2><div class="menu-grid">' +
    (can('record_payments') ? '<div class="mi" onclick="nav(\'payments\')"><div class="ic">💰</div><div class="t">Record payments</div></div>' : '') +
    (can('spin_beneficiary') ? '<div class="mi" onclick="nav(\'spin\')"><div class="ic">🎯</div><div class="t">Spin MGR</div></div>' : '') +
    '<div class="mi" onclick="nav(\'members\')"><div class="ic">👥</div><div class="t">Member accounts</div></div>' +
    '<div class="mi" onclick="menuScreen()"><div class="ic">☰</div><div class="t">All modules</div></div></div>';
  chart('c1',[attS], mtgs.map(function(m){return m.date;}), ['#0e7a4d']);
  chart('c2',[savS], mtgs.map(function(m){return m.date;}), ['#0e7a4d']);
  chart('c5',[mgrS], mtgs.map(function(m){return m.date;}), ['#c9a227']);
  chart('c3',[fImp, fPaid], mtgs.map(function(m){return m.date;}), ['#c0392b','#0e7a4d']);
}

/* ==================== MEMBERS ==================== */
function renderMembers(){
  var q = ($('mq') ? $('mq').value : '').toLowerCase();
  var list = DB.members.filter(function(m){ return !q || (m.full_name+m.m_no+m.village).toLowerCase().indexOf(q)!==-1; });
  var actions = '';
  if (can('manage_members')) actions = '<button class="btn" onclick="addMemberForm()">+ Register member</button> <button class="btn gold" onclick="importExcelForm()">⬆ Import Excel</button> ';
  actions += '<button class="btn ghost" onclick="exportMembersCSV()">⬇ CSV</button>';
  $('view').innerHTML =
    '<div class="row"><input id="mq" placeholder="🔍 Search name / membership no…" value="' + esc(q) + '" oninput="renderMembers()"></div>' +
    '<div style="margin:10px 0">' + actions + '</div>' +
    '<div class="tbl-wrap"><table><tr><th>#</th><th>Member (tap for account)</th><th>Village</th><th>Status</th><th>Savings</th>' + (can('remove_members')?'<th>Admin</th>':'') + '</tr>' +
    list.map(function(m){
      var st = Core.memberStatement(DB, m.id);
      return '<tr><td>' + esc(m.m_no) + '</td>' +
        '<td><span class="member-link" onclick="openMember(\'' + m.id + '\')">' + esc(m.full_name) + '</span></td>' +
        '<td>' + esc(m.village) + '</td>' +
        '<td><span class="pill ' + (m.status==='Active'?'g':(m.status==='Suspended'?'y':'r')) + '">' + esc(m.status) + '</span></td>' +
        '<td>' + fmt(st.savings_total) + '</td>' +
        (can('remove_members') ? '<td><button class="btn sm ghost" onclick="editMemberForm(\'' + m.id + '\')">✎</button> <button class="btn sm red" onclick="removeMemberConfirm(\'' + m.id + '\')">🗑</button></td>' : '') + '</tr>';
    }).join('') + '</table></div>';
}
function addMemberForm(){
  $('modal-root').innerHTML = '<div class="modal"><div class="sheet"><button class="x" onclick="closeModal()">×</button><h3>Register new member</h3>' +
    '<label>Full name *</label><input id="nm">' +
    '<div class="row"><div><label>Phone</label><input id="np" placeholder="+2547…"></div><div><label>Gender</label><select id="ng"><option></option><option>F</option><option>M</option></select></div></div>' +
    '<div class="row"><div><label>ID no.</label><input id="ni"></div><div><label>Village</label><input id="nv"></div></div></div>' +
    '<label>Next of kin</label><input id="nk"><label>Remarks</label><input id="nr">' +
    '<button class="btn big" style="margin-top:12px" onclick="doAddMember()">Save member</button></div></div>';
}
async function doAddMember(){
  var r = await ACT('addMember', { full_name: $('nm').value.trim(), phone: $('np').value.trim(), gender: $('ng').value, id_no: $('ni').value.trim(), village: $('nv').value.trim(), next_of_kin: $('nk').value.trim(), remarks: $('nr').value.trim() });
  if (r.ok) closeModal();
}
function editMemberForm(id){
  var m = DB.members.filter(function(x){return x.id===id;})[0]; if (!m) return;
  $('modal-root').innerHTML = '<div class="modal"><div class="sheet"><button class="x" onclick="closeModal()">×</button><h3>Edit member — ' + esc(m.m_no) + '</h3>' +
    '<label>Full name</label><input id="em_nm" value="' + esc(m.full_name) + '">' +
    '<div class="row"><div><label>Phone</label><input id="em_ph" value="' + esc(m.phone) + '"></div><div><label>Status</label><select id="em_st">' + ['Active','Suspended','Withdrawn','Deceased','Removed'].map(function(s){return '<option ' + (m.status===s?'selected':'') + '>' + s + '</option>';}).join('') + '</select></div></div>' +
    '<div class="row"><div><label>ID no.</label><input id="em_id" value="' + esc(m.id_no) + '"></div><div><label>Village</label><input id="em_v" value="' + esc(m.village) + '"></div></div></div>' +
    '<label>Next of kin</label><input id="em_nk" value="' + esc(m.next_of_kin) + '"><label>Remarks</label><input id="em_rm" value="' + esc(m.remarks) + '">' +
    '<button class="btn big" style="margin-top:10px" onclick="doEditMember(\'' + id + '\')">Save changes</button></div></div>';
}
async function doEditMember(id){
  var r = await ACT('editMember', { id: id, full_name: $('em_nm').value.trim(), phone: $('em_ph').value.trim(), status: $('em_st').value, id_no: $('em_id').value.trim(), village: $('em_v').value.trim(), next_of_kin: $('em_nk').value.trim(), remarks: $('em_rm').value.trim() });
  if (r.ok) closeModal();
}
function removeMemberConfirm(id){
  var m = DB.members.filter(function(x){return x.id===id;})[0]; if (!m) return;
  $('modal-root').innerHTML = '<div class="modal"><div class="sheet"><button class="x" onclick="closeModal()">×</button><h3>Remove member</h3>' +
    '<p><b>' + esc(m.full_name) + '</b> (' + esc(m.m_no) + ') will be marked <span class="pill r">Removed</span>. All history is kept — nothing is deleted.</p>' +
    '<label>Reason</label><input id="rm_reason">' +
    '<button class="btn red big" style="margin-top:10px" onclick="doRemoveMember(\'' + id + '\')">Confirm removal</button></div></div>';
}
async function doRemoveMember(id){ var r = await ACT('removeMember', { id: id, reason: $('rm_reason').value }); if (r.ok) closeModal(); }
function importExcelForm(){
  $('modal-root').innerHTML = '<div class="modal"><div class="sheet"><button class="x" onclick="closeModal()">×</button><h3>⬆ Import members from Excel</h3>' +
    '<p style="font-size:13px">Row 1 must contain exactly these headers:<br><code>Full Name | Phone | Gender | ID No | Village | Next of Kin | Remarks</code></p>' +
    '<button class="btn gold" onclick="downloadTemplate()">⬇ Download guided template (.xlsx)</button>' +
    '<div style="margin-top:10px"><label>Choose file (.xlsx/.xls/.csv)</label><input type="file" id="xls_file" accept=".xlsx,.xls,.csv" onchange="previewExcel(this)"></div>' +
    '<div id="xls_preview"></div></div></div>';
}
function downloadTemplate(){
  var ws = XLSX.utils.aoa_to_sheet([['Full Name','Phone','Gender','ID No','Village','Next of Kin','Remarks'],
    ['Jane Wambui','+254712345678','F','29384756','Kiambu','John Wambui',''],['Peter Maina','+254723456789','M','30125678','Nyeri','Mary Maina','']]);
  ws['!cols'] = [{wch:22},{wch:16},{wch:8},{wch:12},{wch:12},{wch:18},{wch:24}];
  var wb = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb, ws, 'Members');
  XLSX.writeFile(wb, 'chama-chetu-members-template.xlsx'); toast('Template downloaded ✔', 'ok');
}
var IMPORT_ROWS = null;
function previewExcel(inp){
  var f = inp.files[0]; if (!f) return;
  var rd = new FileReader();
  rd.onload = function(){
    try {
      var wb = XLSX.read(rd.result, {type:'array'});
      var json = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]], {defval:''});
      var rows = json.map(function(r){
        return { full_name: String(r['Full Name']||r['Full name']||r['full name']||'').trim(),
          phone: String(r['Phone']||'').trim(), gender: String(r['Gender']||'').trim().toUpperCase().slice(0,1),
          id_no: String(r['ID No']||r['ID No.']||'').trim(), village: String(r['Village']||'').trim(),
          next_of_kin: String(r['Next of Kin']||'').trim(), remarks: String(r['Remarks']||'').trim() };
      });
      IMPORT_ROWS = rows;
      var valid = rows.filter(function(r){return r.full_name;});
      $('xls_preview').innerHTML = '<h3 style="margin-top:10px">Preview — ' + valid.length + ' valid of ' + rows.length + ' rows (duplicates & blanks skipped by the server)</h3>' +
        (valid.length ? '<div class="tbl-wrap" style="max-height:180px;overflow:auto"><table><tr><th>#</th><th>Name</th><th>Phone</th><th>Village</th></tr>' +
        valid.slice(0,25).map(function(r,i){return '<tr><td>'+(i+1)+'</td><td>'+esc(r.full_name)+'</td><td>'+esc(r.phone)+'</td><td>'+esc(r.village)+'</td></tr>';}).join('') + '</table></div>' +
        '<button class="btn big" style="margin-top:10px" onclick="doImportExcel()">Import ' + valid.length + ' member(s)</button>'
        : '<p><span class="pill r">No valid rows — check the "Full Name" header in row 1.</span></p>');
    } catch(e){ toast('Could not read file: ' + e.message, 'err'); }
  };
  rd.readAsArrayBuffer(f);
}
async function doImportExcel(){ if (!IMPORT_ROWS) return; var r = await ACT('importMembers', { rows: IMPORT_ROWS }); if (r.ok){ IMPORT_ROWS = null; closeModal(); } }
function closeModal(){ $('modal-root').innerHTML = ''; }
function download(name, content, mime){
  var a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([content], {type: mime||'application/octet-stream'}));
  a.download = name; a.click(); toast('Downloaded ' + name, 'ok');
}
function exportMembersCSV(){
  var rows = [['Membership No','Full name','Gender','Phone','ID No','Village','Status','Joined','Savings (KSh)','Fines outstanding','MGR outstanding']];
  DB.members.forEach(function(m){ var st = Core.memberStatement(DB, m.id);
    rows.push([m.m_no, m.full_name, m.gender, m.phone, m.id_no, m.village, m.status, m.joined, st.savings_total, st.fines_outstanding, st.mgr_outstanding]); });
  download('members.csv', Core.toCSV(rows), 'text/csv');
}

/* ==================== MEMBER ACCOUNT ==================== */
function openMember(id){ CUR.member = id; CUR.memberTab = 'personal'; nav('member'); }
function setMTab(t){ CUR.memberTab = t; renderMemberAccount(); }
function renderMemberAccount(){
  var m = DB.members.filter(function(x){return x.id===CUR.member;})[0];
  if (!m) return nav('members');
  var st = Core.memberStatement(DB, m.id), a = st.attendance;
  var tabs = [['personal','Personal'],['attendance','Attendance'],['savings','Monthly Savings'],['mgr','Merry-Go-Round'],
    ['fines','Fines & Penalties'],['other','Other payments'],['stmt','Statement'],['perf','Performance']];
  $('view').innerHTML =
    '<div class="card" style="border-left:5px solid var(--gold)"><h2 style="margin:0">' + esc(m.full_name) + ' <span class="pill g">' + esc(m.m_no) + '</span></h2>' +
    '<div class="row" style="margin-top:8px">' +
      '<div class="card stat"><div class="k">Savings</div><div class="v">' + fmt(st.savings_total) + '</div></div>' +
      '<div class="card stat red"><div class="k">Fines owing</div><div class="v">' + fmt(st.fines_outstanding) + '</div></div>' +
      '<div class="card stat gold"><div class="k">MGR outstanding</div><div class="v">' + fmt(st.mgr_outstanding) + '</div></div>' +
      '<div class="card stat red"><div class="k">Double penalty due</div><div class="v">' + fmt(st.mgr_double_due) + '</div></div>' +
      '<div class="card stat"><div class="k">Attendance</div><div class="v">' + a.pct + '%</div></div>' +
    '</div></div>' +
    '<div style="display:flex;gap:6px;overflow-x:auto;margin:10px 0">' +
      tabs.map(function(t){ return '<button class="btn sm ' + (CUR.memberTab===t[0]?'':'ghost') + '" onclick="setMTab(\'' + t[0] + '\')">' + t[1] + '</button>'; }).join('') + '</div>' +
    '<div id="mtab"></div>' +
    '<button class="btn ghost sm" onclick="printStatement()">🖨 Print / PDF statement</button> ' +
    '<button class="btn ghost sm" onclick="downloadStatementCSV()">⬇ Excel/CSV statement</button>';
  var el = $('mtab');
  if (CUR.memberTab==='personal'){
    el.innerHTML = '<div class="card"><table>' +
      [['Membership No', m.m_no], ['Phone', m.phone], ['Gender', m.gender], ['ID No', m.id_no], ['Village', m.village],
       ['Next of kin', m.next_of_kin], ['Status', m.status], ['Date joined', m.joined], ['Remarks', m.remarks]]
      .map(function(r){ return '<tr><td><b>' + r[0] + '</b></td><td>' + esc(r[1]||'—') + '</td></tr>'; }).join('') + '</table></div>';
  } else if (CUR.memberTab==='attendance'){
    var rows = DB.attendance.filter(function(x){return x.member_id===m.id;}).map(function(x){
      return '<tr><td>' + esc(meetingRef(x.meeting_id)) + '</td><td>' + mtDate(x.meeting_id) + '</td><td><b>' + x.status + '</b></td><td>' + fmt(x.waived?0:x.fine_amount) + (x.waived?' (waived)':'') + '</td></tr>'; });
    el.innerHTML = '<div class="card"><b>Present ' + a.present + ' · Late ' + a.late + ' · Apology ' + a.apology + ' · Absent ' + a.absent + ' of ' + a.scheduled + ' (' + a.pct + '%)</b></div>' +
      '<div class="tbl-wrap"><table><tr><th>Meeting</th><th>Date</th><th>Status</th><th>Fine</th></tr>' + rows.join('') + '</table></div>';
  } else if (CUR.memberTab==='savings'){
    var pays = DB.payments.filter(function(p){return p.member_id===m.id && p.category==='NORMAL_SAVINGS';});
    el.innerHTML = summaryRow('Total monthly savings', st.savings_total) +
      '<div class="tbl-wrap"><table><tr><th>Receipt</th><th>Date</th><th>Amount</th><th>Method</th><th>Ref</th></tr>' +
      pays.map(function(p){ return '<tr><td>' + esc(p.txn_no) + '</td><td>' + p.date + '</td><td>' + fmt(p.amount) + '</td><td>' + esc(p.method) + '</td><td>' + esc(p.reference||'—') + '</td></tr>'; }).join('') + '</table></div>';
  } else if (CUR.memberTab==='mgr'){
    var mg = DB.payments.filter(function(p){return p.member_id===m.id && (p.category==='MGR'||p.category==='MGR_DOUBLE');});
    el.innerHTML = summaryRow('Total MGR contributions (incl. double penalty)', st.mgr_total) +
      summaryRow('Outstanding MGR (current cycle)', st.mgr_outstanding) + summaryRow('DOUBLE penalty due if delayed', st.mgr_double_due) +
      '<div class="tbl-wrap"><table><tr><th>Receipt</th><th>Date</th><th>Category</th><th>Amount</th></tr>' +
      mg.map(function(p){ return '<tr><td>' + esc(p.txn_no) + '</td><td>' + p.date + '</td><td>' + esc(catLabel(p.category)) + '</td><td>' + fmt(p.amount) + '</td></tr>'; }).join('') + '</table></div>';
  } else if (CUR.memberTab==='fines'){
    var fr = DB.attendance.filter(function(x){return x.member_id===m.id && (x.fine_amount>0 || x.waived);}).map(function(x){
      return '<tr><td>' + esc(meetingRef(x.meeting_id)) + '</td><td>Attendance (' + x.status + ')</td><td>' + fmt(x.waived?0:x.fine_amount) + '</td><td>' + (x.waived?'<span class="pill b">waived</span>':'<span class="pill r">owing</span>') + '</td></tr>'; });
    DB.ledger.filter(function(e){ return e.category==='LATE_FINE' && e.member_id===m.id && !Core.isReversed(DB,e.id); }).forEach(function(e){
      fr.push('<tr><td>' + esc(meetingRef(e.meeting_id)) + '</td><td>Delayed payment</td><td>' + fmt(e.lines[0].debit) + '</td><td><span class="pill r">owing</span></td></tr>'); });
    el.innerHTML = summaryRow('Fines imposed', st.fines_imposed) + summaryRow('Fines paid', st.fines_paid) + summaryRow('Outstanding', st.fines_outstanding) +
      '<div class="tbl-wrap"><table><tr><th>Meeting</th><th>Type</th><th>Amount</th><th>Status</th></tr>' + fr.join('') + '</table></div>';
  } else if (CUR.memberTab==='other'){
    el.innerHTML = '<div class="tbl-wrap"><table><tr><th>Receipt</th><th>Category</th><th>Date</th><th>Amount</th></tr>' +
      DB.payments.filter(function(p){return p.member_id===m.id && ['WELFARE','SPECIAL_SAVINGS','OTHER'].indexOf(p.category)!==-1;})
      .map(function(p){ return '<tr><td>' + esc(p.txn_no) + '</td><td>' + esc(catLabel(p.category)) + '</td><td>' + p.date + '</td><td>' + fmt(p.amount) + '</td></tr>'; }).join('') + '</table></div>';
  } else if (CUR.memberTab==='stmt'){
    el.innerHTML = '<div class="tbl-wrap"><table><tr><th>Date</th><th>Type</th><th>Ref</th><th>Amount</th><th>Status</th></tr>' +
      st.transactions.map(function(t){ return '<tr><td>' + t.date + '</td><td>' + esc(t.type) + '</td><td>' + esc(t.ref) + '</td><td>' + fmt(t.amount) + '</td><td>' + esc(t.status) + '</td></tr>'; }).join('') + '</table></div>';
  } else {
    el.innerHTML = '<div class="card"><table>' +
      [['Attendance percentage', a.pct + '%'], ['Meetings attended', a.present + a.late + ' / ' + a.scheduled],
       ['Total monthly savings', fmt(st.savings_total)], ['Total MGR contributions', fmt(st.mgr_total)],
       ['MGR outstanding', fmt(st.mgr_outstanding)], ['Double penalty due', fmt(st.mgr_double_due)],
       ['Fines imposed / paid / outstanding', fmt(st.fines_imposed) + ' / ' + fmt(st.fines_paid) + ' / ' + fmt(st.fines_outstanding)],
       ['Overall position (savings − fines − MGR outstanding)', fmt(st.savings_total - st.fines_outstanding - st.mgr_outstanding)]]
      .map(function(r){ return '<tr><td><b>' + r[0] + '</b></td><td>' + r[1] + '</td></tr>'; }).join('') + '</table></div>';
  }
}
function summaryRow(k, v){ return '<div class="card stat" style="margin-bottom:8px"><div class="k">' + k + '</div><div class="v">' + fmt(v) + '</div></div>'; }
function meetingRef(id){ var m = DB.meetings.filter(function(x){return x.id===id;})[0]; return m ? m.ref : '—'; }
function mtDate(id){ var m = DB.meetings.filter(function(x){return x.id===id;})[0]; return m ? m.date : ''; }
function printStatement(){
  var m = DB.members.filter(function(x){return x.id===CUR.member;})[0];
  var st = Core.memberStatement(DB, m.id);
  var w = window.open('', '_blank');
  w.document.write('<html><head><title>Member statement — ' + esc(m.full_name) + '</title><style>body{font-family:Segoe UI,sans-serif;padding:30px}table{border-collapse:collapse;width:100%}td,th{border:1px solid #999;padding:6px;font-size:13px}h1{color:#0b5d3b}.sig{margin-top:60px;display:flex;justify-content:space-between}</style></head><body>' +
    '<h1>' + esc(DB.settings.group_name) + ' — CHAMA CHETU</h1><div>' + esc(DB.settings.reg_no||'') + ' · ' + esc(DB.settings.contact||'') + '</div>' +
    '<h2>Individual member statement</h2><p><b>' + esc(m.full_name) + '</b> (' + esc(m.m_no) + ') — generated ' + new Date().toLocaleString() + '</p>' +
    '<table><tr><th>Item</th><th>Value (KSh)</th></tr>' +
    [['Total monthly savings', st.savings_total], ['Total MGR contributions', st.mgr_total], ['MGR outstanding', st.mgr_outstanding],
     ['Fines imposed', st.fines_imposed], ['Fines paid', st.fines_paid], ['Fines outstanding', st.fines_outstanding]]
    .map(function(r){ return '<tr><td>' + r[0] + '</td><td style="text-align:right">' + r[1].toLocaleString() + '</td></tr>'; }).join('') + '</table>' +
    '<h3>Transactions</h3><table><tr><th>Date</th><th>Type</th><th>Receipt</th><th>Amount</th></tr>' +
    st.transactions.map(function(t){ return '<tr><td>' + t.date + '</td><td>' + esc(t.type) + '</td><td>' + esc(t.ref) + '</td><td style="text-align:right">' + t.amount.toLocaleString() + '</td></tr>'; }).join('') + '</table>' +
    '<div class="sig"><div>Prepared by: ' + esc(SESS.user.full_name) + '</div><div>Signature: ____________</div><div>Chairperson/Treasurer: ____________</div></div></body></html>');
  w.document.close(); w.print();
}
function downloadStatementCSV(){
  var m = DB.members.filter(function(x){return x.id===CUR.member;})[0];
  var st = Core.memberStatement(DB, m.id);
  var rows = [['Date','Type','Receipt','Amount KSh','Status']];
  st.transactions.forEach(function(t){ rows.push([t.date, t.type, t.ref, t.amount, t.status]); });
  rows.push([], ['Totals'], ['Monthly savings', st.savings_total], ['MGR contributions', st.mgr_total], ['MGR outstanding', st.mgr_outstanding], ['Fines outstanding', st.fines_outstanding]);
  download('statement-' + m.m_no + '.csv', Core.toCSV(rows), 'text/csv');
}

/* ==================== MEETINGS ==================== */
function renderMeetings(){
  var open = DB.meetings.filter(function(m){return m.status==='open';});
  var closed = DB.meetings.filter(function(m){return m.status==='closed';}).slice().reverse();
  $('view').innerHTML =
    (can('schedule_meetings') ? '<div style="margin-bottom:10px"><button class="btn" onclick="scheduleMeetingForm()">+ Schedule meeting</button></div>' : '') +
    '<h3>Open meetings</h3>' + (open.map(meetingCard).join('') || '<div class="card">No open meetings.</div>') +
    '<h3>Meeting history (permanent record)</h3><div class="tbl-wrap"><table><tr><th>Ref</th><th>Date</th><th>Venue</th><th>Attendance</th><th></th></tr>' +
    closed.map(function(m){
      var rows = DB.attendance.filter(function(a){return a.meeting_id===m.id;});
      var pct = rows.length ? Math.round(100*rows.filter(function(a){return a.status==='P'||a.status==='L';}).length/rows.length) : 0;
      return '<tr><td>' + esc(m.ref) + '</td><td>' + m.date + '</td><td>' + esc(m.venue) + '</td><td><span class="pill ' + (pct>=75?'g':(pct>=50?'y':'r')) + '">' + pct + '%</span></td><td><button class="btn sm ghost" onclick="CUR.meeting=\'' + m.id + '\';nav(\'meeting\')">View</button></td></tr>';
    }).join('') + '</table></div>';
}
function meetingCard(m){
  return '<div class="card stat" style="margin-bottom:8px;cursor:pointer" onclick="CUR.meeting=\'' + m.id + '\';nav(\'meeting\')"><b>' + esc(m.ref) + '</b> — ' + m.date + ' ' + esc(m.time) + '<br>' + esc(m.venue) + ' · ' + esc(m.type) + ' <span class="pill y">OPEN</span></div>';
}
function scheduleMeetingForm(){
  $('modal-root').innerHTML = '<div class="modal"><div class="sheet"><button class="x" onclick="closeModal()">×</button><h3>Schedule meeting</h3>' +
    '<label>Date *</label><input id="sm_d" type="date" value="' + Core.todayISO() + '">' +
    '<div class="row"><div><label>Time</label><input id="sm_t" type="time" value="14:00"></div><div><label>Type</label><select id="sm_ty"><option>Regular</option><option>Special</option><option>Emergency</option></select></div></div>' +
    '<label>Venue</label><input id="sm_v"><label>Frequency</label><select id="sm_f"><option>Monthly</option><option>Fortnightly</option><option>Custom</option></select>' +
    '<button class="btn big" style="margin-top:12px" onclick="doSchedule()">Create meeting</button></div></div>';
}
async function doSchedule(){ var r = await ACT('createMeeting', { date:$('sm_d').value, time:$('sm_t').value, venue:$('sm_v').value, type:$('sm_ty').value, frequency:$('sm_f').value }); if (r.ok) closeModal(); }
function renderMeetingWorkspace(){
  var mt = DB.meetings.filter(function(x){return x.id===CUR.meeting;})[0];
  if (!mt) return nav('meetings');
  var att = DB.attendance.filter(function(a){return a.meeting_id===mt.id;});
  var marked = att.length, active = DB.members.filter(function(m){return m.status==='Active';}).length;
  var reg = Core.contributionRegister(DB, mt);
  var totExp = reg.reduce(function(s,r){return s+r.expected;},0), totPaid = reg.reduce(function(s,r){return s+r.paid;},0);
  var mgrPaid = reg.reduce(function(s,r){return s+r.mgr_paid;},0);
  var finesHere = att.reduce(function(s,a){return s+(a.waived?0:a.fine_amount);},0);
  var lateHere = DB.ledger.filter(function(e){return e.category==='LATE_FINE' && e.meeting_id===mt.id && !Core.isReversed(DB,e.id);}).reduce(function(s,e){return s+e.lines[0].debit;},0);
  var canMark = can('record_attendance') && mt.status==='open';
  var canPay = can('record_payments') && mt.status==='open';
  $('view').innerHTML =
    '<div class="card"><h2 style="margin:0">' + esc(mt.ref) + ' <span class="pill ' + (mt.status==='open'?'y':'b') + '">' + mt.status + '</span></h2>' +
    '<div>' + mt.date + ' · ' + esc(mt.time) + ' · ' + esc(mt.venue) + ' · ' + esc(mt.type) + '</div></div>' +
    '<h3>📋 Attendance register (' + marked + '/' + active + ' marked)</h3>' +
    '<div class="tbl-wrap"><table><tr><th>Member</th><th colspan="4" style="text-align:center">P · A · X · L</th><th>Fine</th></tr>' +
    DB.members.filter(function(m){return m.status==='Active';}).map(function(m){
      var a = att.filter(function(x){return x.member_id===m.id;})[0];
      var btn = function(code){ return '<button class="abtn ' + (a && a.status===code ? 'sel-'+code.toLowerCase() : '') + '" ' + (canMark?'':'disabled') + ' onclick="mark(\'' + mt.id + '\',\'' + m.id + '\',\'' + code + '\')">' + code + '</button>'; };
      return '<tr><td><span class="member-link" onclick="openMember(\'' + m.id + '\')">' + esc(m.full_name) + '</span></td>' +
        '<td style="text-align:center">' + btn('P') + '</td><td style="text-align:center">' + btn('A') + '</td><td style="text-align:center">' + btn('X') + '</td><td style="text-align:center">' + btn('L') + '</td>' +
        '<td>' + (a ? (a.waived ? '<span class="pill b">waived</span>' : (a.fine_amount>0 ? '<span class="pill r">' + fmt(a.fine_amount) + '</span>' : 'KSh 0')) : '—') + '</td></tr>';
    }).join('') + '</table></div>' +
    (can('waive_fines') && marked ? '<div class="card" style="margin-top:8px"><h3>Waive a fine</h3><div class="row"><select id="wf_m">' +
      att.filter(function(a){return a.fine_amount>0 && !a.waived;}).map(function(a){return '<option value="' + a.member_id + '">' + esc(memberName(a.member_id)) + '</option>';}).join('') + '</select>' +
      '<input id="wf_r" placeholder="Reason"><button class="btn red sm" onclick="doWaive(\'' + mt.id + '\')">Waive</button></div></div>' : '') +
    '<h3>💰 Contributions this meeting — Monthly savings & Merry-go-round (one register)</h3>' +
    '<div class="tbl-wrap"><table><tr><th>Member</th><th>Monthly expected</th><th>Monthly paid</th><th>Monthly owing</th><th>MGR paid</th>' + (canPay?'<th>Record</th>':'') + '</tr>' +
    reg.map(function(r){
      return '<tr><td><span class="member-link" onclick="openMember(\'' + r.member.id + '\')">' + esc(r.member.full_name) + '</span></td>' +
        '<td>' + fmt(r.expected) + '</td><td>' + fmt(r.paid) + '</td>' +
        '<td>' + (r.outstanding>0 ? '<span class="pill r">' + fmt(r.outstanding) + '</span>' : '<span class="pill g">paid</span>') + '</td>' +
        '<td>' + fmt(r.mgr_paid) + '</td>' +
        (canPay ? '<td><button class="btn sm" onclick="quickPay(\'' + r.member.id + '\',\'' + mt.id + '\',\'NORMAL_SAVINGS\',' + DB.settings.contribution_amount + ')">+Monthly</button> <button class="btn sm gold" onclick="quickPay(\'' + r.member.id + '\',\'' + mt.id + '\',\'MGR\',' + DB.settings.mgr_contribution + ')">+MGR</button></td>' : '') + '</tr>';
    }).join('') +
    '<tr style="font-weight:700;background:#eef5f1"><td>TOTAL</td><td>' + fmt(totExp) + '</td><td>' + fmt(totPaid) + '</td><td>' + fmt(totExp-totPaid) + '</td><td>' + fmt(mgrPaid) + '</td><td></td></tr></table></div>' +
    '<h3>💵 Meeting financial summary</h3><div class="grid">' +
    '<div class="card stat"><div class="k">Monthly savings collected</div><div class="v">' + fmt(totPaid) + '</div></div>' +
    '<div class="card stat gold"><div class="k">MGR collected</div><div class="v">' + fmt(mgrPaid) + '</div></div>' +
    '<div class="card stat red"><div class="k">Fines imposed</div><div class="v">' + fmt(finesHere) + '</div></div>' +
    '<div class="card stat red"><div class="k">Delayed-payment fines</div><div class="v">' + fmt(lateHere) + '</div></div></div>' +
    '<p class="syncbar">On close, members who paid less than the monthly amount are automatically fined ' + fmt(DB.settings.late_payment_fine) + '.</p>' +
    (mt.status==='open' && can('close_meeting') ?
      '<h3>Close meeting</h3><div class="card"><label>Minutes</label><textarea id="cl_min"></textarea><label>Resolutions</label><textarea id="cl_res"></textarea>' +
      '<button class="btn big" style="margin-top:8px" onclick="doClose(\'' + mt.id + '\')">🔒 Close & approve (auto-fines delayed payers)</button></div>' :
      '<div class="card"><h3>Minutes</h3><p>' + esc(mt.minutes||'—') + '</p><h3>Resolutions</h3><p>' + esc(mt.resolutions||'—') + '</p></div>');
}
async function mark(mtId, mId, code){ await ACT('markAttendance', { meeting_id: mtId, member_id: mId, status: code }); }
async function doWaive(mtId){ await ACT('waiveFine', { meeting_id: mtId, member_id: $('wf_m').value, reason: $('wf_r').value }); }
async function quickPay(mId, mtId, category, amount){ await ACT('recordPayment', { member_id:mId, category:category, amount:amount, method:'Cash', meeting_id:mtId, by:SESS.user.full_name }); }
async function doClose(mtId){ var r = await ACT('closeMeeting', { meeting_id: mtId, minutes: $('cl_min').value, resolutions: $('cl_res').value }); if (r.ok) nav('meetings'); }

/* ==================== SAVINGS / MGR / FINES ==================== */
function renderSavings(){
  var sel = $('sv_m') ? $('sv_m').value : (DB.meetings[DB.meetings.length-1]||{}).id;
  var mt = DB.meetings.filter(function(m){return m.id===sel;})[0];
  var html = '<h2>🪙 Monthly savings contributions</h2><p class="syncbar">' + fmt(DB.settings.contribution_amount) + ' per member, ' + esc(DB.settings.meeting_frequency) + '. SEPARATE from merry-go-round.</p>';
  if (can('record_payments') && mt){
    html += '<div class="card"><div class="row"><select id="sv_m" onchange="renderSavings()">' + DB.meetings.map(function(m){return '<option value="' + m.id + '"' + (m===mt?' selected':'') + '>' + esc(m.ref) + ' — ' + m.date + '</option>';}).join('') + '</select></div>' +
      '<div class="tbl-wrap" style="margin-top:8px"><table><tr><th>Member</th><th>Expected</th><th>Paid</th><th>Owing</th><th>Record</th></tr>' +
      Core.contributionRegister(DB, mt).map(function(r){
        return '<tr><td>' + esc(r.member.full_name) + '</td><td>' + fmt(r.expected) + '</td><td>' + fmt(r.paid) + '</td><td>' + (r.outstanding>0?'<span class="pill r">'+fmt(r.outstanding)+'</span>':'<span class="pill g">0</span>') + '</td>' +
        '<td><div class="row"><input id="amt_' + r.member.id + '" type="number" placeholder="Amount" style="min-width:80px"><button class="btn sm" onclick="recSav(\'' + r.member.id + '\',\'' + mt.id + '\')">Save</button></div></td></tr>'; }).join('') + '</table></div></div>';
  }
  html += '<h3>Member savings balances</h3><div class="tbl-wrap"><table><tr><th>Member</th><th>Total savings</th></tr>' +
    DB.members.map(function(m){ return [m, Core.memberStatement(DB, m.id).savings_total]; })
    .filter(function(x){return x[1]>0;}).sort(function(a,b){return b[1]-a[1];})
    .map(function(x){ return '<tr><td><span class="member-link" onclick="openMember(\'' + x[0].id + '\')">' + esc(x[0].full_name) + '</span></td><td>' + fmt(x[1]) + '</td></tr>'; }).join('') + '</table></div>';
  $('view').innerHTML = html;
}
async function recSav(mId, mtId){ await ACT('recordPayment', { member_id:mId, category:'NORMAL_SAVINGS', amount:parseFloat($('amt_' + mId).value), method:'Cash', meeting_id:mtId, by:SESS.user.full_name }); }
function renderMgr(){
  var cfg = DB.mgr.config;
  var html = '<h2>🔄 Merry-go-round (separate fund)</h2>';
  if (!cfg){
    html += '<div class="card"><p>No rotation configured yet.</p>';
    if (can('manage_settings')) html += '<label>Contribution per member</label><input id="mg_a" type="number" value="' + DB.settings.mgr_contribution + '"><label>Rotation order (Ctrl-click in turn)</label><select id="mg_o" multiple size="6">' + DB.members.filter(function(m){return m.status==='Active';}).map(function(m){return '<option value="' + m.id + '">' + esc(m.full_name) + '</option>';}).join('') + '</select><button class="btn big" style="margin-top:8px" onclick="doMgrCfg()">Save rotation</button>';
    html += '</div>';
  } else {
    var next = Core.mgrNextBeneficiary(DB);
    html += '<div class="grid"><div class="card stat gold"><div class="k">Per member</div><div class="v">' + fmt(cfg.amount) + '</div></div>' +
      '<div class="card stat gold"><div class="k">Expected pot per cycle</div><div class="v">' + fmt(cfg.amount * cfg.order.length) + '</div></div>' +
      '<div class="card stat"><div class="k">Current cycle</div><div class="v">#' + Core.currentCycle(DB) + '</div></div>' +
      '<div class="card stat"><div class="k">Next beneficiary</div><div class="v" style="font-size:15px">' + esc(next ? memberName(next) : 'Cycle complete') + '</div></div></div>' +
      '<h3>Rotation order & history</h3><div class="tbl-wrap"><table><tr><th>Turn</th><th>Member</th><th>Status</th><th>Double penalty due</th></tr>' +
      cfg.order.map(function(id, i){
        var paid = DB.mgr.payouts.filter(function(p){return p.member_id===id;});
        var dbl = Core.mgrOutstanding(DB, id) > 0 ? '<span class="pill r">' + fmt(Core.mgrDoublePenaltyAmount(DB, id)) + '</span>' : '—';
        return '<tr><td>' + (i+1) + '</td><td>' + esc(memberName(id)) + '</td><td>' + (paid.length ? '<span class="pill g">paid cycle ' + paid.map(function(p){return p.cycle;}).join(', ') + '</span>' : (next===id ? '<span class="pill y">NEXT</span>' : '<span class="pill b">waiting</span>')) + '</td><td>' + dbl + '</td></tr>';
      }).join('') + '</table></div>' +
      '<h3>Payouts recorded</h3><div class="tbl-wrap"><table><tr><th>Cycle</th><th>Beneficiary</th><th>Amount</th><th>Date</th></tr>' +
      DB.mgr.payouts.map(function(p){ return '<tr><td>#' + p.cycle + '</td><td>' + esc(memberName(p.member_id)) + '</td><td>' + fmt(p.amount) + '</td><td>' + p.date + '</td></tr>'; }).join('') + '</table></div>';
    if (can('record_payments') && next) html += '<button class="btn gold big" style="margin-top:10px" onclick="doMgrPayout()">Record payout to ' + esc(memberName(next)) + '</button>';
  }
  $('view').innerHTML = html;
}
async function doMgrCfg(){
  var order = []; var opts = $('mg_o').selectedOptions || [];
  for (var i=0;i<opts.length;i++) order.push(opts[i].value);
  var amt = parseFloat($('mg_a').value);
  var r = await ACT('mgrConfig', { amount: amt, order: order, frequency: 'Monthly' });
  if (r.ok) await ACT('saveSettings', { patch: { mgr_contribution: amt } }, true);
}
async function doMgrPayout(){ var next = Core.mgrNextBeneficiary(DB); if (next) await ACT('recordMgrPayout', { member_id: next, date: Core.todayISO() }); }
async function doMgrPayoutFromSpin(){ var next = Core.mgrNextBeneficiary(DB); if (next) { var r = await ACT('recordMgrPayout', { member_id: next, date: Core.todayISO() }); if (r.ok) nav('mgr'); } }
function renderFines(){
  var imposed = 0, paid = 0, waived = 0, lateImp = 0;
  DB.attendance.forEach(function(a){ if (a.waived) waived += a.fine_amount; else imposed += a.fine_amount; });
  DB.ledger.forEach(function(e){ if (e.category==='LATE_FINE' && !Core.isReversed(DB,e.id)) lateImp += e.lines[0].debit; });
  DB.payments.forEach(function(p){ if ((p.category==='FINE'||p.category==='LATE_FINE') && p.status==='active') paid += p.amount; });
  var rows = DB.attendance.filter(function(a){return a.fine_amount>0;}).map(function(a){
    var paidHere = DB.payments.filter(function(p){return p.member_id===a.member_id && p.category==='FINE' && p.status==='active' && p.meeting_id===a.meeting_id;}).reduce(function(s,p){return s+p.amount;},0);
    return '<tr><td>' + esc(memberName(a.member_id)) + '</td><td>' + esc(meetingRef(a.meeting_id)) + '</td><td>Attendance (' + a.status + ')</td><td>' + fmt(a.fine_amount) + '</td><td>' + fmt(paidHere) + '</td><td>' + (a.waived ? '<span class="pill b">waived</span>' : (paidHere>=a.fine_amount?'<span class="pill g">paid</span>':'<span class="pill r">owing</span>')) + '</td></tr>'; });
  DB.ledger.filter(function(e){return e.category==='LATE_FINE' && !Core.isReversed(DB,e.id);}).forEach(function(e){
    rows.push('<tr><td>' + esc(memberName(e.member_id)) + '</td><td>' + esc(meetingRef(e.meeting_id)) + '</td><td>Delayed payment (auto)</td><td>' + fmt(e.lines[0].debit) + '</td><td>—</td><td><span class="pill r">owing</span></td></tr>'); });
  $('view').innerHTML = '<h2>⚠️ Fines & penalties register</h2><p class="syncbar">Absence ' + fmt(DB.settings.fine_absence) + ' · Late arrival ' + fmt(DB.settings.fine_late) + ' · Apology ' + fmt(DB.settings.fine_apology) + ' · Delayed payment ' + fmt(DB.settings.late_payment_fine) + '</p>' +
    '<div class="grid"><div class="card stat red"><div class="k">Imposed (attendance)</div><div class="v">' + fmt(imposed) + '</div></div>' +
    '<div class="card stat red"><div class="k">Delayed-payment fines</div><div class="v">' + fmt(lateImp) + '</div></div>' +
    '<div class="card stat"><div class="k">Collected</div><div class="v">' + fmt(paid) + '</div></div>' +
    '<div class="card stat gold"><div class="k">Waived (audited)</div><div class="v">' + fmt(waived) + '</div></div>' +
    '<div class="card stat red"><div class="k">Outstanding</div><div class="v">' + fmt(imposed + lateImp - paid) + '</div></div></div>' +
    '<div class="tbl-wrap" style="margin-top:10px"><table><tr><th>Member</th><th>Meeting</th><th>Type</th><th>Fine</th><th>Paid</th><th>State</th></tr>' + rows.join('') + '</table></div>';
}

/* ==================== PAYMENTS (combined) ==================== */
function renderPayments(){
  var canPay = can('record_payments');
  var html = '<h2>💰 Payment register — Monthly savings & Merry-go-round together</h2>';
  var reg = DB.meetings.length ? Core.contributionRegister(DB, DB.meetings[DB.meetings.length-1]) : [];
  if (canPay && reg.length){
    html += '<div class="card"><h3>Combined contributions register (latest meeting)</h3>' +
      '<div class="tbl-wrap"><table><tr><th>Member</th><th colspan="3">Monthly savings</th><th colspan="2">Merry-go-round</th><th>Record</th></tr>' +
      reg.map(function(r){
        var mgrOut = Core.mgrOutstanding(DB, r.member.id);
        var dbl = mgrOut > 0 ? Core.mgrDoublePenaltyAmount(DB, r.member.id) : 0;
        return '<tr><td><span class="member-link" onclick="openMember(\'' + r.member.id + '\')">' + esc(r.member.full_name) + '</span></td>' +
          '<td>' + fmt(r.expected) + '</td><td>' + fmt(r.paid) + '</td><td>' + (r.outstanding>0?'<span class="pill r">'+fmt(r.outstanding)+'</span>':'<span class="pill g">0</span>') + '</td>' +
          '<td>' + fmt(r.mgr_paid) + '</td><td>' + (mgrOut>0 ? '<span class="pill r">' + fmt(mgrOut) + '</span>' + (dbl>0?' <span class="pill y">2× ' + fmt(dbl) + '</span>':'') : '<span class="pill g">0</span>') + '</td>' +
          '<td><button class="btn sm" onclick="payModal(\'' + r.member.id + '\',\'NORMAL_SAVINGS\',' + DB.settings.contribution_amount + ')">+Monthly</button> ' +
          '<button class="btn sm gold" onclick="payModal(\'' + r.member.id + '\',\'MGR\',' + DB.settings.mgr_contribution + ')">+MGR</button>' +
          (dbl>0 ? ' <button class="btn sm red" onclick="payModal(\'' + r.member.id + '\',\'MGR_DOUBLE\',' + dbl + ')">2×</button>' : '') + '</td></tr>';
      }).join('') + '</table></div>' +
      '<button class="btn" style="margin-top:8px" onclick="payModal(null,null,null)">+ Other payment (welfare, fines, special…)</button></div>';
  }
  html += '<h3>' + (SESS.user.role==='member' ? 'My transactions' : 'All transactions') + '</h3><div class="tbl-wrap"><table><tr><th>Receipt</th><th>Date</th><th>Member</th><th>Category</th><th>Amount</th><th>Method</th><th>Ref</th><th></th></tr>' +
    DB.payments.slice().reverse().map(function(p){
      return '<tr><td>' + esc(p.txn_no) + '</td><td>' + p.date + '</td><td>' + esc(memberName(p.member_id)) + '</td><td>' + esc(catLabel(p.category)) + '</td><td>' + fmt(p.amount) + '</td><td>' + esc(p.method) + '</td><td>' + esc(p.reference||'—') + '</td>' +
      '<td>' + (p.status==='active' ? '<button class="btn sm ghost" onclick="showReceipt(\'' + p.id + '\')">🧾</button> ' + (canPay ? '<button class="btn sm red" onclick="doReverse(\'' + p.id + '\')">↩</button>' : '') : '<span class="pill r">reversed</span>') + '</td></tr>';
    }).join('') + '</table></div>';
  $('view').innerHTML = html;
}
function payModal(mId, category, preset){
  var cats = Object.keys(Core.PAY_CATEGORIES);
  $('modal-root').innerHTML = '<div class="modal"><div class="sheet"><button class="x" onclick="closeModal()">×</button><h3>Record payment</h3>' +
    '<div class="row"><div><label>Member</label><select id="py_m">' + DB.members.filter(function(m){return m.status==='Active';}).map(function(m){return '<option value="' + m.id + '"' + (m.id===mId?' selected':'') + '>' + esc(m.full_name) + '</option>';}).join('') + '</select></div>' +
    '<div><label>Category</label><select id="py_c">' + cats.map(function(k){return '<option value="' + k + '"' + (k===category?' selected':'') + '>' + esc(Core.PAY_CATEGORIES[k].label) + '</option>';}).join('') + '</select></div></div>' +
    '<div class="row"><div><label>Amount (KSh)</label><input id="py_a" type="number" value="' + (preset||'') + '"></div><div><label>Method</label><select id="py_me"><option>Cash</option><option>M-Pesa</option><option>Bank transfer</option></select></div></div>' +
    '<div class="row"><div><label>M-Pesa code / receipt ref</label><input id="py_r"></div><div><label>Date</label><input id="py_d" type="date" value="' + Core.todayISO() + '"></div></div>' +
    '<button class="btn big" style="margin-top:8px" onclick="doPayment()">Record payment & issue receipt</button></div></div>';
}
var LAST_RECEIPT = null;
async function doPayment(){
  var o = { member_id: $('py_m').value, category: $('py_c').value, amount: parseFloat($('py_a').value), method: $('py_me').value, reference: $('py_r').value.trim(), date: $('py_d').value, by: SESS.user.full_name };
  var r = await ACT('recordPayment', o, true);
  if (r.ok){ closeModal(); LAST_RECEIPT = r.result.id; nav('payments'); showReceipt(LAST_RECEIPT); }
}
function showReceipt(pid){
  var p = DB.payments.filter(function(x){return x.id===pid;})[0]; if (!p) return;
  var m = DB.members.filter(function(x){return x.id===p.member_id;})[0];
  $('modal-root').innerHTML = '<div class="modal"><div class="sheet"><button class="x" onclick="closeModal()">×</button>' +
    '<div style="text-align:center"><h2 style="color:var(--green)">' + esc(DB.settings.group_name) + '</h2><p style="font-size:12px">' + esc(DB.settings.reg_no||'') + '</p><h3>OFFICIAL RECEIPT</h3></div>' +
    '<table style="width:100%"><tr><td><b>Receipt no</b></td><td>' + esc(p.txn_no) + '</td></tr>' +
    '<tr><td><b>Date</b></td><td>' + p.date + '</td></tr><tr><td><b>Received from</b></td><td>' + esc(m ? m.full_name : '—') + '</td></tr>' +
    '<tr><td><b>For</b></td><td>' + esc(catLabel(p.category)) + '</td></tr>' +
    '<tr><td><b>Amount</b></td><td style="font-size:20px;font-weight:800;color:var(--green)">' + fmt(p.amount) + '</td></tr>' +
    '<tr><td><b>Method</b></td><td>' + esc(p.method) + (p.reference ? ' · ' + esc(p.reference) : '') + '</td></tr>' +
    '<tr><td><b>Received by</b></td><td>' + esc(p.received_by) + '</td></tr></table>' +
    '<p style="font-size:12px;color:var(--muted);margin-top:10px">Reversals only — never deleted (audited).</p>' +
    '<button class="btn big" onclick="printReceipt(\'' + p.id + '\')">🖨 Print / share</button></div></div>';
}
function printReceipt(pid){
  var p = DB.payments.filter(function(x){return x.id===pid;})[0];
  var m = DB.members.filter(function(x){return x.id===p.member_id;})[0];
  var w = window.open('', '_blank');
  w.document.write('<html><head><title>Receipt ' + esc(p.txn_no) + '</title><style>body{font-family:Segoe UI;padding:30px}table td{padding:6px 12px}</style></head><body>' +
    '<h1 style="color:#0b5d3b">' + esc(DB.settings.group_name) + ' — CHAMA CHETU</h1><h2>OFFICIAL RECEIPT ' + esc(p.txn_no) + '</h2>' +
    '<table><tr><td>Date</td><td>' + p.date + '</td></tr><tr><td>Received from</td><td>' + esc(m ? m.full_name : '') + '</td></tr>' +
    '<tr><td>For</td><td>' + esc(catLabel(p.category)) + '</td></tr><tr><td>Amount</td><td><b>' + fmt(p.amount) + '</b></td></tr>' +
    '<tr><td>Method</td><td>' + esc(p.method) + ' ' + esc(p.reference||'') + '</td></tr><tr><td>Received by</td><td>' + esc(p.received_by) + '</td></tr></table>' +
    '<p style="margin-top:40px">Signature: ______________________</p></body></html>');
  w.document.close(); w.print();
}
async function doReverse(pid){
  var reason = prompt('Reason for reversal (recorded in audit log):');
  if (!reason) return;
  var p = DB.payments.filter(function(x){return x.id===pid;})[0];
  await ACT('reverse', { entry_id: p.ledger_id, reason: reason });
}

/* ==================== SPIN ==================== */
var SPIN = { animating: false };
function renderSpin(){
  var eligible = Core.spinEligible(DB);
  var openM = DB.meetings.filter(function(m){return m.status==='open';})[0];
  var next = Core.mgrNextBeneficiary(DB);
  $('view').innerHTML = '<h2>🎯 Spin to select the next merry-go-round beneficiary</h2>' +
    '<p class="syncbar">Winner is chosen with a genuine CSPRNG on the SERVER before the animation; fully audited.</p>' +
    '<div class="card stat gold"><div class="k">Current next beneficiary</div><div class="v" style="font-size:16px">' + esc(next ? memberName(next) : 'Spin to select') + '</div></div>' +
    (openM ? '' : '<div class="card" style="border-left:4px solid var(--gold)">No open meeting — schedule one before spinning.</div>') +
    '<div class="wheel-wrap"><canvas id="wheel" width="680" height="680"></canvas></div>' +
    '<div class="card"><b>Eligible members (' + eligible.length + ')</b>: ' + eligible.map(function(m){return esc(m.full_name);}).join(' · ') + '</div>' +
    (can('spin_beneficiary') && openM && eligible.length ? '<button id="spinBtn" class="btn gold big" style="margin-top:10px" onclick="doSpin()">🎡 SPIN TO SELECT NEXT MERRY-GO-ROUND BENEFICIARY</button>' : '') +
    '<h3>Past selections (auditable)</h3><div class="tbl-wrap"><table><tr><th>Date</th><th>Meeting</th><th>Selected</th><th>By</th></tr>' +
    DB.spin_history.slice().reverse().map(function(h){ return '<tr><td>' + h.date + '</td><td>' + esc(h.meeting_ref||'—') + '</td><td>' + esc(memberName(h.winner)) + '</td><td>' + esc(h.by) + '</td></tr>'; }).join('') + '</table></div>';
  drawWheel(eligible, -1);
}
function drawWheel(names, highlightIdx){
  var cv = $('wheel'); if (!cv || !cv.getContext) return;
  var ctx = cv.getContext('2d'); if (!ctx) return;
  var cx = 340, cy = 340, R = 320, n = names.length;
  var colors = ['#0b5d3b','#0e7a4d','#c9a227','#1c5d99','#2e8b57','#8a6d00','#145a86','#0f8a5f'];
  ctx.clearRect(0,0,680,680);
  ctx.save(); ctx.translate(cx,cy); ctx.rotate(SPIN.angle || 0);
  if (!n) { ctx.restore(); return; }
  names.forEach(function(m, i){
    var a0 = i*2*Math.PI/n, a1 = (i+1)*2*Math.PI/n;
    ctx.beginPath(); ctx.moveTo(0,0); ctx.arc(0,0,R,a0,a1); ctx.closePath();
    ctx.fillStyle = colors[i % colors.length]; ctx.fill(); ctx.strokeStyle = '#fff'; ctx.lineWidth = 3; ctx.stroke();
    ctx.save(); ctx.rotate(a0 + Math.PI/n); ctx.textAlign = 'right'; ctx.fillStyle = '#fff';
    ctx.font = 'bold 26px sans-serif'; ctx.fillText(m.full_name.split(' ')[0] + ' ' + (m.full_name.split(' ')[1]||'').slice(0,1) + '.', R-14, 9);
    ctx.restore();
  });
  ctx.restore();
  ctx.beginPath(); ctx.arc(cx,cy,60,0,2*Math.PI); ctx.fillStyle='#0b3d27'; ctx.fill();
  ctx.fillStyle='#c9a227'; ctx.font='bold 34px sans-serif'; ctx.textAlign='center'; ctx.fillText('SPIN',cx,cy+14);
  ctx.fillStyle='#0b3d27'; ctx.beginPath(); ctx.moveTo(cx-16,10); ctx.lineTo(cx+16,10); ctx.lineTo(cx,44); ctx.closePath(); ctx.fill();
  if (highlightIdx >= 0){ ctx.beginPath(); ctx.arc(cx,cy,R+6,0,2*Math.PI); ctx.strokeStyle='#c9a227'; ctx.lineWidth=8; ctx.stroke(); }
}
var PENDING_SPIN = null;
async function doSpin(){
  if (SPIN.animating) return;
  var openM = DB.meetings.filter(function(m){return m.status==='open';})[0];
  var r = await ACT('spinSelect', { meeting_id: openM.id }, true);
  if (!r.ok) return;
  /* server already decided the winner (CSPRNG) and stored the audit record */
  var eligible = DB.spin_history[DB.spin_history.length-1] ? Core.spinEligible(DB) : [];
  var winnerId = r.result.winner.id || r.result.winner;
  var winIdx = eligible.map(function(m){return m.id;}).indexOf(winnerId);
  var w = DB.members.filter(function(x){return x.id===winnerId;})[0];
  SPIN.animating = true; SPIN.angle = SPIN.angle || 0;
  var seg = 2*Math.PI/Math.max(eligible.length,1);
  var target = -(winIdx*seg + seg/2) - Math.PI/2 - 0.0001;
  var full = target + Math.ceil((SPIN.angle - target)/(2*Math.PI) + 5)*2*Math.PI;
  var t0 = null, dur = 4200, spinStart = SPIN.angle;
  function frame(ts){
    if (!t0) t0 = ts;
    var k = Math.min((ts-t0)/dur, 1), ease = 1 - Math.pow(1-k, 3);
    SPIN.angle = spinStart + (full - spinStart)*ease;
    drawWheel(eligible, -1);
    if (k < 1) requestAnimationFrame(frame);
    else {
      SPIN.animating = false; drawWheel(eligible, winIdx);
      $('modal-root').innerHTML = '<div class="modal"><div class="sheet"><div class="winner-banner">🎉 ' + esc(w.full_name) + '<br><span style="font-size:14px">(' + esc(w.m_no) + ') is the next MERRY-GO-ROUND BENEFICIARY</span></div>' +
        '<p style="font-size:13px">Selected by secure server-side CSPRNG · recorded & audited.</p>' +
        (can('record_payments') ? '<button class="btn gold big" onclick="closeModal();doMgrPayoutFromSpin()">Record payout now</button> ' : '') +
        '<button class="btn ghost big" onclick="closeModal();nav(\'spin\')">Later</button></div></div>';
      toast('Winner: ' + w.full_name, 'ok');
    }
  }
  requestAnimationFrame(frame);
}

/* ==================== SHARE-OUT ==================== */
function renderShareOut(){
  var s = Core.shareOutPreview(DB);
  var html = '<h2>🤝 Sharing of savings</h2><p class="syncbar">Fixed amount to every member with savings on a set date — audited.</p>';
  if (s.configured){
    html += '<div class="grid"><div class="card stat blue"><div class="k">Amount per member</div><div class="v">' + fmt(s.share_amount) + '</div></div>' +
      '<div class="card stat blue"><div class="k">Share date</div><div class="v" style="font-size:15px">' + esc(s.share_date || 'any') + '</div></div>' +
      '<div class="card stat"><div class="k">Members receiving</div><div class="v">' + s.recipients + '</div></div>' +
      '<div class="card stat gold"><div class="k">Total to be shared</div><div class="v">' + fmt(s.total) + '</div></div>' +
      '<div class="card stat"><div class="k">Available cash</div><div class="v">' + fmt(s.available_cash) + '</div></div>' +
      '<div class="card stat ' + (s.status==='executed'?'':'red') + '"><div class="k">Status</div><div class="v" style="font-size:15px">' + esc(s.status) + '</div></div></div>';
  } else html += '<div class="card"><p>No share-out configured yet.</p></div>';
  if (can('configure_shareout')){
    html += '<div class="card" style="margin-top:10px"><h3>Configure / re-schedule</h3>' +
      '<div class="row"><div><label>Amount per member (KSh)</label><input id="so_amt" type="number" value="' + (s.share_amount||500) + '"></div>' +
      '<div><label>Share date</label><input id="so_date" type="date" value="' + (s.share_date||'') + '"></div></div>' +
      '<button class="btn big" style="margin-top:8px" onclick="doCfgShareOut()">Save share-out plan</button></div>';
  }
  if (can('execute_shareout') && s.configured && s.status!=='executed')
    html += '<button class="btn gold big" style="margin-top:10px" onclick="doExecShareOut()">🤝 Execute share-out NOW (' + fmt(s.total) + ' to ' + s.recipients + ' members)</button>';
  html += '<h3>History</h3>' + (DB.shareouts.length ?
    '<div class="tbl-wrap"><table><tr><th>Date</th><th>Per member</th><th>Members</th><th>Total</th></tr>' +
    DB.shareouts.map(function(x){ return '<tr><td>' + x.date + '</td><td>' + fmt(x.per_member) + '</td><td>' + x.members + '</td><td>' + fmt(x.total) + '</td></tr>'; }).join('') + '</table></div>'
    : '<div class="card">None yet.</div>');
  $('view').innerHTML = html;
}
async function doCfgShareOut(){ await ACT('configureShareOut', { share_amount: parseFloat($('so_amt').value), share_date: $('so_date').value }); }
async function doExecShareOut(){
  if (!confirm('Execute the share-out now? This is audited and cannot be deleted.')) return;
  await ACT('executeShareOut', { date: Core.todayISO() });
}

/* ==================== INVESTMENTS / EXPENSES ==================== */
function renderInvestments(){
  var pos = Core.financialPosition(DB);
  $('view').innerHTML = '<h2>📈 Investments</h2>' +
    '<div class="card stat blue"><div class="k">Capital invested (NOT available cash)</div><div class="v">' + fmt(pos.investments) + '</div></div>' +
    (can('record_investments') ? '<button class="btn" onclick="invForm()">+ Propose / record investment</button>' : '') +
    '<div style="margin-top:10px"><div class="tbl-wrap"><table><tr><th>Ref</th><th>Description</th><th>Amount</th><th>Expected</th><th>Actual</th><th>Status</th></tr>' +
    DB.investments.map(function(v){ return '<tr><td>' + esc(v.ref) + '</td><td>' + esc(v.desc) + '</td><td>' + fmt(v.amount) + '</td><td>' + fmt(v.expected_return) + '</td><td>' + fmt(v.actual_return) + '</td><td><span class="pill ' + (v.status==='active'?'g':'y') + '">' + esc(v.status) + '</span></td></tr>'; }).join('') + '</table></div></div>';
}
function invForm(){
  $('modal-root').innerHTML = '<div class="modal"><div class="sheet"><button class="x" onclick="closeModal()">×</button><h3>Investment</h3>' +
    '<label>Description</label><input id="iv_d"><label>Category</label><select id="iv_c"><option>Business</option><option>Agriculture</option><option>Livestock</option><option>Other</option></select>' +
    '<div class="row"><div><label>Amount (KSh)</label><input id="iv_a" type="number"></div><div><label>Source</label><select id="iv_s"><option>CASH</option><option>MPESA</option></select></div></div>' +
    '<div class="row"><div><label>Expected return</label><input id="iv_e" type="number"></div><div><label>Status</label><select id="iv_st"><option value="proposed">Proposed</option><option value="active">Active (post capital now)</option></select></div></div>' +
    '<button class="btn big" style="margin-top:10px" onclick="doInv()">Save</button></div></div>';
}
async function doInv(){ var r = await ACT('addInvestment', { desc:$('iv_d').value, amount:parseFloat($('iv_a').value), category:$('iv_c').value, source:$('iv_s').value, expected_return:parseFloat($('iv_e').value), status:$('iv_st').value }); if (r.ok) closeModal(); }
function renderExpenses(){
  $('view').innerHTML = '<h2>🧾 Group expenditure</h2>' +
    (can('record_expenses') ? '<button class="btn" onclick="expForm()">+ Record expense</button>' : '') +
    '<div style="margin-top:10px"><div class="tbl-wrap"><table><tr><th>Ref</th><th>Description</th><th>Category</th><th>Amount</th><th>Payee</th><th>Approved by</th></tr>' +
    DB.expenses.map(function(e){ return '<tr><td>' + esc(e.ref) + '</td><td>' + esc(e.desc) + '</td><td>' + esc(e.category) + '</td><td>' + fmt(e.amount) + '</td><td>' + esc(e.payee) + '</td><td>' + esc(e.approved_by) + '</td></tr>'; }).join('') + '</table></div></div>';
}
function expForm(){
  $('modal-root').innerHTML = '<div class="modal"><div class="sheet"><button class="x" onclick="closeModal()">×</button><h3>Group expense</h3>' +
    '<label>Description</label><input id="ex_d"><label>Category</label><select id="ex_c"><option>Operations</option><option>Statutory</option><option>Welfare payout</option><option>Meeting costs</option></select>' +
    '<div class="row"><div><label>Amount (KSh)</label><input id="ex_a" type="number"></div><div><label>Source</label><select id="ex_s"><option>CASH</option><option>MPESA</option></select></div></div>' +
    '<div class="row"><div><label>Payee</label><input id="ex_p"></div><div><label>Receipt no</label><input id="ex_r"></div></div>' +
    '<button class="btn big" style="margin-top:10px" onclick="doExp()">Save</button></div></div>';
}
async function doExp(){ var r = await ACT('addExpense', { desc:$('ex_d').value, amount:parseFloat($('ex_a').value), category:$('ex_c').value, source:$('ex_s').value, payee:$('ex_p').value, receipt:$('ex_r').value, approved_by:SESS.user.full_name }); if (r.ok) closeModal(); }

/* ==================== REPORTS ==================== */
var REPORTS = [
  ['members','Membership register'], ['attendance','Meeting attendance register'], ['fines','Fines & penalties register'],
  ['savings','Monthly savings register'], ['mgr','Merry-go-round register'], ['payments','General payment register'],
  ['inv','Investment register'], ['exp','Expenditure register'], ['shareout','Share-out register'],
  ['pnl','Income & expenditure statement'], ['pos','Group financial position'], ['trial','Trial balance (ledger)']
];
function renderReports(){
  $('view').innerHTML = '<h2>📊 Reports & exports</h2>' +
    '<div class="menu-grid" style="grid-template-columns:repeat(2,1fr)">' +
    REPORTS.map(function(r){ return '<div class="mi" onclick="showReport(\'' + r[0] + '\')"><div class="ic">📄</div><div class="t">' + r[1] + '</div></div>'; }).join('') + '</div><div id="rpt"></div>';
}
function showReport(key){
  var rows = [], head = [], title = '';
  if (key==='members'){ title='Membership register'; head=['No','Name','Gender','Phone','Village','Status','Joined'];
    DB.members.forEach(function(m){ rows.push([m.m_no,m.full_name,m.gender,m.phone,m.village,m.status,m.joined]); }); }
  else if (key==='attendance'){ title='Meeting attendance register'; head=['Meeting','Date','Member','Status','Fine'];
    DB.attendance.forEach(function(a){ rows.push([meetingRef(a.meeting_id), mtDate(a.meeting_id), memberName(a.member_id), a.status, a.fine_amount]); }); }
  else if (key==='fines'){ title='Fines & penalties register'; head=['Meeting','Member','Type','Amount','Waived'];
    DB.attendance.filter(function(a){return a.fine_amount>0;}).forEach(function(a){ rows.push([meetingRef(a.meeting_id), memberName(a.member_id), 'Attendance ('+a.status+')', a.fine_amount, a.waived?'YES':'no']); });
    DB.ledger.filter(function(e){return e.category==='LATE_FINE' && !Core.isReversed(DB,e.id);}).forEach(function(e){ rows.push([meetingRef(e.meeting_id), memberName(e.member_id), 'Delayed payment', e.lines[0].debit, 'no']); }); }
  else if (key==='savings'){ title='Monthly savings register'; head=['Receipt','Date','Member','Amount','Method','Ref'];
    DB.payments.filter(function(p){return p.category==='NORMAL_SAVINGS';}).forEach(function(p){ rows.push([p.txn_no,p.date,memberName(p.member_id),p.amount,p.method,p.reference]); }); }
  else if (key==='mgr'){ title='Merry-go-round register'; head=['Receipt','Date','Member','Category','Amount'];
    DB.payments.filter(function(p){return p.category==='MGR'||p.category==='MGR_DOUBLE';}).forEach(function(p){ rows.push([p.txn_no,p.date,memberName(p.member_id),catLabel(p.category),p.amount]); });
    DB.mgr.payouts.forEach(function(p){ rows.push(['PAYOUT','#'+p.cycle+' '+p.date,memberName(p.member_id),'Payout','-'+p.amount]); }); }
  else if (key==='payments'){ title='General payment register'; head=['Receipt','Date','Member','Category','Amount','Method','Ref','Status'];
    DB.payments.forEach(function(p){ rows.push([p.txn_no,p.date,memberName(p.member_id),catLabel(p.category),p.amount,p.method,p.reference,p.status]); }); }
  else if (key==='inv'){ title='Investment register'; head=['Ref','Description','Amount','Expected','Actual','Status'];
    DB.investments.forEach(function(v){ rows.push([v.ref,v.desc,v.amount,v.expected_return,v.actual_return,v.status]); }); }
  else if (key==='exp'){ title='Expenditure register'; head=['Ref','Description','Category','Amount','Payee'];
    DB.expenses.forEach(function(e){ rows.push([e.ref,e.desc,e.category,e.amount,e.payee]); }); }
  else if (key==='shareout'){ title='Share-out register'; head=['Date','Per member','Members','Total','By'];
    DB.shareouts.forEach(function(s){ rows.push([s.date,s.per_member,s.members,s.total,s.by]); }); }
  else if (key==='pnl'){ title='Income & expenditure statement'; head=['Item','Amount (KSh)'];
    var p = Core.financialPosition(DB);
    rows.push(['Income: Fines & penalties', p.fine_income],['Total income', p.fine_income],['Expenditure', p.expenses],['Net surplus', p.fine_income-p.expenses]); }
  else if (key==='pos'){ title='Group financial position'; head=['Account','Amount (KSh)'];
    var pp = Core.financialPosition(DB);
    rows.push(['Cash box',pp.cash],['M-Pesa / bank',pp.mpesa],['Fines receivable',pp.fines_receivable],['Investments',pp.investments],
      ['TOTAL ASSETS',pp.total_position],['Member monthly savings',pp.savings],['Special savings',pp.special],['Merry-go-round fund',pp.mgr_fund],['Welfare fund',pp.welfare],['Available cash (liquid only)',pp.available_cash]); }
  else if (key==='trial'){ title='Trial balance (double-entry ledger)'; head=['Account','Debits','Credits','Balance'];
    var agg = {};
    DB.ledger.forEach(function(e){ e.lines.forEach(function(l){ if (e.reversal_of) return; var a = agg[l.account] = agg[l.account] || {d:0,c:0}; a.d += l.debit; a.c += l.credit; }); });
    Object.keys(agg).sort().forEach(function(k){ rows.push([k, agg[k].d.toFixed(2), agg[k].c.toFixed(2), (agg[k].d-agg[k].c).toFixed(2)]); }); }
  CUR.report = { title: title, head: head, rows: rows };
  $('rpt').innerHTML = '<h3 style="margin-top:14px">' + esc(title) + '</h3>' +
    '<button class="btn sm ghost" onclick="printReport()">🖨 Print / PDF</button> <button class="btn sm ghost" onclick="csvReport()">⬇ CSV/Excel</button>' +
    '<div class="tbl-wrap" style="margin-top:8px"><table><tr>' + head.map(function(h){return '<th>'+esc(h)+'</th>';}).join('') + '</tr>' +
    rows.map(function(r){ return '<tr>' + r.map(function(c){return '<td>' + esc(c) + '</td>';}).join('') + '</tr>'; }).join('') + '</table></div>';
}
function printReport(){
  var r = CUR.report;
  var w = window.open('', '_blank');
  w.document.write('<html><head><title>' + esc(r.title) + '</title><style>body{font-family:Segoe UI;padding:26px}table{border-collapse:collapse;width:100%}th,td{border:1px solid #999;padding:5px 8px;font-size:12px}th{background:#0b5d3b;color:#fff}.sig{margin-top:50px;display:flex;justify-content:space-between}</style></head><body>' +
    '<h1 style="color:#0b5d3b">' + esc(DB.settings.group_name) + ' — CHAMA CHETU</h1><h2>' + esc(r.title) + '</h2><p>Period up to ' + Core.todayISO() + ' · Prepared by ' + esc(SESS.user.full_name) + '</p>' +
    '<table><tr>' + r.head.map(function(h){return '<th>'+esc(h)+'</th>';}).join('') + '</tr>' +
    r.rows.map(function(row){ return '<tr>' + row.map(function(c){return '<td>' + esc(c) + '</td>';}).join('') + '</tr>'; }).join('') + '</table>' +
    '<div class="sig"><div>Treasurer: ____________</div><div>Chairperson: ____________</div><div>Date: ____________</div></div></body></html>');
  w.document.close(); w.print();
}
function csvReport(){ var r = CUR.report; download(r.title.toLowerCase().replace(/[^a-z0-9]+/g,'-') + '.csv', Core.toCSV([r.head].concat(r.rows)), 'text/csv'); }

/* ==================== SETTINGS / USERS / AUDIT ==================== */
var USERS = [];
function renderSettings(){
  var s = DB.settings, canCfg = can('manage_settings'), isAdmin = SESS.user.role === 'admin';
  var sh = Core.shareOutPreview(DB);
  $('view').innerHTML = '<h2>⚙️ Settings</h2><div class="card">' +
    field('st_gn','Group name', s.group_name) + field('st_rn','Registration no', s.reg_no) + field('st_ct','Contact', s.contact) +
    '<div class="row"><div>' + fieldSel('st_fr','Meeting frequency', ['Monthly','Fortnightly','Custom'], s.meeting_frequency) + '</div><div>' + fieldN('st_ca','Monthly contribution', s.contribution_amount) + '</div></div>' +
    '<div class="row"><div>' + fieldN('st_mg','Merry-go-round contribution', s.mgr_contribution) + '</div><div>' + fieldN('st_lp','Delayed-payment fine', s.late_payment_fine) + '</div></div>' +
    '<div class="row"><div>' + fieldN('st_fx','Absence fine', s.fine_absence) + '</div><div>' + fieldN('st_fl','Late-arrival fine', s.fine_late) + '</div></div>' +
    '<div class="row"><div>' + fieldN('st_fa','Apology fine', s.fine_apology) + '</div><div><label>&nbsp;</label><button class="btn ghost sm" onclick="changePwdForm()">Change my password</button></div></div>' +
    (canCfg ? '<button class="btn big" style="margin-top:10px" onclick="saveSettings()">Save settings</button>' : '<p class="syncbar">Read-only: only Administrator/Chairperson can change policies.</p>') + '</div>' +
    '<h3>🤝 Share-out plan</h3><div class="card">' +
    (sh.configured ? '<p>Scheduled: <b>' + fmt(sh.share_amount) + '</b> per member on <b>' + esc(sh.share_date||'—') + '</b> — ' + sh.recipients + ' recipients (' + esc(sh.status) + '). Manage on the Share-Out screen.</p>' : '<p>Not configured. Set it on the Share-Out screen.</p>') + '</div>' +
    '<h3>👥 User accounts (server-enforced roles)</h3>' +
    (isAdmin ? '<button class="btn sm" onclick="addUserForm()">+ Add user</button>' : '') +
    '<div class="tbl-wrap" style="margin-top:6px"><table><tr><th>User</th><th>Role</th>' + (isAdmin?'<th>Assign role</th><th>Status</th><th>Reset pwd</th>':'') + '</tr>' +
    USERS.map(function(u){
      return '<tr><td>' + esc(u.full_name) + ' <span style="font-size:11px;color:var(--muted)">(' + esc(u.username) + ')</span></td><td><span class="pill b">' + u.role + '</span>' + (u.status==='disabled'?' <span class="pill r">disabled</span>':'') + '</td>' +
      (isAdmin ? '<td><div class="row"><select id="ur_' + u.username + '">' + Core.ROLES.map(function(r){return '<option ' + (u.role===r?'selected':'') + '>' + r + '</option>';}).join('') + '</select><button class="btn sm" onclick="doSetRole(\'' + esc(u.username) + '\')">Set</button></div></td>' +
        '<td><button class="btn sm ' + (u.status==='active'?'red':'ghost') + '" onclick="doUserStatus(\'' + esc(u.username) + '\',\'' + (u.status==='active'?'disabled':'active') + '\')">' + (u.status==='active'?'Disable':'Enable') + '</button></td>' +
        '<td><button class="btn sm ghost" onclick="resetPwdForm(\'' + esc(u.username) + '\')">Reset</button></td>' : '') + '</tr>';
    }).join('') + '</table></div>' +
    '<p class="syncbar">Roles are enforced on the SERVER on every request. Disabled users cannot log in. The last administrator cannot be demoted or disabled.</p>';
}
function field(id, label, v){ return '<label>' + label + '</label><input id="' + id + '" value="' + esc(v) + '" ' + (can('manage_settings')?'':'disabled') + '>'; }
function fieldN(id, label, v){ return '<label>' + label + '</label><input id="' + id + '" type="number" value="' + v + '" ' + (can('manage_settings')?'':'disabled') + '>'; }
function fieldSel(id, label, opts, v){ return '<label>' + label + '</label><select id="' + id + '" ' + (can('manage_settings')?'':'disabled') + '>' + opts.map(function(o){return '<option ' + (o===v?'selected':'') + '>' + o + '</option>';}).join('') + '</select>'; }
async function saveSettings(){
  await ACT('saveSettings', { patch: { group_name:$('st_gn').value, reg_no:$('st_rn').value, contact:$('st_ct').value,
    meeting_frequency:$('st_fr').value, contribution_amount:parseFloat($('st_ca').value), mgr_contribution:parseFloat($('st_mg').value),
    late_payment_fine:parseFloat($('st_lp').value), fine_absence:parseFloat($('st_fx').value), fine_late:parseFloat($('st_fl').value), fine_apology:parseFloat($('st_fa').value) } });
}
function changePwdForm(){
  $('modal-root').innerHTML = '<div class="modal"><div class="sheet"><button class="x" onclick="closeModal()">×</button><h3>Change my password</h3>' +
    '<label>Current password</label><input id="cp_cur" type="password"><label>New password (min 8)</label><input id="cp_new" type="password"><label>Confirm</label><input id="cp_new2" type="password">' +
    '<button class="btn big" style="margin-top:10px" onclick="doChangePwd()">Change password</button></div></div>';
}
async function doChangePwd(){
  if ($('cp_new').value !== $('cp_new2').value) return toast('New passwords do not match', 'err');
  var r = await api('POST', '/api/password', { current: $('cp_cur').value, next: $('cp_new').value });
  if (!r.ok) return toast(r.json.error, 'err');
  closeModal(); toast('Password changed ✔', 'ok');
}
function addUserForm(){
  $('modal-root').innerHTML = '<div class="modal"><div class="sheet"><button class="x" onclick="closeModal()">×</button><h3>Add user (real account)</h3>' +
    '<div class="row"><div><label>Username</label><input id="au_u"></div><div><label>Full name</label><input id="au_f"></div></div>' +
    '<div class="row"><div><label>Role</label><select id="au_r">' + Core.ROLES.map(function(r){return '<option>' + r + '</option>';}).join('') + '</select></div><div><label>Temporary password (min 8)</label><input id="au_p"></div></div>' +
    '<label>Link to member (for ordinary members)</label><select id="au_m"><option value="">— none —</option>' + DB.members.map(function(m){return '<option value="' + m.id + '">' + esc(m.full_name) + '</option>';}).join('') + '</select>' +
    '<p style="font-size:12px;color:var(--muted)">The user must change this temporary password at first sign-in.</p>' +
    '<button class="btn big" style="margin-top:10px" onclick="doAddUser()">Create user</button></div></div>';
}
async function doAddUser(){
  var r = await api('POST', '/api/users', { username:$('au_u').value.trim(), full_name:$('au_f').value.trim(), role:$('au_r').value, password:$('au_p').value, member_id:$('au_m').value || null });
  if (!r.ok) return toast(r.json.error, 'err');
  closeModal(); toast('User created — must change password at first sign-in ✔', 'ok'); await loadUsers(); nav('settings');
}
async function doSetRole(un){
  var r = await api('POST', '/api/users/role', { username: un, role: $('ur_' + un).value });
  if (!r.ok) return toast(r.json.error, 'err');
  toast('Role set — audited on server ✔', 'ok'); await refreshState(); nav('settings');
}
async function doUserStatus(un, st){
  var r = await api('POST', '/api/users/status', { username: un, status: st });
  if (!r.ok) return toast(r.json.error, 'err');
  toast('User ' + st + ' — audited ✔', 'ok'); await loadUsers(); nav('settings');
}
function resetPwdForm(un){
  $('modal-root').innerHTML = '<div class="modal"><div class="sheet"><button class="x" onclick="closeModal()">×</button><h3>Reset password — ' + esc(un) + '</h3>' +
    '<label>New temporary password (min 8)</label><input id="rp_n" type="password">' +
    '<p style="font-size:12px;color:var(--muted)">Their sessions are ended; they must change it at next sign-in.</p>' +
    '<button class="btn big" style="margin-top:10px" onclick="doResetPwd(\'' + esc(un) + '\')">Reset</button></div></div>';
}
async function doResetPwd(un){
  var r = await api('POST', '/api/users/reset-password', { username: un, new_password: $('rp_n').value });
  if (!r.ok) return toast(r.json.error, 'err');
  closeModal(); toast('Password reset ✔', 'ok');
}
async function loadUsers(){ var r = await api('GET', '/api/users'); if (r.ok) USERS = r.json.users || []; }
function renderAttendanceList(){
  $('view').innerHTML = '<h2>✅ Attendance registers</h2><p class="syncbar">Mark P · A · X · L inside each meeting workspace — fines post automatically.</p>' +
    '<div class="tbl-wrap"><table><tr><th>Meeting</th><th>Date</th><th>Status</th><th></th></tr>' +
    DB.meetings.slice().reverse().map(function(m){
      var rows = DB.attendance.filter(function(a){return a.meeting_id===m.id;});
      return '<tr><td>' + esc(m.ref) + '</td><td>' + m.date + '</td><td><span class="pill ' + (m.status==='open'?'y':'b') + '">' + m.status + '</span> (' + rows.length + ' marked)</td>' +
        '<td><button class="btn sm" onclick="CUR.meeting=\'' + m.id + '\';nav(\'meeting\')">Open register</button></td></tr>';
    }).join('') + '</table></div>';
}
function renderAudit(){
  var agg = {}, d = 0, c = 0;
  DB.ledger.forEach(function(e){ e.lines.forEach(function(l){ if (e.reversal_of) return; var a = agg[l.account] = agg[l.account]||{d:0,c:0}; a.d+=l.debit; a.c+=l.credit; d+=l.debit; c+=l.credit; }); });
  $('view').innerHTML = '<h2>🛡️ Audit, backup & ledger</h2>' +
    '<div class="grid"><div class="card stat"><div class="k">Ledger entries</div><div class="v">' + DB.ledger.length + '</div></div>' +
    '<div class="card stat"><div class="k">Total debits</div><div class="v">' + fmt(d) + '</div></div>' +
    '<div class="card stat"><div class="k">Total credits</div><div class="v">' + fmt(c) + '</div></div>' +
    '<div class="card stat ' + (Math.abs(d-c)<0.01?'':'red') + '"><div class="k">Ledger balance check</div><div class="v">' + (Math.abs(d-c)<0.01?'BALANCED ✔':'ERROR') + '</div></div></div>' +
    (SESS.user.role==='admin' ? '<h3>Backup & restore (server-side)</h3><div class="card"><button class="btn" onclick="serverBackup()">⬇ Download server backup (JSON, admins only)</button>' +
      ' <label style="display:inline;font-size:12px">Restore: </label><input type="file" id="rst" accept=".json" style="width:auto" onchange="serverRestore(this)"><p style="font-size:12px;color:var(--muted)">A pre-restore snapshot is kept automatically as a rollback point.</p></div>' : '') +
    '<h3>Audit trail (server log — tamper-resistant)</h3><div class="tbl-wrap"><table><tr><th>When</th><th>Action</th><th>Details</th><th>By</th></tr>' +
    (AUDROWS.length ? AUDROWS : DB.audit.slice().reverse().slice(0,40)).map(function(a){
      return '<tr><td>' + String(a.at||'').slice(0,19).replace('T',' ') + '</td><td>' + esc(a.action) + '</td><td>' + esc(a.details || a.reason || '') + '</td><td>' + esc(a.actor || a.by || '') + '</td></tr>'; }).join('') + '</table></div>';
}
var AUDROWS = [];
async function loadAudit(){ try { var r = await api('GET', '/api/audit'); if (r.ok) AUDROWS = r.json.rows || []; } catch(e){} }
async function serverBackup(){
  var r = await fetch('/api/backup', { headers: { 'X-CSRF-Token': SESS.csrf } });
  if (!r.ok) return toast('Backup denied', 'err');
  var j = await r.json();
  download('chama-chetu-server-backup-' + Core.todayISO() + '.json', JSON.stringify(j), 'application/json');
}
async function serverRestore(inp){
  var f = inp.files[0]; if (!f) return;
  if (!confirm('Restore this backup? Current data is snapshotted first as a rollback point.')) return;
  var rd = new FileReader();
  rd.onload = async function(){
    try {
      var b = JSON.parse(rd.result);
      var r = await api('POST', '/api/restore', b);
      if (!r.ok) return toast(r.json.error, 'err');
      DB = r.json.state; DB.version = r.json.version; toast('Restore complete (rollback point kept) ✔', 'ok'); nav('dashboard');
    } catch(e){ toast('Restore failed: ' + e.message, 'err'); }
  };
  rd.readAsText(f);
}

/* ==================== BOOT ==================== */
RENDER = { dashboard:renderDashboard, members:renderMembers, meetings:renderMeetings, payments:renderPayments,
  shareout:renderShareOut, spin:renderSpin, attendance:renderAttendanceList, savings:renderSavings,
  mgr:renderMgr, fines:renderFines, investments:renderInvestments, expenses:renderExpenses,
  reports:renderReports, settings:renderSettings, audit:renderAudit,
  meeting:renderMeetingWorkspace, member:renderMemberAccount };
(async function boot(){
  try { if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js'); } catch (e) {}
  try {
    var s = await api('GET', '/api/setup-status');
    if (s.json.setup_needed) return showSetup();
    var sess = await api('GET', '/api/session');
    if (sess.ok){
      SESS = { csrf: sess.json.csrf, user: sess.json.user };
      DB = sess.json.state; DB.version = sess.json.version;
      await loadUsers(); if (SESS.user.must_change_password) return forcePasswordChange();
      nav('dashboard'); replayQueue();
    } else showLogin();
  } catch(e){ showLogin('Cannot reach the CHAMA CHETU server. Check your connection — your queued offline changes will sync automatically.'); }
})();
