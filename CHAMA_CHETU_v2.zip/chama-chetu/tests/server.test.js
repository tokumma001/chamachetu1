/* CHAMA CHETU v2 — server integration tests (node:test + fetch).
   Run: npm test    (isolated temp DB; no demo data anywhere) */
process.env.SESSION_SECRET = 'test-secret-please-change-32-chars-minimum-ok';
process.env.SETUP_TOKEN = 'test-setup-token-24chars-minimum-ok!';
const os = require('os'), path = require('path'), fs = require('fs');
process.env.DB_PATH = path.join(os.tmpdir(), 'cc-test-' + Date.now() + '.db');
process.env.COOKIE_SECURE = 'false';

const { test, before, after } = require('node:test');
const assert = require('node:assert');
const mod = require('../server/server.js');
const Core2 = require('../src/core.js');
const { app } = mod;

let server, base, cookie = '', csrf = '';
async function req(method, p, body, extraHeaders) {
  const res = await fetch(base + p, {
    method, body: body ? JSON.stringify(body) : undefined,
    headers: { 'Content-Type': 'application/json', ...(cookie ? { Cookie: cookie } : {}), ...(extraHeaders || {}) }
  });
  const sc = res.headers.get('set-cookie');
  if (sc) cookie = sc.split(';')[0];
  let j = null; try { j = await res.json(); } catch (e) {}
  return { status: res.status, json: j };
}
async function loginAs(u, p) { cookie = ''; const r = await req('POST', '/api/login', { username: u, password: p }); csrf = r.json.csrf || csrf; return r; }
function H() { return { 'X-CSRF-Token': csrf }; }

before(async () => {
  server = app.listen(0);
  await new Promise(r => server.on('listening', r));
  base = 'http://127.0.0.1:' + server.address().port;
});

test('health endpoint reports CHAMA CHETU v2', async () => {
  const r = await req('GET', '/api/health');
  assert.equal(r.status, 200); assert.equal(r.json.app, 'CHAMA CHETU');
});

test('setup requires the env SETUP_TOKEN — wrong token rejected', async () => {
  const r = await req('POST', '/api/setup', { setup_token: 'WRONG', username: 'hacker', password: 'whatever123' });
  assert.equal(r.status, 403);
});

test('one-time setup creates the FIRST admin; zero demo members/payments', async () => {
  const r = await req('POST', '/api/setup', { setup_token: process.env.SETUP_TOKEN, username: 'admin1', password: 'Str0ng!Passphrase', full_name: 'Live Administrator', group_name: 'Test Chama' });
  assert.equal(r.status, 200); csrf = r.json.csrf;
  assert.equal(r.json.user.role, 'admin');
  assert.equal(r.json.state.members.length, 0);
  assert.equal(r.json.state.ledger.length, 0);
  assert.equal(r.json.state.payments.length, 0);
});

test('setup cannot run twice (one-time only)', async () => {
  cookie = '';
  const r = await req('POST', '/api/setup', { setup_token: process.env.SETUP_TOKEN, username: 'x2', password: 'whatever123' });
  assert.equal(r.status, 409);
});

test('unauthenticated user creation rejected (401)', async () => {
  cookie = '';
  const r = await req('POST', '/api/users', { username: 'anon', password: 'whatever123', role: 'member' });
  assert.equal(r.status, 401);
});

test('weak passwords rejected at user creation', async () => {
  await loginAs('admin1', 'Str0ng!Passphrase');
  const r = await req('POST', '/api/users', { username: 'weak', password: 'short', full_name: 'W', role: 'member' }, H());
  assert.equal(r.status, 400);
});

test('admin creates real accounts for every role (unique credentials, forced password change)', async () => {
  await loginAs('admin1', 'Str0ng!Passphrase');
  for (const [u, role] of [['chair1','chairperson'],['sec1','secretary'],['treas1','treasurer'],['mem1','member']]) {
    const r = await req('POST', '/api/users', { username: u, password: 'Un1que-Pass-' + u, full_name: u.toUpperCase(), role }, H());
    assert.equal(r.status, 200, u + ': ' + JSON.stringify(r.json));
  }
  const list = await req('GET', '/api/users');
  assert.equal(list.json.users.length, 5);
});

test('duplicate username rejected', async () => {
  await loginAs('admin1', 'Str0ng!Passphrase');
  const r = await req('POST', '/api/users', { username: 'mem1', password: 'Un1que-Pass-zz', full_name: 'dup', role: 'member' }, H());
  assert.equal(r.status, 409);
});

test('secretary registers a real member (server-side permission)', async () => {
  await loginAs('sec1', 'Un1que-Pass-sec1');
  const page = await req('GET', '/api/session'); csrf = page.json.csrf;
  const r = await req('POST', '/api/action', { action: 'addMember', payload: { full_name: 'Alice Wanjiru', phone: '+254700111222', village: 'Kiambu' }, base_version: page.json.version, idempotency_key: 'add-m1' }, H());
  assert.equal(r.status, 200, JSON.stringify(r.json));
  assert.equal(r.json.state.members.length, 1);
});

test('account locks after 5 failed logins (even with the correct password)', async () => {
  cookie = '';
  for (let i = 0; i < 5; i++) await req('POST', '/api/login', { username: 'mem1', password: 'wrong-' + i });
  const r = await req('POST', '/api/login', { username: 'mem1', password: 'Un1que-Pass-mem1' });
  assert.equal(r.status, 423);
});

test('disabled user cannot log in', async () => {
  await loginAs('admin1', 'Str0ng!Passphrase');
  await req('POST', '/api/users/status', { username: 'mem1', status: 'disabled' }, H());
  cookie = '';
  const r = await req('POST', '/api/login', { username: 'mem1', password: 'Un1que-Pass-mem1' });
  assert.equal(r.status, 401);
});

test('treasurer records payment; duplicate payment blocked SERVER-side', async () => {
  await loginAs('sec1', 'Un1que-Pass-sec1');
  const sp = await req('GET', '/api/session'); csrf = sp.json.csrf;
  const mt = await req('POST', '/api/action', { action: 'createMeeting', payload: { date: '2026-11-07', venue: 'Hall' }, base_version: sp.json.version, idempotency_key: 'mt-1' }, H());
  assert.equal(mt.status, 200, JSON.stringify(mt.json));
  await loginAs('treas1', 'Un1que-Pass-treas1');
  const tp = await req('GET', '/api/session'); csrf = tp.json.csrf;
  const m = tp.json.state.members[0];
  const p1 = await req('POST', '/api/action', { action: 'recordPayment', payload: { member_id: m.id, category: 'NORMAL_SAVINGS', amount: 500, method: 'Cash', meeting_id: mt.json.result.id }, base_version: tp.json.version, idempotency_key: 'pay-1' }, H());
  assert.equal(p1.status, 200, JSON.stringify(p1.json));
  const p2 = await req('POST', '/api/action', { action: 'recordPayment', payload: { member_id: m.id, category: 'NORMAL_SAVINGS', amount: 500, method: 'Cash', meeting_id: mt.json.result.id }, base_version: p1.json.version, idempotency_key: 'pay-2' }, H());
  assert.equal(p2.status, 400); assert.match(p2.json.error, /DUPLICATE/);
  /* same idempotency key replays the original response (no double post) */
  const p3 = await req('POST', '/api/action', { action: 'recordPayment', payload: { member_id: m.id, category: 'NORMAL_SAVINGS', amount: 500, method: 'Cash', meeting_id: mt.json.result.id }, base_version: p1.json.version, idempotency_key: 'pay-1' }, H());
  assert.equal(p3.status, 200);
  const ledgerRows = p3.json.state.ledger.filter(e => e.category === 'NORMAL_SAVINGS');
  assert.equal(ledgerRows.length, 1, 'idempotent replay must not post twice');
});

test('RBAC: member denied money actions; member sees ONLY own finances; treasurer denied role assignment', async () => {
  await loginAs('admin1', 'Str0ng!Passphrase');
  const ap = await req('GET', '/api/session'); csrf = ap.json.csrf;
  const mem = ap.json.state.members[0];
  const ur = await req('POST', '/api/users', { username: 'mem2', password: 'Un1que-Pass-mem2', full_name: 'Alice Link', role: 'member', member_id: mem.id }, H());
  assert.equal(ur.status, 200);
  await loginAs('mem2', 'Un1que-Pass-mem2');
  const mp = await req('GET', '/api/session'); csrf = mp.json.csrf;
  const r1 = await req('POST', '/api/action', { action: 'recordPayment', payload: { member_id: mem.id, category: 'NORMAL_SAVINGS', amount: 100 }, base_version: mp.json.version, idempotency_key: 'x1' }, H());
  assert.equal(r1.status, 403, 'member cannot record payments');
  const r2 = await req('GET', '/api/state');
  assert.equal(r2.json.state.payments.filter(p => p.member_id !== mem.id).length, 0, 'no other members’ payments delivered');
  assert.equal(r2.json.state.investments.length, 0, 'investments hidden from members');
  assert.equal(r2.json.state.expenses.length, 0, 'expenses hidden from members');
  assert.equal(r2.json.state.users.length, 0, 'user list hidden from members');
  const r3 = await req('GET', '/api/audit');
  assert.equal(r3.status, 403, 'member cannot read the server audit log');
  await loginAs('treas1', 'Un1que-Pass-treas1');
  const tp = await req('GET', '/api/session'); csrf = tp.json.csrf;
  const r4 = await req('POST', '/api/users/role', { username: 'mem2', role: 'admin' }, H());
  assert.equal(r4.status, 403, 'treasurer cannot assign roles');
});

test('attendance X auto-fine 200; closeMeeting auto-fines the UNPAID member once', async () => {
  await loginAs('sec1', 'Un1que-Pass-sec1');
  const sp = await req('GET', '/api/session'); csrf = sp.json.csrf;
  /* add a second member who does NOT pay at this meeting
     (the first member already paid in full in the duplicate-payment test,
     so per business rules she must NOT be fined) */
  const bobr = await req('POST', '/api/action', { action: 'addMember', payload: { full_name: 'Bob Ochieng', village: 'Kisumu' }, base_version: sp.json.version, idempotency_key: 'add-m2' }, H());
  assert.equal(bobr.status, 200, JSON.stringify(bobr.json));
  const bobId = bobr.json.result.id;
  const open = bobr.json.state.meetings.find(m => m.status === 'open');
  const a = await req('POST', '/api/action', { action: 'markAttendance', payload: { meeting_id: open.id, member_id: bobId, status: 'X' }, base_version: bobr.json.version, idempotency_key: 'att-1' }, H());
  assert.equal(a.status, 200); assert.equal(a.json.result.fine_amount, 200);
  const c = await req('POST', '/api/action', { action: 'closeMeeting', payload: { meeting_id: open.id, minutes: 'm', resolutions: 'r' }, base_version: a.json.version, idempotency_key: 'close-1' }, H());
  assert.equal(c.status, 200, JSON.stringify(c.json));
  const late = c.json.state.ledger.filter(e => e.category === 'LATE_FINE' && e.member_id === bobId && !c.json.state.ledger.some(x => x.reversal_of === e.id));
  assert.equal(late.length, 1, 'exactly one late-payment fine for the unpaid member');
  const c2 = await req('POST', '/api/action', { action: 'closeMeeting', payload: { meeting_id: open.id, minutes: 'x', resolutions: 'y' }, base_version: c.json.version, idempotency_key: 'close-2' }, H());
  assert.equal(c2.status, 400, 'closed meetings cannot be re-closed');
});

test('insufficient-cash expense rejected; negative balances impossible', async () => {
  await loginAs('treas1', 'Un1que-Pass-treas1');
  const tp = await req('GET', '/api/session'); csrf = tp.json.csrf;
  const r = await req('POST', '/api/action', { action: 'addExpense', payload: { desc: 'big', amount: 999999 }, base_version: tp.json.version, idempotency_key: 'exp-bad' }, H());
  assert.equal(r.status, 400); assert.match(r.json.error, /Insufficient/);
});

test('MGR: spin selects beneficiary, no repeat in cycle, payout once, double penalty computed', async () => {
  await loginAs('chair1', 'Un1que-Pass-chair1');
  const cp = await req('GET', '/api/session'); csrf = cp.json.csrf;
  const st = cp.json.state;
  const cfg = await req('POST', '/api/action', { action: 'mgrConfig', payload: { amount: 300, order: st.members.map(m => m.id) }, base_version: cp.json.version, idempotency_key: 'mgr-cfg' }, H());
  assert.equal(cfg.status, 200);
  const s1 = await req('POST', '/api/action', { action: 'spinSelect', payload: { meeting_id: st.meetings[0].id }, base_version: cfg.json.version, idempotency_key: 'spin-1' }, H());
  assert.equal(s1.status, 200);
  assert.equal(s1.json.result.record.purpose, 'MERRY_GO_ROUND_BENEFICIARY');
  const s2 = await req('POST', '/api/action', { action: 'spinSelect', payload: { meeting_id: st.meetings[0].id }, base_version: s1.json.version, idempotency_key: 'spin-2' }, H());
  assert.ok(!s2.json.result.eligible.includes(s1.json.result.winner.id), 'no repeat winner within a cycle');
  const w = s2.json.result.winner.id;
  /* payouts are a treasurer permission — chairperson must be DENIED (RBAC check) */
  const poDenied = await req('POST', '/api/action', { action: 'recordMgrPayout', payload: { member_id: w, date: '2026-11-07' }, base_version: s2.json.version, idempotency_key: 'payout-denied' }, H());
  assert.equal(poDenied.status, 403, 'chairperson cannot record payouts');
  await loginAs('treas1', 'Un1que-Pass-treas1');
  const tp = await req('GET', '/api/session'); csrf = tp.json.csrf;
  const po = await req('POST', '/api/action', { action: 'recordMgrPayout', payload: { member_id: w, date: '2026-11-07' }, base_version: s2.json.version, idempotency_key: 'payout-1' }, H());
  assert.equal(po.status, 200);
  const po2 = await req('POST', '/api/action', { action: 'recordMgrPayout', payload: { member_id: w, date: '2026-11-07' }, base_version: po.json.version, idempotency_key: 'payout-2' }, H());
  assert.equal(po2.status, 400); assert.match(po2.json.error, /twice/);
  /* a member with outstanding MGR gets a double-penalty quote = 2 × owed
     (po.json is the last successful response and carries the full state) */
  const owingMember = po.json.state.members.find(m => m.id !== w);
  const dbl = Core2.mgrDoublePenaltyAmount(po.json.state, owingMember.id);
  assert.equal(dbl, 600, 'double penalty = 2 x 300 outstanding');
});

test('share-out: insufficient cash blocked; correct config totals', async () => {
  await loginAs('admin1', 'Str0ng!Passphrase');
  const ap = await req('GET', '/api/session'); csrf = ap.json.csrf;
  const cfg = await req('POST', '/api/action', { action: 'configureShareOut', payload: { share_amount: 100000, share_date: '2026-12-01' }, base_version: ap.json.version, idempotency_key: 'so-cfg' }, H());
  assert.equal(cfg.status, 200);
  const ex = await req('POST', '/api/action', { action: 'executeShareOut', payload: {}, base_version: cfg.json.version, idempotency_key: 'so-ex' }, H());
  assert.equal(ex.status, 400); assert.match(ex.json.error, /Insufficient/);
});

test('version conflict: stale write rejected with 409 — no silent overwrite', async () => {
  await loginAs('treas1', 'Un1que-Pass-treas1');
  const tp = await req('GET', '/api/session'); csrf = tp.json.csrf;
  const r = await req('POST', '/api/action', { action: 'recordPayment', payload: { member_id: tp.json.state.members[0].id, category: 'WELFARE', amount: 50 }, base_version: 1, idempotency_key: 'stale-1' }, H());
  assert.equal(r.status, 409); assert.equal(r.json.code, 'VERSION_CONFLICT');
});

test('CSRF token required on every mutating route', async () => {
  await loginAs('treas1', 'Un1que-Pass-treas1');
  const tp = await req('GET', '/api/session');
  const r = await req('POST', '/api/action', { action: 'recordPayment', payload: {}, base_version: tp.json.version, idempotency_key: 'nocsrf' }, {});
  assert.equal(r.status, 403);
});

test('password change verifies current password; admin reset forces change and kills sessions', async () => {
  await loginAs('sec1', 'Un1que-Pass-sec1');
  const sp = await req('GET', '/api/session'); csrf = sp.json.csrf;
  const bad = await req('POST', '/api/password', { current: 'nope', next: 'NewStr0ng-Pass!' }, H());
  assert.equal(bad.status, 401);
  const okp = await req('POST', '/api/password', { current: 'Un1que-Pass-sec1', next: 'NewStr0ng-Pass!' }, H());
  assert.equal(okp.status, 200);
  await loginAs('admin1', 'Str0ng!Passphrase');
  const ap = await req('GET', '/api/session'); csrf = ap.json.csrf;
  const rs = await req('POST', '/api/users/reset-password', { username: 'sec1', new_password: 'Reset-Str0ng-99' }, H());
  assert.equal(rs.status, 200);
  /* the reset user's old session must be dead */
  cookie = '';
  const l = await req('POST', '/api/login', { username: 'sec1', password: 'Reset-Str0ng-99' });
  assert.equal(l.status, 200);
  assert.equal(l.json.user.must_change_password, true, 'forced change at next login');
});

test('backup/restore round-trip preserves data; non-admin denied', async () => {
  await loginAs('treas1', 'Un1que-Pass-treas1');
  const bk = await fetch(base + '/api/backup', { headers: { Cookie: cookie } });
  assert.equal(bk.status, 403, 'treasurer cannot download backup');
  await loginAs('admin1', 'Str0ng!Passphrase');
  const ap = await req('GET', '/api/session'); csrf = ap.json.csrf;
  const bk2 = await req('GET', '/api/backup');
  assert.equal(bk2.status, 200);
  assert.ok(!JSON.stringify(bk2.json.users).includes('password_hash'), 'backup must not contain password hashes');
  const before = bk2.json.state;
  const rs = await req('POST', '/api/restore', { state: before, exported_at: bk2.json.exported_at }, H());
  assert.equal(rs.status, 200, JSON.stringify(rs.json));
  const after = await req('GET', '/api/state');
  assert.equal(after.json.state.members.length, before.members.length);
  assert.equal(after.json.state.ledger.length, before.ledger.length);
  /* restore denied for treasurer already asserted via backup; role check on restore too */
  await loginAs('treas1', 'Un1que-Pass-treas1');
  const tp = await req('GET', '/api/session'); csrf = tp.json.csrf;
  const rr = await req('POST', '/api/restore', { state: before }, H());
  assert.equal(rr.status, 403);
});

test('every ledger entry stays balanced after the full run', () => {
  const st = mod.loadState().data;
  st.ledger.forEach(e => {
    const d = e.lines.reduce((s, l) => s + l.debit, 0), c = e.lines.reduce((s, l) => s + l.credit, 0);
    assert.ok(Math.abs(d - c) < 0.011, 'unbalanced entry ' + e.id);
  });
});

after(() => { try { server.closeAllConnections(); } catch (e) {} server.close(); try { fs.unlinkSync(process.env.DB_PATH); } catch (e) {} });
