/* CHAMA CHETU automated test suite — run: node tests/test.js */
var C = require('../src/core.js');
var PASS = 0, FAIL = 0, LOG = [];
function T(name, fn){ try{ fn(); PASS++; LOG.push('PASS  '+name); } catch(e){ FAIL++; LOG.push('FAIL  '+name+'  -> '+e.message); } }
function eq(a,b,msg){ if (Math.abs(a-b) > 0.011) throw new Error((msg||'eq')+': '+a+' != '+b); }
function ok(v,msg){ if(!v) throw new Error(msg||'expected truthy'); }
function throws(fn, frag){ try{ fn(); } catch(e){ if(!frag || String(e.message).indexOf(frag)!==-1) return; throw new Error('wrong error: '+e.message); } throw new Error('expected throw containing "'+frag+'"'); }
function fresh(){ return C.seedDB(); }
var TR='treasurer', CH='chairperson', SE='secretary', AD='admin', ME='member';

/* ---- refactor checks: loans fully replaced by merry-go-round ---- */
T('loans fully removed from the engine', function(){
  ['applyLoan','approveLoan','disburseLoan','loanSchedule','loanOutstanding','loanRepaidTotals'].forEach(function(k){
    ok(typeof C[k] === 'undefined', k + ' still exists');
  });
  ok(!C.PAY_CATEGORIES.LOAN_REPAY && !C.PAY_CATEGORIES.LOAN_INTEREST && !C.PAY_CATEGORIES.LOAN_PRINCIPAL, 'loan categories still exist');
});
T('new payment categories: monthly, delayed fine, double penalty', function(){
  ok(C.PAY_CATEGORIES.LATE_FINE && C.PAY_CATEGORIES.MGR_DOUBLE);
  ok(C.PAY_CATEGORIES.NORMAL_SAVINGS.label.indexOf('Monthly') !== -1);
  ok(C.PAY_CATEGORIES.LATE_FINE.credit === 'FINES_RECEIVABLE');
  ok(C.PAY_CATEGORIES.MGR_DOUBLE.credit === 'MGR_FUND');
});

/* ---- auth ---- */
var db = fresh();
T('login works with correct PIN', function(){ ok(C.login(db,'treasurer',db._seedPwd).role === 'treasurer'); });
T('login rejects wrong PIN', function(){ throws(function(){ C.login(db,'treasurer','x'); }, 'Invalid'); });
T('member cannot record payments', function(){ throws(function(){ C.recordPayment(db,{member_id:'MEM1',category:'NORMAL_SAVINGS',amount:100},ME); }, 'ACCESS DENIED'); });
T('secretary can record attendance', function(){
  var m = C.createMeeting(db,{date:'2026-10-01',venue:'Hall'},SE);
  ok(C.markAttendance(db,m.id,'MEM1','P',SE).status === 'P');
});

/* ---- 1 & 2: member edit/remove + role assignment ---- */
T('admin can edit a member (audited)', function(){
  var m = C.editMember(db,'MEM4',{full_name:'Joseph K. Kimani', village:'Nyeri Town'},AD);
  ok(m.full_name === 'Joseph K. Kimani');
  ok(db.audit.some(function(a){ return a.action === 'MEMBER_EDIT'; }));
});
T('ordinary member cannot edit members', function(){ throws(function(){ C.editMember(db,'MEM4',{full_name:'x'},ME); }, 'ACCESS DENIED'); });
T('admin can soft-remove a member; ledger untouched', function(){
  var before = db.ledger.length;
  C.removeMember(db,'MEM11','Left the group',AD);
  ok(db.members.filter(function(x){ return x.id === 'MEM11'; })[0].status === 'Removed');
  ok(db.audit.some(function(a){ return a.action === 'MEMBER_REMOVED'; }));
  eq(db.ledger.length, before, 'ledger rows must never be deleted');
});
T('admin can assign a role to another user (audited)', function(){
  var u = C.setUserRole(db,'U5','treasurer',AD); ok(u.role === 'treasurer');
  ok(db.audit.some(function(a){ return a.action === 'ROLE_CHANGE'; }));
});
T('non-admin cannot assign roles', function(){ throws(function(){ C.setUserRole(db,'U5','member',TR); }, 'ACCESS DENIED'); });
T('cannot demote the last administrator', function(){ throws(function(){ C.setUserRole(db,'U1','member',AD); }, 'last administrator'); });

/* ---- attendance + automated fines ---- */
var db2 = fresh();
var mtg = C.createMeeting(db2,{date:'2026-10-01',venue:'Hall A'},SE);
T('X/L/A/P auto-fines correct', function(){
  eq(C.markAttendance(db2,mtg.id,'MEM4','X',SE).fine_amount, 200);
  eq(C.markAttendance(db2,mtg.id,'MEM5','L',SE).fine_amount, 50);
  eq(C.markAttendance(db2,mtg.id,'MEM6','A',SE).fine_amount, 0);
  eq(C.markAttendance(db2,mtg.id,'MEM7','P',SE).fine_amount, 0);
});
T('no duplicate attendance fine; correction reverses & audits', function(){
  C.markAttendance(db2,mtg.id,'MEM4','X',SE);
  C.markAttendance(db2,mtg.id,'MEM4','P',SE);
  var live = db2.ledger.filter(function(e){ return e.category==='FINE' && e.member_id==='MEM4' && e.meeting_id===mtg.id && !C.isReversed(db2,e.id); });
  eq(live.length, 0, 'fine must be reversed');
  ok(db2.audit.some(function(a){ return a.action === 'ATTENDANCE_CORRECTION'; }));
});
T('chairperson waives fine with reason; audited', function(){
  C.markAttendance(db2,mtg.id,'MEM8','X',SE);
  C.waiveFine(db2,mtg.id,'MEM8','Bereavement','Grace',CH);
  eq(C.accBalance(db2,'FINES_RECEIVABLE','MEM8'), 0);
});

/* ---- savings separation ---- */
var db3 = fresh();
var m1 = C.createMeeting(db3,{date:'2026-10-01'},SE);
T('monthly contribution posts to MEMBER_SAVINGS only', function(){
  C.recordPayment(db3,{member_id:'MEM1',category:'NORMAL_SAVINGS',amount:500,method:'Cash',meeting_id:m1.id},TR);
  eq(C.accBalance(db3,'MEMBER_SAVINGS','MEM1'), 500);
});
T('MGR contribution posts to SEPARATE MGR_FUND (never merged)', function(){
  C.recordPayment(db3,{member_id:'MEM1',category:'MGR',amount:300,method:'Cash',meeting_id:m1.id},TR);
  eq(C.groupBalance(db3,'MGR_FUND'), 300);
  eq(C.accBalance(db3,'MEMBER_SAVINGS','MEM1'), 500);
});
T('duplicate payment blocked', function(){
  throws(function(){ C.recordPayment(db3,{member_id:'MEM1',category:'NORMAL_SAVINGS',amount:500,method:'Cash',meeting_id:m1.id},TR); }, 'DUPLICATE');
});

/* ---- 5 & 7: delayed payment fines + double penalty ---- */
var db4 = fresh();
var m4 = C.createMeeting(db4,{date:'2026-10-01'},SE);
T('closing a meeting auto-fines delayed contributors (configurable amount)', function(){
  C.closeMeeting(db4,m4.id,'Minutes','Resolutions',SE); /* nobody paid this meeting */
  var late = db4.ledger.filter(function(e){ return e.category==='LATE_FINE' && e.member_id==='MEM1' && !C.isReversed(db4,e.id); });
  eq(late.length, 1, 'exactly one late fine');
  eq(late[0].lines[0].debit, 100, 'late_payment_fine amount');
});
T('late fine never duplicated; re-closing a closed meeting is rejected', function(){
  throws(function(){ C.closeMeeting(db4,m4.id,'m2','r2',SE); }, 'already closed');
  eq(db4.ledger.filter(function(e){ return e.category==='LATE_FINE' && e.member_id==='MEM1' && !C.isReversed(db4,e.id); }).length, 1);
});
T('double penalty: delayed MGR pays DOUBLE into the MGR fund', function(){
  C.mgrConfig(db4,{amount:300,order:['MEM1','MEM2','MEM3']},AD);
  var before = C.groupBalance(db4,'MGR_FUND');
  C.recordPayment(db4,{member_id:'MEM2',category:'MGR_DOUBLE',amount:600,method:'Cash'},TR);
  eq(C.groupBalance(db4,'MGR_FUND') - before, 600, 'double of 300');
});

/* ---- 8: spin determines next MGR beneficiary ---- */
T('spin picks MGR beneficiary; becomes next in rotation; no repeat in cycle', function(){
  var dbx = fresh();
  C.mgrConfig(dbx,{amount:300,order:dbx.members.map(function(m){ return m.id; })},AD);
  var m = C.createMeeting(dbx,{date:'2026-11-01'},SE);
  var r1 = C.spinSelect(dbx,m.id,'Grace',CH);
  ok(r1.record.purpose === 'MERRY_GO_ROUND_BENEFICIARY', 'purpose recorded');
  eq(C.mgrNextBeneficiary(dbx), r1.winner.id, 'spun member is next beneficiary');
  var r2s = C.spinSelect(dbx,m.id,'Grace',CH);
  ok(r2s.eligible.indexOf(r1.winner.id) === -1, 'prior winner excluded in same cycle');
  eq(C.mgrNextBeneficiary(dbx), r2s.winner.id, 'next updated to latest spin');
  ok(dbx.audit.some(function(a){ return a.action === 'SPIN'; }));
});
T('MGR payout once per cycle; audit kept', function(){
  var dbx = fresh();
  C.mgrConfig(dbx,{amount:300,order:['MEM1','MEM2','MEM3']},AD);
  var m = C.createMeeting(dbx,{date:'2026-11-01'},SE);
  var r1 = C.spinSelect(dbx,m.id,'Grace',CH);
  C.recordMgrPayout(dbx, r1.winner.id, null, '2026-11-01', TR);
  throws(function(){ C.recordMgrPayout(dbx, r1.winner.id, null, '2026-11-01', TR); }, 'twice');
});
T('ordinary member cannot spin', function(){ throws(function(){ C.spinSelect(fresh(),'MTG1','x',ME); }, 'ACCESS DENIED'); });
T('spin does not disburse anything automatically', function(){
  var dbx = fresh();
  var m = C.createMeeting(dbx,{date:'2026-11-01'},SE);
  var r = C.spinSelect(dbx,m.id,'chair',CH);
  eq(dbx.mgr.payouts.length, 0, 'no payout auto-recorded');
});

/* ---- 10: share-out of savings ---- */
T('share-out pays members from savings & cash; audited', function(){
  var dbx = fresh();
  var m = C.createMeeting(dbx,{date:'2026-10-01'},SE);
  C.recordPayment(dbx,{member_id:'MEM1',category:'NORMAL_SAVINGS',amount:2000,method:'Cash',meeting_id:m.id},TR);
  C.recordPayment(dbx,{member_id:'MEM2',category:'NORMAL_SAVINGS',amount:2000,method:'Cash',meeting_id:m.id},TR);
  C.configureShareOut(dbx,{share_amount:500,share_date:'2026-12-15'},AD);
  var cashBefore = C.groupBalance(dbx,'CASH');
  var rec = C.executeShareOut(dbx,'2026-12-15','Grace',TR);
  eq(rec.members, 2, 'two members with savings paid');
  eq(rec.total, 1000, 'total shared out');
  eq(C.accBalance(dbx,'MEMBER_SAVINGS','MEM1'), 1500, 'member savings reduced');
  eq(C.groupBalance(dbx,'CASH'), cashBefore - 1000, 'cash reduced');
  ok(dbx.shareouts.length === 1 && dbx.audit.some(function(a){ return a.action === 'SHARE_OUT'; }));
});
T('share-out blocked when not configured', function(){
  throws(function(){ C.executeShareOut(fresh(), null, 'x', TR); }, 'not configured');
});
T('share-out blocked when cash insufficient', function(){
  var dbx = fresh();
  var m = C.createMeeting(dbx,{date:'2026-10-01'},SE);
  C.recordPayment(dbx,{member_id:'MEM1',category:'NORMAL_SAVINGS',amount:2000,method:'Cash',meeting_id:m.id},TR);
  C.configureShareOut(dbx,{share_amount:5000},AD);
  throws(function(){ C.executeShareOut(dbx, null, 'x', TR); }, 'Insufficient');
});
T('member cannot execute share-out', function(){ throws(function(){ C.executeShareOut(fresh(), null, 'x', ME); }, 'ACCESS DENIED'); });

/* ---- ledger integrity ---- */
T('every ledger entry balanced', function(){
  [db,db2,db3,db4].forEach(function(d){
    d.ledger.forEach(function(e){ var dr=0,cr=0; e.lines.forEach(function(l){ dr+=l.debit; cr+=l.credit; }); eq(dr,cr,'entry '+e.id); });
  });
});
T('accounting identity: Assets = Liabilities + (Income - Expenses)', function(){
  [db,db2,db3,db4].forEach(function(d){
    var p = C.financialPosition(d);
    var assets = p.cash + p.mpesa + p.fines_receivable + p.investments;
    var liab = p.savings + p.special + p.mgr_fund + p.welfare;
    var pl = p.fine_income - p.expenses;
    eq(assets, liab + pl, 'identity for a db');
  });
});
T('member statement aggregates without loan fields', function(){
  var st = C.memberStatement(db3,'MEM1');
  eq(st.savings_total, 500);
  ok(st.mgr_outstanding !== undefined && st.loans_outstanding === undefined, 'loan fields must be gone');
});

console.log(LOG.join('\n'));
console.log('\n================================');
console.log('RESULT: ' + PASS + ' passed, ' + FAIL + ' failed, ' + (PASS+FAIL) + ' total');
process.exit(FAIL ? 1 : 0);
