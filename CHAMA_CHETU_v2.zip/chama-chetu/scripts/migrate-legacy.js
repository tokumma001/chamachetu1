/* Validates a legacy (demo-build) JSON backup and emits a CLEAN import file.
   Demo group rows are excluded; only genuine member data passes.
   Usage: node scripts/migrate-legacy.js old-backup.json > import-clean.json */
const fs = require('fs');
const DEMO_MARKERS = ['Tumaini Women Savings Group', 'TMG']; /* demo group name/prefix — excludes demo rows, contains no credentials */
const src = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
const st = src.state || src;
const out = { app: 'CHAMA CHETU', exported_at: new Date().toISOString(), migrated: true,
  settings: st.settings || {}, members: [], meetings: [], attendance: [], payments: [],
  investments: st.investments || [], expenses: st.expenses || [], ledger: [],
  audit: [], spin_history: st.spin_history || [], mgr: st.mgr || { config: null, payouts: [] },
  shareouts: [], shareout_config: st.shareout_config || null, notifications: [] };
const isDemo = s => DEMO_MARKERS.some(m => String(s || '').includes(m));
const keep = [];
(st.members || []).forEach(m => {
  if (isDemo(m.full_name) || isDemo(m.m_no)) return;
  keep.push(m.id); out.members.push(m);
});
const keepSet = new Set(keep);
(st.meetings || []).forEach(x => { if (!isDemo(x.ref)) out.meetings.push(x); });
(st.payments || []).forEach(p => { if (keepSet.has(p.member_id)) out.payments.push(p); });
(st.attendance || []).forEach(a => { if (keepSet.has(a.member_id)) out.attendance.push(a); });
(st.ledger || []).forEach(e => {
  if (e.member_id && !keepSet.has(e.member_id)) return;
  if ((e.lines || []).some(l => l.member_id && !keepSet.has(l.member_id))) return;
  out.ledger.push(e);
});
let dr = 0, cr = 0;
out.ledger.forEach(e => e.lines.forEach(l => { dr += l.debit; cr += l.credit; }));
console.error(`members kept: ${out.members.length}, payments: ${out.payments.length}, ledger entries: ${out.ledger.length}`);
console.error(`ledger balance check: debits=${dr.toFixed(2)} credits=${cr.toFixed(2)} -> ${Math.abs(dr - cr) < 0.011 ? 'BALANCED ✔' : 'UNBALANCED — DO NOT IMPORT'}`);
console.error('Demo group (Tumaini/TMG/MEM demo) rows excluded.');
if (Math.abs(dr - cr) >= 0.011) process.exit(1);
process.stdout.write(JSON.stringify(out));
