# CHAMA CHETU v2 — Production Deployment Guide

## 0. Honest architecture statement

The previous deployment (Netlify Drop of a single HTML file) **cannot host this system**:
the security upgrade requires a server process (authentication, sessions, database,
authorization). Netlify remains fine for static sites only. This package therefore needs
a Node host. All recommended options below have free tiers; nothing paid is required.

## 1. Choose a free Node host (any one)

| Host | Free tier | Notes |
|---|---|---|
| **Render** | Free web service (spins down when idle; cold start ~30s) | Easiest; HTTPS automatic |
| **Fly.io** | Free allowances | Persistent disks available for SQLite |
| **Railway** | Trial credit | One-click Node deploys |
| Your own VPS | ~KSh 700–1,200/mo | Full control; use the systemd notes below |

Database: **SQLite is included** (file-based, zero-cost, WAL mode). When the group
outgrows one server, move to free PostgreSQL (Supabase/Neon) — see `server/schema.md`
for the upgrade path; no business-logic changes are needed.

## 2. Deploy on Render (step-by-step)

1. Put this project in a **private** GitHub repository (never public: it contains your
   business logic; secrets stay out of it via .env / host env vars).
2. Render dashboard → **New → Web Service** → connect the repo.
3. Settings:
   - Build command: `npm install`
   - Start command: `npm start`
   - Instance type: Free
4. **Environment → Add environment variable** (never in the repo):
   - `SESSION_SECRET` = output of `openssl rand -hex 32`
   - `SETUP_TOKEN` = output of `openssl rand -hex 24`
   - `COOKIE_SECURE` = `true` (Render serves HTTPS automatically)
   - `SESSION_TTL_HOURS` = `12`
   - `DB_PATH` = `/data/chama_chetu.db` (if you attach a Render Disk; otherwise the
     default `./server/chama_chetu.db` — note free-tier restarts can reset ephemeral
     files, so attach a disk or accept re-running migration from backup)
5. Deploy. Render gives `https://your-app.onrender.com` with HTTPS.

Fly.io/Railway are equivalent: set the same env vars in their dashboards.

## 3. VPS deployment (optional path)

```bash
sudo apt update && sudo apt install -y nodejs npm nginx
# app
git clone <your-private-repo> && cd chama-chetu && npm ci
cp .env.example .env && nano .env      # fill SESSION_SECRET, SETUP_TOKEN, COOKIE_SECURE=true
npm start                              # or: pm2 start server/server.js --name chama-chetu
# HTTPS via Let's Encrypt + nginx reverse proxy to 127.0.0.1:3000
sudo apt install -y certbot python3-certbot-nginx && sudo certbot --nginx -d your.domain
# nightly backups (cron)
echo '0 2 * * * sqlite3 /path/server/chama_chetu.db ".backup /path/backups/cc-$(date +\%F).db"' | crontab -
```

## 4. Secure administrator initialization (one-time)

1. Open `https://your-app` — the **First-time secure setup** screen appears (it only
   appears while zero administrators exist; the endpoint refuses to run twice).
2. Paste the `SETUP_TOKEN` from your host's environment page, choose the admin username
   and a strong password (min 8 chars), set the real group name.
3. The token can then be rotated/removed from the host env for extra safety.
4. Immediately: Settings → **+ Add user** for each official (chairperson, secretary,
   treasurer, members). Each receives a temporary password and must set their own at
   first sign-in.

## 5. Frontend / domain notes

- The frontend (`public/`) is served by the same Node server — no separate static
  hosting is needed. Do **not** also host `index.html` standalone on Netlify: it must
  talk to this backend.
- Custom domain: point it at your host (Render: Settings → Custom Domains) — HTTPS is
  issued automatically. Always `COOKIE_SECURE=true` in production.

## 6. Production testing checklist (run before declaring live)

- [ ] `npm test` passes on the deployed build (72 checks)
- [ ] Setup screen appears only once; wrong SETUP_TOKEN is rejected
- [ ] Admin creates one real account per role; each logs in and changes their password
- [ ] Member login sees only their own records (verify with two different members)
- [ ] A member account, after 5 wrong passwords, locks for 10 minutes
- [ ] Disabled user cannot log in
- [ ] Treasurer records a payment; the same payment twice is rejected
- [ ] Meeting close auto-fines delayed payers exactly once
- [ ] Spin selects an MGR beneficiary; audit shows the selection record
- [ ] Share-out preview total matches recipients × amount; execute with insufficient
      cash is rejected
- [ ] Two devices (two officials) see the same live data; concurrent edits show the
      "updated by another official — screen refreshed" message rather than overwriting
- [ ] Audit screen shows server log entries for the actions above
- [ ] Backup downloads (admin) and restores on a second device
- [ ] Phone: Add to Home screen; airplane-mode entry queues a payment and it syncs
      when back online

## 7. Backup & disaster recovery

- **App-level:** admin → Audit → Download server backup (JSON; excludes password
  hashes). Every restore writes an automatic pre-restore snapshot server-side
  (rollback point) before replacing data.
- **File-level:** nightly `sqlite3 .backup` cron (command above); copy off-site
  (e.g. encrypted upload or second official's email).
- **Recovery drills:** once per month, restore the latest backup to a scratch folder
  and confirm member counts and trial-balance balance.
- **Rollback of a bad migration/restore:** see docs/MIGRATION.md.

## 8. What is NOT included / not yet verified

- No live domain/HTTPS is configured in this package — that happens on your host.
- M-Pesa automatic verification is not implemented (manual code entry only); Daraja
  credentials would be configured as server env vars when you enable it.
- SMS/WhatsApp notifications are not implemented.
- Load-testing at scale has not been performed; the design target is a community group
  (tens of members, hundreds of transactions), which SQLite handles comfortably.
