# CHAMA CHETU v2 — Security report

## Vulnerabilities found in the previous (demo) build and fixed here

| # | Vulnerability | Previous state | Fix in v2 |
|---|---|---|---|
| 1 | Hardcoded demo credentials | 5 demo PINs (`Admin@123` etc.) shipped inside index.html; anyone with the URL logged in as treasurer | **Removed entirely.** Auth now server-side only; the shipped HTML contains zero credentials (verified by grep) |
| 2 | Client-side authentication | "login" was a JS check in the browser; all data downloadable in the HTML | bcrypt password hashes verified on the server; sessions issued as HttpOnly cookies |
| 3 | localStorage as system of record | All money data in each browser; trivially editable via DevTools | Central SQLite database on the server; browser keeps only a read-only render + a secure offline QUEUE that the server validates on replay |
| 4 | No server-side authorization | Buttons hidden per role, but any user could call any function from the console | Every mutation goes through one dispatch table that checks the role permission server-side and logs ACCESS_DENIED |
| 5 | Member privacy | Member view filtered in JS only | Server strips other members' financial rows before responding to member sessions |
| 6 | CSRF | N/A (no server) | Double-submit protection: CSRF token issued at login, required header on every mutating request (403 otherwise, tested) |
| 7 | Brute force | None | 5 failed logins → 10-minute lockout (tested), per-IP rate limiting (90 req/min) |
| 8 | Session fixation/hijacking | None | 256-bit random SIDs, HttpOnly + SameSite=Strict (+ Secure on HTTPS), server-side expiry, purge of expired rows |
| 9 | Duplicate financial entries | Guard existed in engine only | Still enforced inside the DB transaction; duplicate payments rejected with 400 (tested end-to-end) |
| 10 | Concurrent multi-device writes | N/A | Optimistic versioning: stale writes rejected with 409, client reloads — no silent overwrite (tested) |
| 11 | XSS via injected fields | Partial | All rendered values pass through `esc()`; CSP header set server-side |
| 12 | Secrets in frontend | Demo PINs in HTML | No secrets in the client; SESSION_SECRET/SETUP_TOKEN live only in server .env (documented) |
| 13 | Insecure backups | JSON backup from localStorage | Admin-only server backup endpoint (password hashes excluded), audited; restore keeps an automatic rollback snapshot |
| 14 | Deletion of financial history | Reversals-only in engine | Preserved; reversals audited; ledger append-only in the state document |

## Remaining responsibilities of the operator (external configuration)
- Serve HTTPS (the host terminates TLS; set COOKIE_SECURE=true in production).
- Keep `.env` out of any public repo; rotate SESSION_SECRET/SETUP_TOKEN periodically.
- OS-level hardening and OS updates of the VPS/host.
- Optional: Safaricom Daraja credentials (if M-Pesa auto-verification is enabled later) — server env only.
