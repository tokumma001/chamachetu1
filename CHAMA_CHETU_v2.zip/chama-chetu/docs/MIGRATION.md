# CHAMA CHETU v2 — data migration & rollback

## Principles
- **No demo data migrates.** The production database starts empty; the demo group
  (Tumaini Women Savings Group, its members/payments/spins) exists only in the old
  standalone demo file and is deliberately NOT auto-imported.
- Migration is explicit, validated, and reversible.

## Procedure (migrating genuine records from the previous offline build)
1. **Backup first.** On each old device: Audit → Download full backup (JSON). Also copy
   the old `chama_chetu.db` if the server build was used.
2. **Initialize production DB**: start the new server once, complete `/api/setup`
   (creates the first real admin; DB has zero members/payments).
3. **Create the real user accounts** (admin → Settings → + Add user) for chairperson,
   secretary, treasurer and members. Members link to member records by full name.
4. **Migrate members**: use Members → Import Excel with the old member list
   (template provided in-app). Duplicates and blank rows are skipped and reported.
5. **Migrate financial records (optional, only if genuine)**: send the old JSON backup
   to the server operator, who validates it with
   `node scripts/migrate-legacy.js <old-backup.json>` — this prints a validation
   report (ledger balance check, duplicate scan, member-name mapping) and writes a
   clean, admin-approved `import-<date>.json` that the admin then restores via
   Audit → Restore. The validator never imports demo member names or demo pins.
6. **Validate**: open Reports → Trial balance (ledger must show BALANCED ✔), spot-check
   3 member statements against paper records, then take a fresh server backup.
7. **Rollback**: if anything is wrong, the restore operation wrote an automatic
   pre-restore snapshot (idempotency table, key `PRE-RESTORE-*`); the operator can
   restore it, or re-run the migration. File-level rollback: replace
   `server/chama_chetu.db` with the nightly backup taken in step 1.
